import {
  Globe, Smartphone, Server, Search, Mountain, PenLine, Megaphone, Workflow, Sparkles, FileText, FileSpreadsheet,
  Presentation, Image as ImageIcon, Video, Link2, Figma, Rocket, type LucideProps,
} from "lucide-react";

const MAP = {
  globe: Globe, smartphone: Smartphone, server: Server, search: Search, mountain: Mountain, "pen-line": PenLine,
  megaphone: Megaphone, workflow: Workflow, sparkles: Sparkles, file: FileText, sheet: FileSpreadsheet,
  slides: Presentation, image: ImageIcon, video: Video, link: Link2, figma: Figma, rocket: Rocket,
} as const;

export const ICON_NAMES = Object.keys(MAP);

export function Icon({ name, ...props }: { name?: string | null } & Omit<LucideProps, "name">) {
  const C = MAP[(name ?? "sparkles") as keyof typeof MAP] ?? Sparkles;
  return <C {...props} />;
}
