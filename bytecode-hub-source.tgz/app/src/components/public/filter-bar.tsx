import Link from "next/link";
import { cn } from "@/lib/utils";

/** Server-rendered filter chips that work without JavaScript (query-string links). */
export function FilterChips({ basePath, param, options, current, params }: {
  basePath: string; param: string; options: { value: string; label: string }[]; current?: string; params: Record<string, string | undefined>;
}) {
  const href = (value?: string) => {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v && k !== param) q.set(k, v);
    if (value) q.set(param, value);
    const s = q.toString();
    return s ? `${basePath}?${s}` : basePath;
  };
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none]">
      <Link href={href()} className={cn("chip shrink-0 px-4 py-2 text-sm", !current && "border-navy bg-navy text-white")}>All</Link>
      {options.map((o) => (
        <Link key={o.value} href={href(o.value)} className={cn("chip shrink-0 px-4 py-2 text-sm hover:border-brand", current === o.value && "border-navy bg-navy text-white hover:border-navy")}>{o.label}</Link>
      ))}
    </div>
  );
}
