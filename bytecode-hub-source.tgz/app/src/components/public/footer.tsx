import Link from "next/link";
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone, Youtube } from "lucide-react";
import { Logo } from "@/components/logo";
import type { SiteSettings } from "@/lib/settings";
import { telLink } from "@/lib/utils";

export function Footer({ s, services }: { s: SiteSettings; services: { slug: string; name: string }[] }) {
  const social = [
    { href: s.social.facebook, label: "Facebook", Icon: Facebook },
    { href: s.social.instagram, label: "Instagram", Icon: Instagram },
    { href: s.social.linkedin, label: "LinkedIn", Icon: Linkedin },
    { href: s.social.youtube, label: "YouTube", Icon: Youtube },
  ].filter((x) => x.href);
  return (
    <footer className="bg-navy text-white/80">
      <div className="container grid gap-10 py-14 md:grid-cols-12">
        <div className="md:col-span-4">
          <Logo fileId={s.logoDarkFileId} dark />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-white/70">{s.tagline}</p>
          {social.length > 0 && (
            <div className="mt-5 flex gap-2">
              {social.map(({ href, label, Icon }) => (
                <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={label} className="grid h-10 w-10 place-items-center rounded-xl bg-white/10 hover:bg-white/20">
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          )}
        </div>
        <div className="md:col-span-3">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-white">Services</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {services.map((x) => <li key={x.slug}><Link href={`/services/${x.slug}`} className="hover:text-white">{x.name}</Link></li>)}
          </ul>
        </div>
        <div className="md:col-span-2">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-white">Explore</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {[["/portfolio", "Portfolio"], ["/showcase", "UI/UX & live demos"], ["/packages", "Packages"], ["/resources", "Resources"], ["/about", "About"], ["/request-proposal", "Request a proposal"]].map(([h, l]) => (
              <li key={h}><Link href={h} className="hover:text-white">{l}</Link></li>
            ))}
          </ul>
        </div>
        <div className="md:col-span-3">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-white">Contact</h3>
          <ul className="mt-4 space-y-3 text-sm">
            {s.phone && <li className="flex gap-3"><Phone className="mt-0.5 h-4 w-4 shrink-0 text-teal" /><a href={telLink(s.phone)!} className="hover:text-white">{s.phone}</a></li>}
            {s.email && <li className="flex gap-3"><Mail className="mt-0.5 h-4 w-4 shrink-0 text-teal" /><a href={`mailto:${s.email}`} className="break-all hover:text-white">{s.email}</a></li>}
            {s.address && <li className="flex gap-3"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-teal" /><span>{s.address}</span></li>}
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container flex flex-col gap-3 py-6 text-xs text-white/60 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} {s.companyName}. All rights reserved.</p>
          <div className="flex gap-4">
            <Link href="/privacy" className="hover:text-white">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-white">Terms of Use</Link>
            <Link href="/admin" className="hover:text-white">Team login</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
