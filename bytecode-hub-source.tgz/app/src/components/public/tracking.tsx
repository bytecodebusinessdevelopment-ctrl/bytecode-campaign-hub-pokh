"use client";
import { useEffect, useState } from "react";
import Script from "next/script";
import Link from "next/link";

const ATTR_KEY = "bc_attr";
const CONSENT_KEY = "bc_consent";

/** Stores first-touch attribution (UTM params, referrer, landing page) for 30 days so enquiries can be attributed. */
function captureAttribution() {
  try {
    const url = new URL(window.location.href);
    const utm: Record<string, string> = {};
    for (const k of ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "fbclid", "gclid", "campaign"]) {
      const v = url.searchParams.get(k);
      if (v) utm[k] = v.slice(0, 120);
    }
    const campaignPath = /^\/c\/([a-z0-9-]+)/.exec(url.pathname);
    if (campaignPath) utm.campaign = campaignPath[1];
    const existing = window.localStorage.getItem(ATTR_KEY);
    const parsed = existing ? JSON.parse(existing) : null;
    const fresh = parsed && Date.now() - parsed.ts < 30 * 86400000;
    if (Object.keys(utm).length || !fresh) {
      const ref = document.referrer && !document.referrer.startsWith(window.location.origin) ? document.referrer : parsed?.referrer ?? "";
      window.localStorage.setItem(ATTR_KEY, JSON.stringify({ utm: Object.keys(utm).length ? utm : parsed?.utm ?? {}, referrer: ref, landingPage: window.location.pathname + window.location.search, ts: Date.now() }));
    }
  } catch {
    /* storage unavailable — attribution is best-effort */
  }
}

export function readAttribution(): { utm: Record<string, string>; referrer: string; landingPage: string } | null {
  try {
    const v = window.localStorage.getItem(ATTR_KEY);
    return v ? JSON.parse(v) : null;
  } catch {
    return null;
  }
}

export function Tracking({ ga4Id, metaPixelId }: { ga4Id: string; metaPixelId: string }) {
  const [consent, setConsent] = useState<"granted" | "denied" | null>(null);
  const hasTrackers = Boolean(ga4Id || metaPixelId);

  useEffect(() => {
    captureAttribution();
    try { setConsent((window.localStorage.getItem(CONSENT_KEY) as "granted" | "denied" | null) ?? null); } catch { setConsent(null); }
  }, []);

  const decide = (v: "granted" | "denied") => {
    try { window.localStorage.setItem(CONSENT_KEY, v); } catch { /* ignore */ }
    setConsent(v);
  };

  return (
    <>
      {consent === "granted" && ga4Id && (
        <>
          <Script src={`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(ga4Id)}`} strategy="afterInteractive" />
          <Script id="ga4" strategy="afterInteractive">{`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config',${JSON.stringify(ga4Id)});`}</Script>
        </>
      )}
      {consent === "granted" && metaPixelId && (
        <Script id="meta-pixel" strategy="afterInteractive">{`!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init',${JSON.stringify(metaPixelId)});fbq('track','PageView');`}</Script>
      )}
      {hasTrackers && consent === null && (
        <div role="dialog" aria-label="Cookie notice" className="fixed inset-x-3 bottom-3 z-50 mx-auto max-w-xl rounded-2xl border border-line bg-white p-4 shadow-lift sm:inset-x-auto sm:left-5">
          <p className="text-sm text-ink-soft">
            We use analytics and advertising cookies to understand how our site is used and to measure our campaigns. See our{" "}
            <Link href="/privacy" className="font-medium text-brand underline">Privacy Policy</Link>.
          </p>
          <div className="mt-3 flex gap-2">
            <button type="button" className="btn-primary btn-sm" onClick={() => decide("granted")}>Accept</button>
            <button type="button" className="btn-outline btn-sm" onClick={() => decide("denied")}>Decline</button>
          </div>
        </div>
      )}
    </>
  );
}

/** Fire a conversion event (only runs if the visitor accepted cookies and trackers are loaded). */
export function trackLead() {
  const w = window as unknown as { gtag?: (...a: unknown[]) => void; fbq?: (...a: unknown[]) => void };
  try { w.gtag?.("event", "generate_lead"); w.fbq?.("track", "Lead"); } catch { /* ignore */ }
}
