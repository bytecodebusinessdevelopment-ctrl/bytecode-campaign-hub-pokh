/** Renders simple admin-entered text: "## Heading" lines become headings, "• " / "- " lines become list items. */
export function ProseText({ text }: { text: string }) {
  const blocks = text.split(/\n{2,}/);
  return (
    <div className="prose prose-slate max-w-none prose-headings:font-display prose-headings:text-navy prose-a:text-brand">
      {blocks.map((b, i) => {
        const trimmed = b.trim();
        if (trimmed.startsWith("## ")) return <h2 key={i}>{trimmed.slice(3)}</h2>;
        const ls = trimmed.split("\n");
        if (ls.every((l) => /^(•|-|\*)\s/.test(l.trim()))) return <ul key={i}>{ls.map((l, j) => <li key={j}>{l.trim().replace(/^(•|-|\*)\s/, "")}</li>)}</ul>;
        if (ls[0].startsWith("## ")) return <div key={i}><h2>{ls[0].slice(3)}</h2>{ls.slice(1).map((l, j) => /^(•|-|\*)\s/.test(l.trim()) ? <ul key={j}><li>{l.trim().slice(2)}</li></ul> : <p key={j}>{l}</p>)}</div>;
        return <p key={i} className="whitespace-pre-line">{trimmed}</p>;
      })}
    </div>
  );
}
