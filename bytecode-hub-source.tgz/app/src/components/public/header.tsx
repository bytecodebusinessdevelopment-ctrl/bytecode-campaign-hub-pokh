"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { ChevronDown, Menu, X, ArrowRight } from "lucide-react";
import { Logo } from "@/components/logo";
import { Icon } from "@/components/icon";
import { cn } from "@/lib/utils";

type NavService = { slug: string; name: string; icon: string | null; tagline: string | null };

const LINKS = [
  { href: "/portfolio", label: "Portfolio" },
  { href: "/packages", label: "Packages" },
  { href: "/resources", label: "Resources" },
  { href: "/about", label: "About ByteCode" },
  { href: "/contact", label: "Contact" },
];

export function Header({ services, logoFileId, companyShort }: { services: NavService[]; logoFileId: string | null; companyShort: string }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [svcOpen, setSvcOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => { setOpen(false); setSvcOpen(false); }, [pathname]);

  const active = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <header className={cn("sticky top-0 z-40 border-b transition-all", scrolled ? "border-line bg-white/90 backdrop-blur-md" : "border-transparent bg-white")}>
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2">Skip to content</a>
      <div className="container flex h-16 items-center justify-between gap-4 lg:h-[72px]">
        <Link href="/" aria-label={`${companyShort} home`} className="shrink-0"><Logo fileId={logoFileId} /></Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          <Link href="/" className={cn("rounded-lg px-3 py-2 text-sm font-medium", active("/") ? "text-brand" : "text-ink-soft hover:text-navy")}>Home</Link>
          <div className="relative" onMouseEnter={() => setSvcOpen(true)} onMouseLeave={() => setSvcOpen(false)}>
            <button
              type="button"
              aria-expanded={svcOpen}
              onClick={() => setSvcOpen((v) => !v)}
              className={cn("inline-flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-medium", active("/services") ? "text-brand" : "text-ink-soft hover:text-navy")}
            >
              Our Services <ChevronDown className={cn("h-4 w-4 transition", svcOpen && "rotate-180")} />
            </button>
            {svcOpen && (
              <div className="absolute left-1/2 top-full w-[640px] -translate-x-1/2 pt-2">
                <div className="card grid grid-cols-2 gap-1 p-3 shadow-lift">
                  {services.map((s) => (
                    <Link key={s.slug} href={`/services/${s.slug}`} className="flex gap-3 rounded-xl p-3 hover:bg-surface">
                      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-brand/10 text-brand"><Icon name={s.icon} className="h-4 w-4" /></span>
                      <span>
                        <span className="block text-sm font-semibold text-navy">{s.name}</span>
                        <span className="line-clamp-1 text-xs text-ink-muted">{s.tagline}</span>
                      </span>
                    </Link>
                  ))}
                  <Link href="/services" className="col-span-2 mt-1 flex items-center justify-between rounded-xl bg-surface px-4 py-3 text-sm font-semibold text-brand">
                    View all services <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            )}
          </div>
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className={cn("rounded-lg px-3 py-2 text-sm font-medium", active(l.href) ? "text-brand" : "text-ink-soft hover:text-navy")}>{l.label}</Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link href="/request-proposal" className="btn-primary hidden sm:inline-flex">Request a Proposal</Link>
          <button type="button" className="btn-ghost px-3 lg:hidden" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} onClick={() => setOpen((v) => !v)}>
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="max-h-[calc(100dvh-64px)] overflow-y-auto border-t border-line bg-white lg:hidden">
          <nav className="container flex flex-col gap-1 py-4" aria-label="Mobile">
            <Link href="/" className="rounded-xl px-3 py-3 font-medium text-navy hover:bg-surface">Home</Link>
            <details className="group rounded-xl" open>
              <summary className="flex cursor-pointer list-none items-center justify-between rounded-xl px-3 py-3 font-medium text-navy hover:bg-surface">
                Our Services <ChevronDown className="h-4 w-4 transition group-open:rotate-180" />
              </summary>
              <div className="grid gap-1 pb-2 pl-2">
                {services.map((s) => (
                  <Link key={s.slug} href={`/services/${s.slug}`} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-ink-soft hover:bg-surface">
                    <Icon name={s.icon} className="h-4 w-4 text-brand" /> {s.name}
                  </Link>
                ))}
              </div>
            </details>
            {LINKS.map((l) => (
              <Link key={l.href} href={l.href} className="rounded-xl px-3 py-3 font-medium text-navy hover:bg-surface">{l.label}</Link>
            ))}
            <Link href="/request-proposal" className="btn-primary mt-3">Request a Proposal</Link>
          </nav>
        </div>
      )}
    </header>
  );
}
