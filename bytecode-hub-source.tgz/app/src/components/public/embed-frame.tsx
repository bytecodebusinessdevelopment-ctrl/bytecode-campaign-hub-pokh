"use client";
import { useState } from "react";
import { Monitor, Tablet, Smartphone, ExternalLink, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

const SIZES = { desktop: "100%", tablet: "820px", mobile: "390px" } as const;

/**
 * Embedded live preview with device-width toggle. Many sites block iframes (X-Frame-Options / CSP),
 * so an external link is ALWAYS shown, and the admin must confirm a demo is embeddable before we try.
 */
export function EmbedFrame({ url, title }: { url: string; title: string }) {
  const [size, setSize] = useState<keyof typeof SIZES>("desktop");
  return (
    <div className="card overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line bg-surface px-4 py-3">
        <div className="flex gap-1" role="group" aria-label="Preview size">
          {([["desktop", Monitor], ["tablet", Tablet], ["mobile", Smartphone]] as const).map(([k, I]) => (
            <button key={k} type="button" onClick={() => setSize(k)} aria-pressed={size === k} className={cn("btn-ghost btn-sm", size === k && "bg-white text-brand shadow-sm")}>
              <I className="h-4 w-4" /><span className="hidden capitalize sm:inline">{k}</span>
            </button>
          ))}
        </div>
        <a href={url} target="_blank" rel="noopener noreferrer" className="btn-primary btn-sm">Open in new tab <ExternalLink className="h-3.5 w-3.5" /></a>
      </div>
      <div className="flex justify-center bg-slate-100 p-3 sm:p-6">
        <iframe
          src={url}
          title={title}
          style={{ width: SIZES[size], maxWidth: "100%" }}
          className="h-[70vh] min-h-[480px] rounded-xl border border-line bg-white shadow-lift transition-all"
          loading="lazy"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
          referrerPolicy="no-referrer"
        />
      </div>
      <p className="flex items-center gap-2 border-t border-line px-4 py-3 text-xs text-ink-muted">
        <AlertTriangle className="h-3.5 w-3.5" /> If the preview stays blank, the site does not allow embedding — use &ldquo;Open in new tab&rdquo;.
      </p>
    </div>
  );
}
