import Link from "next/link";
import { Check, X, Clock, Plus } from "lucide-react";
import { priceLabel } from "@/components/public/home-view";
import { cn } from "@/lib/utils";

type Pkg = {
  id: string; name: string; slug: string; description: string | null; targetAudience: string | null; priceType: string; priceNpr: number | null; priceNote: string | null;
  deliverables: string[]; features: string[]; exclusions: string[]; addOns: string[]; deliveryPeriod: string | null; requirements: string | null; featured: boolean;
};

export function PackageCard({ p, serviceSlug }: { p: Pkg; serviceSlug: string }) {
  return (
    <div id={`${serviceSlug}-${p.slug}`} className={cn("card relative flex flex-col p-6", p.featured && "ring-2 ring-brand")}>
      {p.featured && <span className="badge absolute -top-3 left-6 bg-brand text-white">Most popular</span>}
      <h3 className="text-xl font-bold">{p.name}</h3>
      {p.targetAudience && <p className="mt-1 text-sm text-ink-muted">{p.targetAudience}</p>}
      <p className="mt-4 font-display text-3xl font-extrabold text-navy">{priceLabel(p)}</p>
      {p.priceNote && <p className="text-xs text-ink-muted">{p.priceNote}</p>}
      {p.description && <p className="mt-4 text-sm leading-relaxed text-ink-soft">{p.description}</p>}
      {p.deliveryPeriod && <p className="mt-4 flex items-center gap-2 text-sm text-ink-soft"><Clock className="h-4 w-4 text-teal" /> Estimated delivery: {p.deliveryPeriod}</p>}
      <List title="Deliverables" items={p.deliverables} icon="check" />
      <List title="Features" items={p.features} icon="check" />
      <List title="Optional add-ons" items={p.addOns} icon="plus" />
      <List title="Not included" items={p.exclusions} icon="x" />
      {p.requirements && <p className="mt-4 rounded-xl bg-surface p-3 text-xs text-ink-soft"><span className="font-semibold text-navy">Requirements: </span>{p.requirements}</p>}
      <Link href={`/request-proposal?package=${encodeURIComponent(p.name)}`} className={cn("mt-6", p.featured ? "btn-primary" : "btn-outline")}>Request a quotation</Link>
    </div>
  );
}

function List({ title, items, icon }: { title: string; items: string[]; icon: "check" | "x" | "plus" }) {
  if (!items.length) return null;
  const I = icon === "check" ? Check : icon === "x" ? X : Plus;
  return (
    <div className="mt-5">
      <p className="text-xs font-semibold uppercase tracking-wide text-ink-muted">{title}</p>
      <ul className="mt-2 space-y-1.5">
        {items.map((x) => (
          <li key={x} className="flex gap-2 text-sm text-ink-soft"><I className={cn("mt-0.5 h-4 w-4 shrink-0", icon === "x" ? "text-ink-muted" : "text-teal")} />{x}</li>
        ))}
      </ul>
    </div>
  );
}
