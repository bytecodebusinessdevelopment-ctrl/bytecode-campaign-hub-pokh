import Link from "next/link";
import { ArrowRight, Briefcase, Code2, LineChart, PenTool, Tags, FolderDown, Send, Phone, Mail, MapPin, MessageCircle, CheckCircle2, Cloud, Smartphone, Server, Search, Bot, MonitorSmartphone, Quote } from "lucide-react";
import { getSettings } from "@/lib/settings";
import { getPublishedServices, getPublishedProjects, getPublishedPackages, getPublicResources, getPublicDemos, getPublishedTestimonials, getIndustries } from "@/lib/public-data";
import { ServiceCard, ProjectCard, ResourceCard, DemoCard } from "@/components/public/cards";
import { formatNpr } from "@/lib/format";
import { telLink, whatsappLink } from "@/lib/utils";
import type { t } from "@/lib/db";

type Campaign = typeof t.campaigns.$inferSelect;

const ENTRY_POINTS = [
  { href: "/portfolio", label: "Explore Our Work", body: "Live websites, systems and demos", Icon: Briefcase },
  { href: "/services/website-development", label: "Website & Software Development", body: "Websites, apps and business systems", Icon: Code2 },
  { href: "/services/seo", label: "SEO & Digital Growth", body: "Be found by the right customers", Icon: LineChart },
  { href: "/services/content-writing", label: "Content & Creative", body: "Content, travel SEO, video and social", Icon: PenTool },
  { href: "/packages", label: "Packages & Pricing", body: "Clear scopes and deliverables", Icon: Tags },
  { href: "/resources", label: "Resources & Downloads", body: "Company profile, brochures, samples", Icon: FolderDown },
];

const CAPABILITIES = [
  { Icon: MonitorSmartphone, title: "Responsive websites & CMS", body: "Fast, mobile-first websites you can update yourself." },
  { Icon: Smartphone, title: "Android, iOS & web apps", body: "Customer-facing and internal applications." },
  { Icon: Server, title: "Custom systems & APIs", body: "Business systems, workflow automation and integrations." },
  { Icon: Cloud, title: "Cloud hosting & deployment", body: "Reliable hosting, deployment and maintenance." },
  { Icon: Search, title: "SEO, AEO & analytics", body: "Search visibility on Google and AI-assisted search." },
  { Icon: Bot, title: "AI-assisted features", body: "Practical AI integrations where they add real value." },
];

export async function HomeView({ campaign }: { campaign?: Campaign | null }) {
  const [s, services, projects, packages, resources, demos, testimonials, industries] = await Promise.all([
    getSettings(),
    getPublishedServices(),
    getPublishedProjects({ limit: 6 }),
    getPublishedPackages(),
    getPublicResources({ featured: true, limit: 6, campaignId: campaign?.id }),
    getPublicDemos({ featured: true, limit: 3 }),
    getPublishedTestimonials(),
    getIndustries(),
  ]);
  const featuredProjects = projects.filter((p) => p.featured).length ? projects.filter((p) => p.featured) : projects;
  const featuredPackages = packages.filter((p) => p.pkg.featured).slice(0, 3);
  const industriesWithWork = industries.filter((i) => projects.some((p) => p.industryId === i.id));
  const heroTitle = campaign?.heroTitle || s.heroTitle;
  const heroSubtitle = campaign?.heroSubtitle || s.heroSubtitle;
  const proposalHref = campaign ? `/request-proposal?campaign=${campaign.slug}` : "/request-proposal";
  const wa = whatsappLink(s.whatsapp, `Hello ${s.companyName}, I'd like to discuss a project.`);

  return (
    <>
      {/* 1 · Hero */}
      <section className="relative overflow-hidden bg-navy text-white">
        <div className="grid-bg absolute inset-0 opacity-70" aria-hidden />
        <div className="absolute -left-40 top-10 h-96 w-96 rounded-full bg-brand/40 blur-3xl" aria-hidden />
        <div className="absolute -right-32 -top-20 h-[28rem] w-[28rem] rounded-full bg-teal/30 blur-3xl" aria-hidden />
        <div className="container relative grid items-center gap-12 py-16 sm:py-24 lg:grid-cols-[1.1fr_.9fr] lg:py-28">
          <div className="animate-fade-up">
            {campaign?.location && (
              <p className="mb-5 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold text-white/90 ring-1 ring-white/20">
                <MapPin className="h-3.5 w-3.5 text-teal" /> Now meeting businesses in {campaign.location.split(",")[0]}
              </p>
            )}
            <h1 className="text-4xl font-extrabold leading-[1.05] text-white sm:text-6xl">
              {heroTitle.split(".").filter(Boolean).map((part, i, arr) => (
                <span key={i} className={i === arr.length - 1 && arr.length > 1 ? "bg-gradient-to-r from-teal to-sky-300 bg-clip-text text-transparent" : ""}>
                  {part.trim()}{heroTitle.includes(".") ? <span className="-ml-[0.08em]">.</span> : ""}{i < arr.length - 1 ? " " : ""}
                </span>
              ))}
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/75">{heroSubtitle}</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link href={proposalHref} className="btn-accent px-6 py-3.5 text-base">Request a Proposal <ArrowRight className="h-4 w-4" /></Link>
              <Link href="/portfolio" className="btn-light px-6 py-3.5 text-base">Explore Our Work</Link>
            </div>
            <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-white/70">
              {["Websites & apps", "Custom software", "SEO & content", "Marketing & video"].map((x) => (
                <li key={x} className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-teal" /> {x}</li>
              ))}
            </ul>
          </div>
          <HeroVisual />
        </div>
      </section>

      {/* 2 · Introduction */}
      <section className="section">
        <div className="container grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="eyebrow">About {s.shortName}</p>
            <h2 className="h-section mt-3">One technology partner for building, growing and running your business online.</h2>
          </div>
          <div className="space-y-4">
            <p className="lead-text">{s.aboutIntro}</p>
            {campaign?.landingIntro && <p className="lead-text">{campaign.landingIntro}</p>}
            <p className="text-ink-soft">{s.tagline}</p>
            <Link href="/about" className="inline-flex items-center gap-1 font-semibold text-brand">More about us <ArrowRight className="h-4 w-4" /></Link>
          </div>
        </div>
      </section>

      {/* 3 · Main services */}
      <section className="section bg-surface">
        <div className="container">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div><p className="eyebrow">What we do</p><h2 className="h-section mt-3">Services</h2></div>
            <Link href="/services" className="btn-outline">All services</Link>
          </div>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((x) => <ServiceCard key={x.id} s={x} />)}
          </div>
        </div>
      </section>

      {/* 4 · Explore our solutions */}
      <section className="section">
        <div className="container">
          <p className="eyebrow">Explore our solutions</p>
          <h2 className="h-section mt-3 max-w-2xl">Go straight to what matters to you.</h2>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {ENTRY_POINTS.map(({ href, label, body, Icon }) => (
              <Link key={href} href={href} className="group flex items-center gap-4 rounded-2xl border border-line p-5 transition hover:border-brand hover:bg-brand/[.03]">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-navy text-white transition group-hover:bg-brand"><Icon className="h-5 w-5" /></span>
                <span className="flex-1"><span className="block font-semibold text-navy">{label}</span><span className="text-sm text-ink-muted">{body}</span></span>
                <ArrowRight className="h-5 w-5 text-ink-muted transition group-hover:translate-x-1 group-hover:text-brand" />
              </Link>
            ))}
            <Link href={proposalHref} className="group flex items-center gap-4 rounded-2xl bg-gradient-to-r from-brand to-teal p-5 text-white sm:col-span-2 lg:col-span-3">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white/15"><Send className="h-5 w-5" /></span>
              <span className="flex-1"><span className="block font-semibold">Request a Proposal</span><span className="text-sm text-white/80">Tell us what you need — we&apos;ll come back with a plan and quotation.</span></span>
              <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
      </section>

      {/* 5 · Featured portfolio (only real, published projects) */}
      {featuredProjects.length > 0 && (
        <section className="section bg-surface">
          <div className="container">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div><p className="eyebrow">Featured work</p><h2 className="h-section mt-3">Recent projects</h2></div>
              <Link href="/portfolio" className="btn-outline">Full portfolio</Link>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {featuredProjects.slice(0, 6).map((p) => <ProjectCard key={p.id} p={p} />)}
            </div>
          </div>
        </section>
      )}

      {demos.length > 0 && (
        <section className="section">
          <div className="container">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div><p className="eyebrow">Live demos</p><h2 className="h-section mt-3">UI/UX & live demonstrations</h2></div>
              <Link href="/showcase" className="btn-outline">All demos</Link>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{demos.map((d) => <DemoCard key={d.id} d={d} />)}</div>
          </div>
        </section>
      )}

      {/* 6 · Industry experience (derived from published projects only) */}
      {industriesWithWork.length > 0 && (
        <section className="section">
          <div className="container">
            <p className="eyebrow">Industry experience</p>
            <h2 className="h-section mt-3">Industries we have worked with</h2>
            <div className="mt-8 flex flex-wrap gap-3">
              {industriesWithWork.map((i) => (
                <Link key={i.id} href={`/portfolio?industry=${i.slug}`} className="chip px-4 py-2 text-sm hover:border-brand hover:text-brand">{i.name}</Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 7 · Technology capabilities */}
      <section className="section bg-navy text-white">
        <div className="container">
          <p className="eyebrow">Technology capabilities</p>
          <h2 className="h-section mt-3 max-w-2xl text-white">The technical depth to build what your business actually needs.</h2>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {CAPABILITIES.map(({ Icon, title, body }) => (
              <div key={title} className="rounded-2xl border border-white/10 bg-white/[.04] p-6">
                <Icon className="h-6 w-6 text-teal" />
                <h3 className="mt-4 font-semibold text-white">{title}</h3>
                <p className="mt-1 text-sm text-white/65">{body}</p>
              </div>
            ))}
          </div>
          {s.technologies.length > 0 && (
            <div className="mt-8 flex flex-wrap gap-2">
              {s.technologies.map((x) => <span key={x} className="rounded-full bg-white/10 px-3 py-1 text-xs font-medium text-white/80 ring-1 ring-white/15">{x}</span>)}
            </div>
          )}
        </div>
      </section>

      {/* 8 · Why choose ByteCode */}
      <section className="section">
        <div className="container">
          <p className="eyebrow">Why {s.shortName}</p>
          <h2 className="h-section mt-3">Why businesses choose us</h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {s.whyChoose.map((w, i) => (
              <div key={w.title} className="relative rounded-2xl border border-line p-6">
                <span className="font-display text-4xl font-extrabold text-brand/15">0{i + 1}</span>
                <h3 className="mt-2 font-bold">{w.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-soft">{w.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {testimonials.length > 0 && (
        <section className="section bg-surface">
          <div className="container">
            <p className="eyebrow">Client feedback</p>
            <h2 className="h-section mt-3">What our clients say</h2>
            <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {testimonials.map((x) => (
                <figure key={x.id} className="card p-6">
                  <Quote className="h-6 w-6 text-teal" />
                  <blockquote className="mt-3 text-ink-soft">{x.quote}</blockquote>
                  <figcaption className="mt-4 text-sm"><span className="font-semibold text-navy">{x.personName}</span>{x.designation || x.company ? <span className="text-ink-muted"> — {[x.designation, x.company].filter(Boolean).join(", ")}</span> : null}</figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 9 · Featured packages (only approved, published packages) */}
      {featuredPackages.length > 0 && (
        <section className="section bg-surface">
          <div className="container">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div><p className="eyebrow">Packages</p><h2 className="h-section mt-3">Featured packages</h2></div>
              <Link href="/packages" className="btn-outline">All packages</Link>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {featuredPackages.map(({ pkg, service }) => (
                <Link key={pkg.id} href={`/packages#${service.slug}`} className="card flex flex-col p-6 hover:shadow-lift">
                  <p className="text-xs font-semibold uppercase tracking-wide text-ink-muted">{service.name}</p>
                  <h3 className="mt-1 text-xl font-bold">{pkg.name}</h3>
                  <p className="mt-3 font-display text-2xl font-extrabold text-brand">{priceLabel(pkg)}</p>
                  {pkg.description && <p className="mt-3 line-clamp-3 text-sm text-ink-soft">{pkg.description}</p>}
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 10 · Documents and resources */}
      {resources.length > 0 && (
        <section className="section">
          <div className="container">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div><p className="eyebrow">Documents & resources</p><h2 className="h-section mt-3">Download our materials</h2></div>
              <Link href="/resources" className="btn-outline">Resource library</Link>
            </div>
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{resources.map((r) => <ResourceCard key={r.id} r={r} />)}</div>
          </div>
        </section>
      )}

      {/* 11 · Enquiry CTA + 12 · Contact information */}
      <section className="section pt-4 sm:pt-6">
        <div className="container">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-navy via-navy to-brand p-8 text-white sm:p-12">
            <div className="grid-bg absolute inset-0 opacity-50" aria-hidden />
            <div className="relative grid gap-10 lg:grid-cols-[1.3fr_1fr] lg:items-center">
              <div>
                <h2 className="text-3xl font-extrabold text-white sm:text-4xl">Let&apos;s talk about your business.</h2>
                <p className="mt-4 max-w-xl text-white/75">Share a few details about your goals and we&apos;ll recommend the right solution — whether that&apos;s a new website, a system, SEO or a campaign.</p>
                <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                  <Link href={proposalHref} className="btn-accent px-6 py-3.5 text-base">Request a Proposal <ArrowRight className="h-4 w-4" /></Link>
                  {wa && <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-light px-6 py-3.5 text-base"><MessageCircle className="h-4 w-4" /> WhatsApp us</a>}
                </div>
              </div>
              <ul className="space-y-4 rounded-2xl bg-white/[.06] p-6 ring-1 ring-white/10">
                {s.phone && <li className="flex gap-3"><Phone className="mt-0.5 h-5 w-5 text-teal" /><a href={telLink(s.phone)!} className="font-medium hover:underline">{s.phone}</a></li>}
                {s.email && <li className="flex gap-3"><Mail className="mt-0.5 h-5 w-5 text-teal" /><a href={`mailto:${s.email}`} className="break-all font-medium hover:underline">{s.email}</a></li>}
                {s.address && <li className="flex gap-3"><MapPin className="mt-0.5 h-5 w-5 text-teal" /><span>{s.address}</span></li>}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export function priceLabel(p: { priceType: string; priceNpr: number | null; priceNote: string | null }) {
  switch (p.priceType) {
    case "fixed": return p.priceNpr ? formatNpr(p.priceNpr) : "Price on request";
    case "starting": return p.priceNpr ? `From ${formatNpr(p.priceNpr)}` : "Price on request";
    case "monthly": return p.priceNpr ? `${formatNpr(p.priceNpr)} / month` : "Monthly — on request";
    case "custom": return "Custom quotation";
    default: return "Price on request";
  }
}

function HeroVisual() {
  const chips = ["Websites", "Mobile apps", "Business systems", "SEO", "Travel content", "Video"];
  return (
    <div className="relative mx-auto hidden w-full max-w-md animate-fade-up [animation-delay:150ms] sm:block" aria-hidden>
      <div className="rounded-2xl bg-white/[.07] p-3 ring-1 ring-white/15 backdrop-blur">
        <div className="flex items-center gap-1.5 px-2 pb-3">
          <span className="h-2.5 w-2.5 rounded-full bg-white/25" /><span className="h-2.5 w-2.5 rounded-full bg-white/25" /><span className="h-2.5 w-2.5 rounded-full bg-white/25" />
          <span className="ml-3 h-5 flex-1 rounded-md bg-white/10" />
        </div>
        <div className="rounded-xl bg-white p-5">
          <div className="h-3 w-24 rounded bg-navy/80" />
          <div className="mt-4 h-6 w-4/5 rounded bg-navy/90" />
          <div className="mt-2 h-6 w-3/5 rounded bg-gradient-to-r from-brand to-teal" />
          <div className="mt-4 space-y-1.5"><div className="h-2 w-full rounded bg-slate-200" /><div className="h-2 w-11/12 rounded bg-slate-200" /><div className="h-2 w-2/3 rounded bg-slate-200" /></div>
          <div className="mt-5 flex gap-2"><div className="h-8 w-28 rounded-lg bg-brand" /><div className="h-8 w-24 rounded-lg border border-slate-200" /></div>
          <div className="mt-6 grid grid-cols-3 gap-2">
            {[0, 1, 2].map((i) => <div key={i} className="h-16 rounded-lg bg-gradient-to-br from-slate-100 to-slate-200" />)}
          </div>
        </div>
      </div>
      <div className="absolute -bottom-6 -left-8 flex max-w-[16rem] flex-wrap gap-2">
        {chips.map((c) => <span key={c} className="rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-navy shadow-lift">{c}</span>)}
      </div>
      <div className="absolute -right-4 -top-5 rounded-2xl bg-teal px-4 py-3 text-sm font-semibold text-white shadow-lift">
        Mobile-first · SEO-ready
      </div>
    </div>
  );
}
