import Link from "next/link";
import { ArrowUpRight, Download, ExternalLink, FileText, FileSpreadsheet, Presentation, Image as ImageIcon, Video, Link2, Figma, Globe, Rocket } from "lucide-react";
import { Icon } from "@/components/icon";
import { CLASSIFICATION_LABELS, DEMO_TYPE_LABELS } from "@/lib/enquiry-config";
import { cn } from "@/lib/utils";

export function ServiceCard({ s }: { s: { slug: string; name: string; icon: string | null; summary: string | null; tagline: string | null } }) {
  return (
    <Link href={`/services/${s.slug}`} className="group card flex h-full flex-col p-6 transition hover:-translate-y-0.5 hover:border-brand/40 hover:shadow-lift">
      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand/15 to-teal/15 text-brand"><Icon name={s.icon} className="h-6 w-6" /></span>
      <h3 className="mt-5 text-lg font-bold">{s.name}</h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-ink-soft">{s.summary ?? s.tagline}</p>
      <span className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-brand">Learn more <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" /></span>
    </Link>
  );
}

export function ClassificationBadge({ value, className }: { value: string; className?: string }) {
  const tone: Record<string, string> = {
    client_project: "bg-teal/10 text-teal",
    internal_demo: "bg-brand/10 text-brand",
    uiux_concept: "bg-violet-100 text-violet-700",
    prototype: "bg-amber-100 text-amber-800",
    in_progress: "bg-slate-100 text-slate-700",
  };
  return <span className={cn("badge", tone[value] ?? "bg-slate-100 text-slate-700", className)}>{CLASSIFICATION_LABELS[value] ?? value}</span>;
}

type ProjectLite = {
  slug: string; title: string; summary: string | null; coverFileId: string | null; classification: string;
  clientName: string | null; clientNamePublic: boolean; industry?: { name: string } | null; projectType?: { name: string } | null;
};

export function ProjectCard({ p }: { p: ProjectLite }) {
  return (
    <Link href={`/portfolio/${p.slug}`} className="group card flex h-full flex-col overflow-hidden transition hover:-translate-y-0.5 hover:shadow-lift">
      <div className="relative aspect-[16/10] overflow-hidden bg-gradient-to-br from-navy to-brand">
        {p.coverFileId ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={`/api/files/${p.coverFileId}`} alt="" loading="lazy" className="h-full w-full object-cover object-top transition duration-500 group-hover:scale-[1.03]" />
        ) : (
          <div className="grid-bg flex h-full items-center justify-center p-6 text-center font-display text-lg font-bold text-white/90">{p.title}</div>
        )}
        <ClassificationBadge value={p.classification} className="absolute left-3 top-3 bg-white/95" />
      </div>
      <div className="flex flex-1 flex-col p-5">
        <p className="text-xs font-medium text-ink-muted">{[p.industry?.name, p.projectType?.name].filter(Boolean).join(" · ")}</p>
        <h3 className="mt-1 text-base font-bold leading-snug">{p.title}</h3>
        {p.summary && <p className="mt-2 line-clamp-2 text-sm text-ink-soft">{p.summary}</p>}
        <span className="mt-auto pt-4 text-sm font-semibold text-brand">View project →</span>
      </div>
    </Link>
  );
}

type DemoLite = { id: string; title: string; description: string | null; url: string; demoType: string; classification: string; previewFileId: string | null; technologies: string[]; industry?: { name: string } | null };

export function DemoCard({ d }: { d: DemoLite }) {
  const TypeIcon = d.demoType === "figma" ? Figma : d.demoType === "vercel" ? Rocket : d.demoType === "video" ? Video : Globe;
  return (
    <div className="card flex h-full flex-col overflow-hidden">
      <Link href={`/showcase/${d.id}`} className="group relative block aspect-[16/10] overflow-hidden bg-gradient-to-br from-navy via-navy to-teal">
        {d.previewFileId ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={`/api/files/${d.previewFileId}`} alt="" loading="lazy" className="h-full w-full object-cover object-top transition duration-500 group-hover:scale-[1.03]" />
        ) : (
          <div className="grid-bg flex h-full flex-col items-center justify-center gap-2 p-6 text-center text-white/90"><TypeIcon className="h-8 w-8" /><span className="font-display font-bold">{d.title}</span></div>
        )}
        <ClassificationBadge value={d.classification} className="absolute left-3 top-3 bg-white/95" />
      </Link>
      <div className="flex flex-1 flex-col p-5">
        <p className="flex items-center gap-1.5 text-xs font-medium text-ink-muted"><TypeIcon className="h-3.5 w-3.5" /> {DEMO_TYPE_LABELS[d.demoType]}{d.industry ? ` · ${d.industry.name}` : ""}</p>
        <h3 className="mt-1 text-base font-bold">{d.title}</h3>
        {d.description && <p className="mt-2 line-clamp-2 text-sm text-ink-soft">{d.description}</p>}
        {d.technologies.length > 0 && <div className="mt-3 flex flex-wrap gap-1.5">{d.technologies.slice(0, 4).map((x) => <span key={x} className="chip py-0.5">{x}</span>)}</div>}
        <div className="mt-auto flex gap-2 pt-4">
          <Link href={`/showcase/${d.id}`} className="btn-outline btn-sm flex-1">Preview</Link>
          <a href={d.url} target="_blank" rel="noopener noreferrer" className="btn-primary btn-sm flex-1">Open <ExternalLink className="h-3.5 w-3.5" /></a>
        </div>
      </div>
    </div>
  );
}

export function fileKindIcon(mime: string | null | undefined, kind: string) {
  if (kind === "figma") return Figma;
  if (kind === "vercel") return Rocket;
  if (kind === "website") return Globe;
  if (kind === "video_link") return Video;
  if (kind === "link") return Link2;
  if (!mime) return FileText;
  if (mime.includes("spreadsheet") || mime.includes("excel")) return FileSpreadsheet;
  if (mime.includes("presentation") || mime.includes("powerpoint")) return Presentation;
  if (mime.startsWith("image/")) return ImageIcon;
  if (mime.startsWith("video/")) return Video;
  return FileText;
}

export function fileTypeLabel(mime: string | null | undefined, kind: string) {
  if (kind !== "file") return { link: "Link", video_link: "Video", website: "Website", vercel: "Live demo", figma: "Prototype" }[kind] ?? "Link";
  if (!mime) return "File";
  if (mime === "application/pdf") return "PDF";
  if (mime.includes("word")) return "Word";
  if (mime.includes("presentation") || mime.includes("powerpoint")) return "PowerPoint";
  if (mime.includes("spreadsheet") || mime.includes("excel")) return "Excel";
  if (mime.startsWith("image/")) return "Image";
  if (mime.startsWith("video/")) return "Video";
  return "File";
}

type ResourceLite = {
  slug: string; title: string; description: string | null; kind: string; url: string | null; fileId: string | null; allowDownload: boolean;
  previewFileId: string | null; category?: { name: string } | null; file?: { mimeType: string } | null;
};

export function ResourceCard({ r }: { r: ResourceLite }) {
  const I = fileKindIcon(r.file?.mimeType, r.kind);
  return (
    <div className="card flex h-full flex-col p-5 transition hover:shadow-lift">
      <div className="flex items-start gap-4">
        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-surface text-brand ring-1 ring-line"><I className="h-6 w-6" /></span>
        <div className="min-w-0">
          <p className="text-xs font-medium text-ink-muted">{[r.category?.name, fileTypeLabel(r.file?.mimeType, r.kind)].filter(Boolean).join(" · ")}</p>
          <h3 className="mt-0.5 font-bold leading-snug"><Link href={`/resources/${r.slug}`} className="hover:text-brand">{r.title}</Link></h3>
        </div>
      </div>
      {r.description && <p className="mt-3 line-clamp-3 text-sm text-ink-soft">{r.description}</p>}
      <div className="mt-auto flex gap-2 pt-4">
        <Link href={`/resources/${r.slug}`} className="btn-outline btn-sm flex-1">{r.kind === "file" ? "Preview" : "Details"}</Link>
        {r.kind === "file" && r.fileId && r.allowDownload ? (
          <a href={`/api/files/${r.fileId}?download=1&r=${r.slug}`} className="btn-primary btn-sm flex-1"><Download className="h-3.5 w-3.5" /> Download</a>
        ) : r.url ? (
          <a href={r.url} target="_blank" rel="noopener noreferrer" className="btn-primary btn-sm flex-1">Open <ExternalLink className="h-3.5 w-3.5" /></a>
        ) : null}
      </div>
    </div>
  );
}

export function PageHero({ eyebrow, title, intro, children }: { eyebrow?: string; title: string; intro?: string | null; children?: React.ReactNode }) {
  return (
    <section className="relative overflow-hidden bg-navy text-white">
      <div className="grid-bg absolute inset-0 opacity-60" aria-hidden />
      <div className="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-teal/30 blur-3xl" aria-hidden />
      <div className="container relative py-14 sm:py-20">
        {eyebrow && <p className="eyebrow text-teal">{eyebrow}</p>}
        <h1 className="mt-3 max-w-3xl text-3xl font-extrabold text-white sm:text-5xl">{title}</h1>
        {intro && <p className="mt-4 max-w-2xl text-lg text-white/75">{intro}</p>}
        {children}
      </div>
    </section>
  );
}

export function EmptyState({ title, body, children }: { title: string; body?: string; children?: React.ReactNode }) {
  return (
    <div className="card flex flex-col items-center px-6 py-14 text-center">
      <div className="grid h-14 w-14 place-items-center rounded-2xl bg-surface text-brand ring-1 ring-line"><FileText className="h-6 w-6" /></div>
      <h3 className="mt-4 text-lg font-bold">{title}</h3>
      {body && <p className="mt-2 max-w-md text-sm text-ink-soft">{body}</p>}
      {children && <div className="mt-5 flex flex-wrap justify-center gap-2">{children}</div>}
    </div>
  );
}

export { ArrowUpRight };
