import { MessageCircle } from "lucide-react";
import { whatsappLink } from "@/lib/utils";

export function WhatsAppFab({ number, company }: { number: string; company: string }) {
  const href = whatsappLink(number, `Hello ${company}, I'd like to know more about your services.`);
  if (!href) return null;
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      className="fixed bottom-5 right-5 z-40 inline-flex h-14 items-center gap-2 rounded-full bg-[#25D366] px-5 font-semibold text-white shadow-lift transition hover:scale-105"
    >
      <MessageCircle className="h-6 w-6" /> <span className="hidden sm:inline">WhatsApp</span>
    </a>
  );
}
