"use client";
import { cn } from "@/lib/utils";

export function Field({ label, name, error, hint, required, children, className }: {
  label: string; name?: string; error?: string; hint?: string; required?: boolean; children: React.ReactNode; className?: string;
}) {
  return (
    <div className={className}>
      <label htmlFor={name} className="label">{label}{required && <span className="text-red-600"> *</span>}</label>
      {children}
      {error ? <p className="mt-1 text-xs font-medium text-red-600" role="alert">{error}</p> : hint ? <p className="hint">{hint}</p> : null}
    </div>
  );
}

export function TextInput({ id, value, onChange, error, ...rest }: { id: string; value: string; onChange: (v: string) => void; error?: string } & Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "id">) {
  return <input id={id} name={id} value={value} onChange={(e) => onChange(e.target.value)} aria-invalid={Boolean(error)} className={cn("input", error && "border-red-400 focus:border-red-500 focus:ring-red-500/15")} {...rest} />;
}

export function TextArea({ id, value, onChange, error, ...rest }: { id: string; value: string; onChange: (v: string) => void; error?: string } & Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, "value" | "onChange" | "id">) {
  return <textarea id={id} name={id} value={value} onChange={(e) => onChange(e.target.value)} aria-invalid={Boolean(error)} className={cn("input", error && "border-red-400")} {...rest} />;
}

export function SelectInput({ id, value, onChange, options, placeholder = "Select…", error }: { id: string; value: string; onChange: (v: string) => void; options: { value: string; label: string }[]; placeholder?: string; error?: string }) {
  return (
    <select id={id} name={id} value={value} onChange={(e) => onChange(e.target.value)} aria-invalid={Boolean(error)} className={cn("input", error && "border-red-400")}>
      <option value="">{placeholder}</option>
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}

export function ChoiceChips({ options, value, onChange, multiple = false, name }: { options: { value: string; label: string }[]; value: string[]; onChange: (v: string[]) => void; multiple?: boolean; name: string }) {
  return (
    <div className="flex flex-wrap gap-2" role={multiple ? "group" : "radiogroup"} aria-label={name}>
      {options.map((o) => {
        const on = value.includes(o.value);
        return (
          <button
            key={o.value}
            type="button"
            role={multiple ? "checkbox" : "radio"}
            aria-checked={on}
            onClick={() => onChange(multiple ? (on ? value.filter((v) => v !== o.value) : [...value, o.value]) : on ? [] : [o.value])}
            className={cn("min-h-[44px] rounded-xl border px-4 py-2 text-sm font-medium transition", on ? "border-brand bg-brand text-white shadow-sm" : "border-line bg-white text-ink-soft hover:border-brand/60")}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

export function newClientRef() {
  try {
    return crypto.randomUUID();
  } catch {
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
  }
}

export function loadDraft<T>(key: string): T | null {
  try {
    const v = window.localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : null;
  } catch {
    return null;
  }
}
export function saveDraft(key: string, value: unknown) {
  try { window.localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage unavailable */ }
}
export function clearDraft(key: string) {
  try { window.localStorage.removeItem(key); } catch { /* ignore */ }
}
