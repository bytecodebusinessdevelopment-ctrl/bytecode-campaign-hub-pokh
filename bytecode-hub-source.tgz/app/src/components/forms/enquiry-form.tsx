"use client";
import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import Link from "next/link";
import Script from "next/script";
import { ArrowLeft, ArrowRight, CheckCircle2, Loader2, ShieldCheck } from "lucide-react";
import { submitEnquiry } from "@/app/(public)/actions";
import { activeSets, CONTACT_METHODS, MEETING_PREFERENCES, TIMELINES, type Question } from "@/lib/enquiry-config";
import { isValidPhone, cn } from "@/lib/utils";
import { readAttribution, trackLead } from "@/components/public/tracking";
import { Field, TextInput, TextArea, SelectInput, ChoiceChips, newClientRef, loadDraft, saveDraft, clearDraft } from "@/components/forms/fields";

type Opt = { id: string; key?: string; label?: string; name?: string };
type Props = {
  services: { id: string; key: string; label: string }[];
  industries: { id: string; name: string }[];
  budgets: { id: string; label: string }[];
  formToken: string;
  preselectKeys: string[];
  packageName?: string | null;
  turnstileSiteKey?: string;
};

type State = {
  serviceIds: string[];
  business: { name: string; industryId: string; location: string; address: string; website: string; facebook: string; instagram: string; otherLinks: string };
  contact: { fullName: string; designation: string; phone: string; whatsapp: string; email: string; sameWhatsapp: boolean };
  answers: Record<string, Record<string, string>>;
  requirements: string;
  budgetRangeId: string;
  budgetCustom: string;
  timeline: string;
  preferredContactMethod: string;
  meetingPreference: string;
  comments: string;
  consent: boolean;
  clientRef: string;
};

const DRAFT_KEY = "bc_enquiry_draft_v1";
const STEPS = ["Services", "Business", "Contact", "Requirements", "Budget & timeline", "Review"];

const empty = (): State => ({
  serviceIds: [],
  business: { name: "", industryId: "", location: "", address: "", website: "", facebook: "", instagram: "", otherLinks: "" },
  contact: { fullName: "", designation: "", phone: "", whatsapp: "", email: "", sameWhatsapp: true },
  answers: {},
  requirements: "",
  budgetRangeId: "",
  budgetCustom: "",
  timeline: "",
  preferredContactMethod: "",
  meetingPreference: "",
  comments: "",
  consent: false,
  clientRef: "",
});

export function EnquiryForm({ services, industries, budgets, formToken, preselectKeys, packageName, turnstileSiteKey }: Props) {
  const [s, setS] = useState<State>(empty);
  const [step, setStep] = useState(0);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const [hp, setHp] = useState("");
  const [restored, setRestored] = useState(false);
  const [touched, setTouched] = useState(false);
  const topRef = useRef<HTMLDivElement>(null);
  const turnstileRef = useRef<string | null>(null);

  // Restore an unsent draft (protects against dropped mobile connections / accidental refresh).
  useEffect(() => {
    const draft = loadDraft<{ s: State; step: number }>(DRAFT_KEY);
    const pre = services.filter((x) => preselectKeys.includes(x.key)).map((x) => x.id);
    if (draft?.s?.clientRef) {
      // Keep the visitor's earlier answers, but still honour a service chosen from the page they came from.
      setS({ ...draft.s, serviceIds: [...new Set([...draft.s.serviceIds, ...pre])] });
      setStep(Math.min(draft.step ?? 0, STEPS.length - 1));
      setRestored(true);
    } else {
      setS((p) => ({ ...p, clientRef: newClientRef(), serviceIds: pre, comments: packageName ? `Interested in package: ${packageName}` : p.comments }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  // Only keep a draft once the visitor has actually entered something.
  useEffect(() => { if (touched && s.clientRef && !done) saveDraft(DRAFT_KEY, { s, step }); }, [s, step, done, touched]);

  const selectedKeys = useMemo(() => services.filter((x) => s.serviceIds.includes(x.id)).map((x) => x.key), [services, s.serviceIds]);
  const sets = useMemo(() => activeSets(selectedKeys), [selectedKeys]);

  const setBiz = (k: keyof State["business"], v: string) => { setTouched(true); setS((p) => ({ ...p, business: { ...p.business, [k]: v } })); };
  const setCon = (k: keyof State["contact"], v: string | boolean) => { setTouched(true); setS((p) => ({ ...p, contact: { ...p.contact, [k]: v } })); };
  const setAns = (set: string, q: string, v: string) => { setTouched(true); setS((p) => ({ ...p, answers: { ...p.answers, [set]: { ...(p.answers[set] ?? {}), [q]: v } } })); };

  function validate(i: number) {
    const e: Record<string, string> = {};
    if (i === 0 && !s.serviceIds.length) e.serviceIds = "Please choose at least one service.";
    if (i === 1) {
      if (s.business.name.trim().length < 2) e["business.name"] = "Business name is required.";
      if (s.business.location.trim().length < 2) e["business.location"] = "Location is required.";
    }
    if (i === 2) {
      if (s.contact.fullName.trim().length < 2) e["contact.fullName"] = "Your name is required.";
      if (!isValidPhone(s.contact.phone)) e["contact.phone"] = "Enter a valid phone number, e.g. 98XXXXXXXX or +977…";
      if (!s.contact.sameWhatsapp && s.contact.whatsapp && !isValidPhone(s.contact.whatsapp)) e["contact.whatsapp"] = "Enter a valid WhatsApp number.";
      if (s.contact.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.contact.email)) e["contact.email"] = "Enter a valid email address.";
    }
    if (i === 3 && s.requirements.trim().length < 10) e.requirements = "Please describe your requirements in a sentence or two.";
    if (i === 5 && !s.consent) e.consent = "Please agree so we can contact you.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  const go = (next: number) => {
    if (next > step && !validate(step)) return;
    setStep(next);
    setServerError(null);
    topRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const submit = () => {
    if (!validate(5)) return;
    setServerError(null);
    start(async () => {
      const attr = readAttribution();
      try {
        const res = await submitEnquiry({
          business: s.business,
          contact: { ...s.contact, whatsapp: s.contact.sameWhatsapp ? s.contact.phone : s.contact.whatsapp },
          serviceIds: s.serviceIds,
          answers: Object.fromEntries(sets.map((set) => [set.key, s.answers[set.key] ?? {}])),
          requirements: s.requirements,
          budgetRangeId: s.budgetRangeId === "custom" ? "" : s.budgetRangeId,
          budgetCustom: s.budgetRangeId === "custom" ? s.budgetCustom : s.budgetRangeId === "undecided" ? "Not yet decided" : "",
          timeline: s.timeline,
          preferredContactMethod: s.preferredContactMethod,
          meetingPreference: s.meetingPreference,
          comments: s.comments,
          consent: s.consent as true,
          clientRef: s.clientRef,
          attribution: attr ? { utm: attr.utm, referrer: attr.referrer, landingPage: attr.landingPage } : null,
          formToken,
          hp,
          turnstileToken: turnstileRef.current,
        });
        if (res.ok) {
          clearDraft(DRAFT_KEY);
          setDone(res.leadCode);
          trackLead();
          topRef.current?.scrollIntoView({ behavior: "smooth" });
        } else {
          setServerError(res.error);
          if (res.fieldErrors) setErrors(res.fieldErrors);
        }
      } catch {
        setServerError("We couldn't reach the server — please check your connection and press Submit again. Your answers are saved on this device.");
      }
    });
  };

  if (done) {
    return (
      <div ref={topRef} className="card p-8 text-center sm:p-12">
        <CheckCircle2 className="mx-auto h-14 w-14 text-teal" />
        <h2 className="mt-4 text-2xl font-extrabold">Thank you — we&apos;ve received your enquiry.</h2>
        {done !== "RECEIVED" && <p className="mt-3 text-ink-soft">Your reference number is <span className="font-mono text-lg font-bold text-navy">{done}</span></p>}
        <p className="mx-auto mt-3 max-w-md text-ink-soft">A member of our team will review your requirements and contact you{s.preferredContactMethod ? ` by ${s.preferredContactMethod.toLowerCase()}` : ""} soon.{s.contact.email ? " We've also sent a confirmation to your email." : ""}</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3"><Link href="/portfolio" className="btn-outline">Explore our work</Link><Link href="/" className="btn-primary">Back to home</Link></div>
      </div>
    );
  }

  const answer = (set: string, q: Question) => {
    const v = s.answers[set]?.[q.key] ?? "";
    const id = `${set}-${q.key}`;
    if (q.type === "textarea") return <TextArea id={id} value={v} onChange={(x) => setAns(set, q.key, x)} placeholder={q.placeholder} rows={3} />;
    if (q.type === "select") return <SelectInput id={id} value={v} onChange={(x) => setAns(set, q.key, x)} options={q.options!.map((o) => ({ value: o, label: o }))} />;
    if (q.type === "yesno") return <ChoiceChips name={q.label} value={v ? [v] : []} onChange={(x) => setAns(set, q.key, x[0] ?? "")} options={[{ value: "Yes", label: "Yes" }, { value: "No", label: "No" }, { value: "Not sure", label: "Not sure" }]} />;
    return <TextInput id={id} value={v} onChange={(x) => setAns(set, q.key, x)} placeholder={q.placeholder} />;
  };

  return (
    <div ref={topRef} className="scroll-mt-24">
      {turnstileSiteKey && <Script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer />}
      {/* Progress indicator */}
      <ol className="mb-6 grid grid-cols-6 gap-1.5" aria-label="Progress">
        {STEPS.map((label, i) => (
          <li key={label} className="min-w-0">
            <button type="button" onClick={() => i < step && go(i)} disabled={i >= step} className="w-full text-left disabled:cursor-default" aria-current={i === step ? "step" : undefined}>
              <span className={cn("block h-1.5 rounded-full transition", i <= step ? "bg-brand" : "bg-line")} />
              <span className={cn("mt-2 hidden truncate text-xs font-medium sm:block", i === step ? "text-navy" : "text-ink-muted")}>{label}</span>
            </button>
          </li>
        ))}
      </ol>
      <p className="mb-4 text-sm text-ink-muted sm:hidden">Step {step + 1} of {STEPS.length}: <span className="font-semibold text-navy">{STEPS[step]}</span></p>
      {restored && step < 5 && <p className="mb-4 rounded-xl bg-brand/5 px-4 py-2 text-sm text-brand">We restored the details you entered earlier on this device. <button type="button" className="underline" onClick={() => { clearDraft(DRAFT_KEY); setS({ ...empty(), clientRef: newClientRef() }); setStep(0); setRestored(false); }}>Start over</button></p>}

      <div className="card p-5 sm:p-8">
        {/* Honeypot — hidden from humans */}
        <div aria-hidden className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
          <label>Leave this field empty<input tabIndex={-1} autoComplete="off" value={hp} onChange={(e) => setHp(e.target.value)} name="company_url_confirm" /></label>
        </div>

        {step === 0 && (
          <section>
            <h2 className="text-xl font-bold">What can we help you with?</h2>
            <p className="mt-1 text-sm text-ink-soft">Choose all that apply — we&apos;ll only ask the questions relevant to your selection.</p>
            <div className="mt-6"><ChoiceChips name="Interested services" multiple value={s.serviceIds} onChange={(v) => { setTouched(true); setS((p) => ({ ...p, serviceIds: v })); }} options={services.map((x) => ({ value: x.id, label: x.label }))} /></div>
            {errors.serviceIds && <p className="mt-3 text-sm font-medium text-red-600" role="alert">{errors.serviceIds}</p>}
          </section>
        )}

        {step === 1 && (
          <section className="grid gap-5 sm:grid-cols-2">
            <h2 className="text-xl font-bold sm:col-span-2">About your business</h2>
            <Field label="Business name" name="b-name" required error={errors["business.name"]} className="sm:col-span-2"><TextInput id="b-name" value={s.business.name} onChange={(v) => setBiz("name", v)} autoComplete="organization" error={errors["business.name"]} /></Field>
            <Field label="Industry" name="b-industry"><SelectInput id="b-industry" value={s.business.industryId} onChange={(v) => setBiz("industryId", v)} options={industries.map((i) => ({ value: i.id, label: i.name }))} /></Field>
            <Field label="Location (city / area)" name="b-loc" required error={errors["business.location"]}><TextInput id="b-loc" value={s.business.location} onChange={(v) => setBiz("location", v)} placeholder="e.g. Lakeside, Pokhara" error={errors["business.location"]} /></Field>
            <Field label="Business address" name="b-addr" className="sm:col-span-2"><TextInput id="b-addr" value={s.business.address} onChange={(v) => setBiz("address", v)} autoComplete="street-address" /></Field>
            <Field label="Website" name="b-web"><TextInput id="b-web" value={s.business.website} onChange={(v) => setBiz("website", v)} placeholder="www.example.com" inputMode="url" /></Field>
            <Field label="Facebook page" name="b-fb"><TextInput id="b-fb" value={s.business.facebook} onChange={(v) => setBiz("facebook", v)} placeholder="facebook.com/yourpage" /></Field>
            <Field label="Instagram" name="b-ig"><TextInput id="b-ig" value={s.business.instagram} onChange={(v) => setBiz("instagram", v)} placeholder="@yourbusiness" /></Field>
            <Field label="Other relevant links" name="b-other"><TextInput id="b-other" value={s.business.otherLinks} onChange={(v) => setBiz("otherLinks", v)} placeholder="TripAdvisor, Google Maps, Daraz…" /></Field>
          </section>
        )}

        {step === 2 && (
          <section className="grid gap-5 sm:grid-cols-2">
            <h2 className="text-xl font-bold sm:col-span-2">Contact person</h2>
            <Field label="Full name" name="c-name" required error={errors["contact.fullName"]}><TextInput id="c-name" value={s.contact.fullName} onChange={(v) => setCon("fullName", v)} autoComplete="name" error={errors["contact.fullName"]} /></Field>
            <Field label="Designation" name="c-des"><TextInput id="c-des" value={s.contact.designation} onChange={(v) => setCon("designation", v)} placeholder="e.g. Owner, Marketing Manager" /></Field>
            <Field label="Phone" name="c-phone" required error={errors["contact.phone"]} hint="Nepali mobile/landline or international (+country code)"><TextInput id="c-phone" type="tel" value={s.contact.phone} onChange={(v) => setCon("phone", v)} autoComplete="tel" inputMode="tel" placeholder="98XXXXXXXX" error={errors["contact.phone"]} /></Field>
            <Field label="Email" name="c-email" error={errors["contact.email"]}><TextInput id="c-email" type="email" value={s.contact.email} onChange={(v) => setCon("email", v)} autoComplete="email" inputMode="email" error={errors["contact.email"]} /></Field>
            <div className="sm:col-span-2">
              <label className="flex items-center gap-3 text-sm text-ink-soft"><input type="checkbox" className="check" checked={s.contact.sameWhatsapp} onChange={(e) => setCon("sameWhatsapp", e.target.checked)} /> My WhatsApp number is the same as my phone number</label>
            </div>
            {!s.contact.sameWhatsapp && (
              <Field label="WhatsApp number" name="c-wa" error={errors["contact.whatsapp"]}><TextInput id="c-wa" type="tel" value={s.contact.whatsapp} onChange={(v) => setCon("whatsapp", v)} inputMode="tel" error={errors["contact.whatsapp"]} /></Field>
            )}
          </section>
        )}

        {step === 3 && (
          <section className="space-y-8">
            <div>
              <h2 className="text-xl font-bold">Your requirements</h2>
              <p className="mt-1 text-sm text-ink-soft">What problems is your business trying to solve, and what outcomes do you expect?</p>
              <div className="mt-4"><Field label="Describe your requirements" name="req" required error={errors.requirements}><TextArea id="req" value={s.requirements} onChange={(v) => { setTouched(true); setS((p) => ({ ...p, requirements: v })); }} rows={5} placeholder="e.g. We want more direct bookings from international trekkers instead of relying on OTAs…" error={errors.requirements} /></Field></div>
            </div>
            {sets.map((set) => (
              <fieldset key={set.key} className="rounded-2xl border border-line p-5">
                <legend className="px-2 font-display text-base font-bold text-navy">{set.title}</legend>
                <div className="grid gap-5 sm:grid-cols-2">
                  {set.questions.map((q) => (
                    <Field key={q.key} label={q.label} name={`${set.key}-${q.key}`} className={q.type === "textarea" || q.type === "yesno" ? "sm:col-span-2" : ""}>{answer(set.key, q)}</Field>
                  ))}
                </div>
              </fieldset>
            ))}
          </section>
        )}

        {step === 4 && (
          <section className="space-y-6">
            <h2 className="text-xl font-bold">Budget & timeline</h2>
            <Field label="Approximate budget (NPR)" name="budget">
              <ChoiceChips name="Budget" value={s.budgetRangeId ? [s.budgetRangeId] : []} onChange={(v) => setS((p) => ({ ...p, budgetRangeId: v[0] ?? "" }))} options={[...budgets.map((b) => ({ value: b.id, label: b.label })), { value: "undecided", label: "Not yet decided" }, { value: "custom", label: "Enter my own" }]} />
            </Field>
            {s.budgetRangeId === "custom" && <Field label="Your budget" name="budget-custom"><TextInput id="budget-custom" value={s.budgetCustom} onChange={(v) => setS((p) => ({ ...p, budgetCustom: v }))} placeholder="e.g. Rs. 75,000" /></Field>}
            <Field label="When would you like to start?" name="timeline">
              <ChoiceChips name="Timeline" value={s.timeline ? [s.timeline] : []} onChange={(v) => setS((p) => ({ ...p, timeline: v[0] ?? "" }))} options={TIMELINES.map((x) => ({ value: x, label: x }))} />
            </Field>
          </section>
        )}

        {step === 5 && (
          <section className="space-y-6">
            <h2 className="text-xl font-bold">Almost done</h2>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Preferred communication method" name="pcm"><SelectInput id="pcm" value={s.preferredContactMethod} onChange={(v) => setS((p) => ({ ...p, preferredContactMethod: v }))} options={CONTACT_METHODS.map((x) => ({ value: x, label: x }))} /></Field>
              <Field label="Meeting preference" name="mp"><SelectInput id="mp" value={s.meetingPreference} onChange={(v) => setS((p) => ({ ...p, meetingPreference: v }))} options={MEETING_PREFERENCES.map((x) => ({ value: x, label: x }))} /></Field>
              <Field label="Additional comments" name="cm" className="sm:col-span-2"><TextArea id="cm" value={s.comments} onChange={(v) => setS((p) => ({ ...p, comments: v }))} rows={3} /></Field>
            </div>
            <div className="rounded-2xl bg-surface p-5 text-sm">
              <p className="font-semibold text-navy">Summary</p>
              <dl className="mt-3 grid gap-x-6 gap-y-2 sm:grid-cols-2">
                <Row k="Business" v={`${s.business.name}${s.business.location ? `, ${s.business.location}` : ""}`} />
                <Row k="Contact" v={`${s.contact.fullName} · ${s.contact.phone}`} />
                <Row k="Services" v={services.filter((x) => s.serviceIds.includes(x.id)).map((x) => x.label).join(", ")} />
                <Row k="Timeline" v={s.timeline || "—"} />
              </dl>
            </div>
            <label className={cn("flex items-start gap-3 rounded-2xl border p-4 text-sm", errors.consent ? "border-red-400 bg-red-50" : "border-line")}>
              <input type="checkbox" className="check mt-0.5" checked={s.consent} onChange={(e) => setS((p) => ({ ...p, consent: e.target.checked }))} />
              <span className="text-ink-soft">I agree to ByteCode Developers storing the information I have submitted and contacting me about this enquiry, as described in the <Link href="/privacy" target="_blank" className="font-medium text-brand underline">Privacy Policy</Link>. <span className="text-red-600">*</span></span>
            </label>
            {errors.consent && <p className="text-sm font-medium text-red-600" role="alert">{errors.consent}</p>}
            {turnstileSiteKey && (
              <div className="cf-turnstile" data-sitekey={turnstileSiteKey} data-callback="bcTurnstile" ref={() => { (window as unknown as Record<string, unknown>).bcTurnstile = (tok: string) => { turnstileRef.current = tok; }; }} />
            )}
            <p className="flex items-center gap-2 text-xs text-ink-muted"><ShieldCheck className="h-4 w-4 text-teal" /> Your information is stored securely and only shared with the ByteCode team.</p>
          </section>
        )}

        {serverError && <p className="mt-6 rounded-xl bg-red-50 px-4 py-3 text-sm font-medium text-red-700" role="alert">{serverError}</p>}

        <div className="mt-8 flex items-center justify-between gap-3 border-t border-line pt-6">
          {step > 0 ? <button type="button" onClick={() => go(step - 1)} className="btn-ghost"><ArrowLeft className="h-4 w-4" /> Back</button> : <span />}
          {step < STEPS.length - 1 ? (
            <button type="button" onClick={() => go(step + 1)} className="btn-primary">Continue <ArrowRight className="h-4 w-4" /></button>
          ) : (
            <button type="button" onClick={submit} disabled={pending} className="btn-accent">{pending ? <><Loader2 className="h-4 w-4 animate-spin" /> Sending…</> : <>Submit enquiry <ArrowRight className="h-4 w-4" /></>}</button>
          )}
        </div>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex gap-2"><dt className="w-20 shrink-0 text-ink-muted">{k}</dt><dd className="text-navy">{v || "—"}</dd></div>;
}

export type { Opt };
