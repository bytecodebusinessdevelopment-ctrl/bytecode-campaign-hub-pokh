"use client";
import { useEffect, useState, useTransition } from "react";
import Link from "next/link";
import { CheckCircle2, Loader2 } from "lucide-react";
import { submitContact } from "@/app/(public)/actions";
import { Field, TextInput, TextArea, newClientRef } from "@/components/forms/fields";
import { readAttribution, trackLead } from "@/components/public/tracking";

export function ContactForm({ formToken }: { formToken: string }) {
  const [f, setF] = useState({ name: "", business: "", phone: "", email: "", message: "", consent: false });
  const [ref, setRef] = useState("");
  const [hp, setHp] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const [pending, start] = useTransition();
  useEffect(() => setRef(newClientRef()), []);
  const set = (k: keyof typeof f, v: string | boolean) => setF((p) => ({ ...p, [k]: v }));

  if (done) return (
    <div className="card p-8 text-center"><CheckCircle2 className="mx-auto h-12 w-12 text-teal" /><h2 className="mt-3 text-xl font-bold">Message sent</h2>{done !== "RECEIVED" && <p className="mt-2 text-ink-soft">Reference: <span className="font-mono font-bold text-navy">{done}</span></p>}<p className="mt-2 text-ink-soft">We&apos;ll get back to you soon.</p></div>
  );

  return (
    <form
      className="card grid gap-5 p-6 sm:grid-cols-2 sm:p-8"
      onSubmit={(e) => {
        e.preventDefault();
        setMsg(null);
        start(async () => {
          const attr = readAttribution();
          const res = await submitContact({ ...f, clientRef: ref, formToken, hp, attribution: attr ? { utm: attr.utm, referrer: attr.referrer, landingPage: attr.landingPage } : null });
          if (res.ok) { setDone(res.leadCode); trackLead(); } else { setMsg(res.error); setErrors(res.fieldErrors ?? {}); }
        });
      }}
    >
      <div aria-hidden className="absolute -left-[9999px] h-0 w-0 overflow-hidden"><input tabIndex={-1} autoComplete="off" value={hp} onChange={(e) => setHp(e.target.value)} name="company_url_confirm" /></div>
      <Field label="Your name" name="cf-name" required error={errors.name}><TextInput id="cf-name" value={f.name} onChange={(v) => set("name", v)} autoComplete="name" error={errors.name} /></Field>
      <Field label="Business name" name="cf-biz" required error={errors.business}><TextInput id="cf-biz" value={f.business} onChange={(v) => set("business", v)} autoComplete="organization" error={errors.business} /></Field>
      <Field label="Phone" name="cf-phone" required error={errors.phone}><TextInput id="cf-phone" type="tel" value={f.phone} onChange={(v) => set("phone", v)} autoComplete="tel" inputMode="tel" error={errors.phone} /></Field>
      <Field label="Email" name="cf-email" error={errors.email}><TextInput id="cf-email" type="email" value={f.email} onChange={(v) => set("email", v)} autoComplete="email" error={errors.email} /></Field>
      <Field label="Message" name="cf-msg" required error={errors.message} className="sm:col-span-2"><TextArea id="cf-msg" value={f.message} onChange={(v) => set("message", v)} rows={4} error={errors.message} /></Field>
      <label className="flex items-start gap-3 text-sm text-ink-soft sm:col-span-2"><input type="checkbox" className="check mt-0.5" checked={f.consent} onChange={(e) => set("consent", e.target.checked)} /> <span>I agree to ByteCode Developers storing my details and contacting me about this message (<Link href="/privacy" className="text-brand underline">Privacy Policy</Link>).</span></label>
      {errors.consent && <p className="text-sm text-red-600 sm:col-span-2">{errors.consent}</p>}
      {msg && <p className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700 sm:col-span-2" role="alert">{msg}</p>}
      <div className="sm:col-span-2"><button className="btn-primary" disabled={pending}>{pending && <Loader2 className="h-4 w-4 animate-spin" />} Send message</button></div>
    </form>
  );
}
