"use client";
import { useActionState, useEffect, useRef } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

type State = { ok?: boolean; error?: string; message?: string; fieldErrors?: Record<string, string> } | null;
type Action = (prev: State, fd: FormData) => Promise<State>;

export function ActionForm({ action, children, className, resetOnSuccess = false, refresh = true, id }: {
  action: Action; children: React.ReactNode; className?: string; resetOnSuccess?: boolean; refresh?: boolean; id?: string;
}) {
  const [state, formAction] = useActionState(action, null);
  const ref = useRef<HTMLFormElement>(null);
  const snapshot = useRef<[string, string][] | null>(null);
  const router = useRouter();
  useEffect(() => {
    if (state?.ok) {
      if (resetOnSuccess) ref.current?.reset();
      if (refresh) router.refresh();
    }
    // React resets forms after an action completes — on error, restore what the user typed.
    if (state?.error && snapshot.current && ref.current) restoreForm(ref.current, snapshot.current);
  }, [state, resetOnSuccess, refresh, router]);
  return (
    <form ref={ref} action={(fd) => { snapshot.current = [...fd.entries()].filter(([, v]) => typeof v === "string") as [string, string][]; return formAction(fd); }} className={className} id={id}>
      {children}
      <FormMessage state={state} />
    </form>
  );
}

function restoreForm(form: HTMLFormElement, entries: [string, string][]) {
  const byName = new Map<string, string[]>();
  for (const [k, v] of entries) byName.set(k, [...(byName.get(k) ?? []), v]);
  form.querySelectorAll<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>("[name]").forEach((el) => {
    const vals = byName.get(el.name) ?? [];
    if (el instanceof HTMLInputElement && (el.type === "checkbox" || el.type === "radio")) el.checked = vals.includes(el.value);
    else if (el instanceof HTMLInputElement && (el.type === "hidden" || el.type === "file")) return;
    else if (el instanceof HTMLSelectElement && el.multiple) Array.from(el.options).forEach((o) => { o.selected = vals.includes(o.value); });
    else if (vals.length) el.value = vals[0];
  });
}

export function FormMessage({ state }: { state: State }) {
  if (!state) return null;
  if (state.error)
    return (
      <div className="col-span-full mt-3 flex items-start gap-2 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700" role="alert">
        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
        <div>{state.error}{state.fieldErrors && <ul className="mt-1 list-disc pl-4">{Object.entries(state.fieldErrors).map(([k, v]) => <li key={k}>{v}</li>)}</ul>}</div>
      </div>
    );
  if (state.ok && state.message)
    return <div className="col-span-full mt-3 flex items-center gap-2 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800" role="status"><CheckCircle2 className="h-4 w-4" /> {state.message}</div>;
  return null;
}

export function SubmitButton({ children, className = "btn-primary", confirm: confirmText, name, value }: { children: React.ReactNode; className?: string; confirm?: string; name?: string; value?: string }) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      name={name}
      value={value}
      disabled={pending}
      className={className}
      onClick={(e) => { if (confirmText && !window.confirm(confirmText)) e.preventDefault(); }}
    >
      {pending && <Loader2 className="h-4 w-4 animate-spin" />} {children}
    </button>
  );
}

export function Badge({ color, children, className }: { color?: string | null; children: React.ReactNode; className?: string }) {
  return (
    <span className={cn("badge whitespace-nowrap", className)} style={color ? { backgroundColor: `${color}1a`, color } : undefined}>{children}</span>
  );
}
