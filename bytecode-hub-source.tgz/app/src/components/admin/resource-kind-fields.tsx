"use client";
import { useState } from "react";

/** Shows the file uploader for "file" resources, otherwise a URL field. */
export function ResourceKindFields({ kinds, initialKind, initialUrl, fileSlot }: { kinds: [string, string][]; initialKind: string; initialUrl: string; fileSlot: React.ReactNode }) {
  const [kind, setKind] = useState(initialKind);
  return (
    <>
      <label className="block"><span className="label">Resource type</span>
        <select name="kind" value={kind} onChange={(e) => setKind(e.target.value)} className="input">{kinds.map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
      </label>
      <div className="sm:col-span-2">
        <div className={kind === "file" ? "" : "hidden"}>{fileSlot}</div>
        {kind !== "file" && <label className="block"><span className="label">URL *</span><input name="url" defaultValue={initialUrl} placeholder="https://…" className="input" /></label>}
      </div>
    </>
  );
}
