import Link from "next/link";

/**
 * Lightweight, dependency-free charts (single-series, one hue → no legend needed; the title names the series).
 * Thin bars with rounded data-ends, recessive gridlines, direct value labels, and a hover tooltip per mark.
 * Each chart also renders as an accessible list so values are never conveyed by colour/length alone.
 */

type Datum = { label: string; value: number; href?: string; color?: string | null };

export function HBarChart({ data, empty = "No data yet", max: maxProp, valueSuffix = "" }: { data: Datum[]; empty?: string; max?: number; valueSuffix?: string }) {
  if (!data.length || data.every((d) => !d.value)) return <p className="py-6 text-center text-sm text-ink-muted">{empty}</p>;
  const max = maxProp ?? Math.max(...data.map((d) => d.value), 1);
  return (
    <ul className="space-y-2.5" role="list">
      {data.map((d) => {
        const pct = Math.max(d.value ? 2 : 0, (d.value / max) * 100);
        const inner = (
          <div className="group grid grid-cols-[minmax(0,9rem)_1fr_auto] items-center gap-3 sm:grid-cols-[minmax(0,11rem)_1fr_auto]" title={`${d.label}: ${d.value}${valueSuffix}`}>
            <span className="truncate text-sm text-ink-soft">{d.label}</span>
            <span className="relative h-2.5 rounded-full bg-surface">
              <span className="absolute inset-y-0 left-0 rounded-r-[4px] transition-all group-hover:brightness-110" style={{ width: `${pct}%`, backgroundColor: d.color ?? "rgb(var(--brand-blue))" }} />
            </span>
            <span className="min-w-8 text-right text-sm font-semibold tabular-nums text-navy">{d.value}{valueSuffix}</span>
          </div>
        );
        return <li key={d.label}>{d.href ? <Link href={d.href} className="block rounded-lg hover:bg-surface/60">{inner}</Link> : inner}</li>;
      })}
    </ul>
  );
}

export function ColumnChart({ data, height = 160, label = "Leads" }: { data: Datum[]; height?: number; label?: string }) {
  const peak = Math.max(...data.map((d) => d.value), 1);
  // Round the axis up to a "nice" number so ticks are whole and distinct.
  const niceMax = (n: number) => {
    if (n <= 4) return n;
    const p = 10 ** Math.floor(Math.log10(n));
    const m = n / p;
    return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 5 ? 5 : 10) * p;
  };
  const max = niceMax(peak);
  const ticks = max <= 4 ? Array.from({ length: max + 1 }, (_, i) => max - i) : [max, Math.round(max / 2), 0];
  return (
    <div>
      <div className="relative flex gap-1.5 pl-7" style={{ height }}>
        <div className="pointer-events-none absolute inset-y-0 left-0 flex w-full flex-col justify-between" aria-hidden>
          {ticks.map((tk, i) => (
            <div key={i} className="flex items-center gap-2"><span className="w-5 text-right text-[10px] tabular-nums text-ink-muted">{tk}</span><span className="h-px flex-1 bg-line/70" /></div>
          ))}
        </div>
        {data.map((d) => (
          <div key={d.label} className="group relative flex flex-1 flex-col justify-end">
            <div className="mx-auto w-full max-w-[22px] rounded-t-[4px] bg-brand transition group-hover:bg-navy" style={{ height: `${(d.value / max) * 100}%`, minHeight: d.value ? 3 : 0 }} />
            <div className="pointer-events-none absolute -top-8 left-1/2 z-10 hidden -translate-x-1/2 whitespace-nowrap rounded-lg bg-navy px-2 py-1 text-xs text-white shadow-lift group-hover:block">
              {d.label}: <strong>{d.value}</strong> {label.toLowerCase()}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-1.5 pl-7 text-[10px] text-ink-muted">
        {data.map((d, i) => <span key={d.label} className="relative flex-1 text-center"><span className={`absolute left-1/2 -translate-x-1/2 whitespace-nowrap ${i % 3 === 0 ? "" : "hidden"}`}>{d.label}</span>&nbsp;</span>)}
      </div>
      <table className="sr-only"><caption>{label} per week</caption><tbody>{data.map((d) => <tr key={d.label}><th>{d.label}</th><td>{d.value}</td></tr>)}</tbody></table>
    </div>
  );
}

export function FunnelChart({ rows }: { rows: { name: string; reached: number; current: number; is_lost: boolean; is_won: boolean }[] }) {
  const top = Math.max(rows[0]?.reached ?? 0, 1);
  return (
    <div className="space-y-2">
      {rows.filter((r) => !r.is_lost).map((r, i, arr) => {
        const prev = i > 0 ? arr[i - 1].reached : null;
        const step = prev ? Math.round((r.reached / prev) * 100) : null;
        return (
          <div key={r.name} className="grid grid-cols-[8.5rem_1fr_auto] items-center gap-3" title={`${r.name}: ${r.reached} reached, ${r.current} currently here`}>
            <span className="truncate text-sm text-ink-soft">{r.name}</span>
            <span className="relative h-7 rounded-lg bg-surface">
              <span className="absolute inset-y-0 left-0 rounded-lg" style={{ width: `${Math.max(r.reached ? 2 : 0, (r.reached / top) * 100)}%`, backgroundColor: r.is_won ? "rgb(var(--brand-teal))" : "rgb(var(--brand-blue))", opacity: 1 - i * 0.07 }} />
            </span>
            <span className="w-24 text-right text-sm tabular-nums"><strong className="text-navy">{r.reached}</strong>{step !== null && <span className="ml-1 text-xs text-ink-muted">({step}%)</span>}</span>
          </div>
        );
      })}
    </div>
  );
}
