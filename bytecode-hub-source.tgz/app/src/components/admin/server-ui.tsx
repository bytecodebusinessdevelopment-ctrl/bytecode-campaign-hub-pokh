import Link from "next/link";
import { cn } from "@/lib/utils";

export function PageHeader({ title, subtitle, actions, back }: { title: string; subtitle?: React.ReactNode; actions?: React.ReactNode; back?: { href: string; label: string } }) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="min-w-0">
        {back && <Link href={back.href} className="text-sm text-ink-muted hover:text-brand">← {back.label}</Link>}
        <h1 className="mt-1 truncate text-2xl font-extrabold sm:text-3xl">{title}</h1>
        {subtitle && <div className="mt-1 text-sm text-ink-muted">{subtitle}</div>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Stat({ label, value, hint, tone = "default", href }: { label: string; value: React.ReactNode; hint?: React.ReactNode; tone?: "default" | "good" | "warn" | "bad"; href?: string }) {
  const body = (
    <div className={cn("card h-full p-4 transition", href && "hover:border-brand/40 hover:shadow-lift")}>
      <p className="text-xs font-semibold uppercase tracking-wide text-ink-muted">{label}</p>
      <p className={cn("mt-2 font-display text-2xl font-extrabold tabular-nums sm:text-3xl", tone === "good" && "text-emerald-600", tone === "warn" && "text-amber-600", tone === "bad" && "text-red-600", tone === "default" && "text-navy")}>{value}</p>
      {hint && <p className="mt-1 text-xs text-ink-muted">{hint}</p>}
    </div>
  );
  return href ? <Link href={href}>{body}</Link> : body;
}

export function Tabs({ tabs, current }: { tabs: { href: string; label: string; key: string; count?: number }[]; current: string }) {
  return (
    <div className="mb-6 flex gap-1 overflow-x-auto border-b border-line [scrollbar-width:none]">
      {tabs.map((t) => (
        <Link key={t.key} href={t.href} className={cn("-mb-px shrink-0 border-b-2 px-4 py-2.5 text-sm font-semibold", current === t.key ? "border-brand text-brand" : "border-transparent text-ink-muted hover:text-navy")}>
          {t.label}{typeof t.count === "number" && <span className="ml-1.5 rounded-full bg-surface px-2 py-0.5 text-xs">{t.count}</span>}
        </Link>
      ))}
    </div>
  );
}

export function Pagination({ page, pages, params, basePath }: { page: number; pages: number; params: Record<string, string | undefined>; basePath: string }) {
  if (pages <= 1) return null;
  const href = (p: number) => {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v && k !== "page") q.set(k, v);
    q.set("page", String(p));
    return `${basePath}?${q}`;
  };
  return (
    <div className="mt-4 flex items-center justify-between text-sm">
      <span className="text-ink-muted">Page {page} of {pages}</span>
      <div className="flex gap-2">
        {page > 1 && <Link href={href(page - 1)} className="btn-outline btn-sm">Previous</Link>}
        {page < pages && <Link href={href(page + 1)} className="btn-outline btn-sm">Next</Link>}
      </div>
    </div>
  );
}

export function Section({ title, children, actions, className }: { title: string; children: React.ReactNode; actions?: React.ReactNode; className?: string }) {
  return (
    <section className={cn("card p-5 sm:p-6", className)}>
      <div className="mb-4 flex items-center justify-between gap-3"><h2 className="text-lg font-bold">{title}</h2>{actions}</div>
      {children}
    </section>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="rounded-2xl border border-dashed border-line px-6 py-10 text-center text-sm text-ink-muted">{children}</div>;
}
