"use client";
import { useEffect, useRef, useState } from "react";
import { Upload, X, FileText, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

type Uploaded = { id: string; name: string; mimeType?: string };
type Purpose = "document" | "image" | "video" | "any";

const ACCEPT: Record<Purpose, string> = {
  document: ".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx",
  image: ".jpg,.jpeg,.png,.webp",
  video: ".mp4,.mov,.webm",
  any: ".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.jpg,.jpeg,.png,.webp,.mp4,.mov,.webm",
};

/** Upload flow: reserve (validates type/size) → send bytes directly to storage → server verifies file signature. */
export async function uploadFile(file: File, purpose: Purpose, onProgress?: (p: number) => void): Promise<Uploaded> {
  const init = await fetch("/api/uploads/init", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: file.name, size: file.size, purpose }) });
  const initJson = await init.json();
  if (!init.ok) throw new Error(initJson.error ?? "Upload failed");
  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open(initJson.method, initJson.uploadUrl);
    for (const [k, v] of Object.entries(initJson.headers ?? {})) xhr.setRequestHeader(k, String(v));
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress?.(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(safeError(xhr.responseText))));
    xhr.onerror = () => reject(new Error("Network error during upload — check your connection."));
    xhr.send(file);
  });
  const done = await fetch("/api/uploads/complete", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fileId: initJson.fileId }) });
  const doneJson = await done.json();
  if (!done.ok) throw new Error(doneJson.error ?? "Upload failed");
  return { id: doneJson.id, name: doneJson.name, mimeType: doneJson.mimeType };
}

function safeError(text: string) {
  try { return JSON.parse(text).error ?? "Upload failed"; } catch { return "Upload failed"; }
}

export function FileUpload({ name, purpose, initial, label, help, showPreview = purpose === "image" }: {
  name: string; purpose: Purpose; initial?: Uploaded | null; label?: string; help?: string; showPreview?: boolean;
}) {
  const [file, setFile] = useState<Uploaded | null>(initial ?? null);
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const input = useRef<HTMLInputElement>(null);

  const onPick = async (f: File | undefined) => {
    if (!f) return;
    setError(null);
    setProgress(0);
    try {
      setFile(await uploadFile(f, purpose, setProgress));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setProgress(null);
      if (input.current) input.current.value = "";
    }
  };

  return (
    <div>
      {label && <span className="label">{label}</span>}
      <input type="hidden" name={name} value={file?.id ?? ""} />
      <div className={cn("flex items-center gap-3 rounded-xl border border-dashed border-line bg-surface p-3", error && "border-red-300 bg-red-50")}>
        {file ? (
          <>
            {showPreview ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={`/api/files/${file.id}`} alt="" className="h-14 w-20 rounded-lg border border-line bg-white object-cover" />
            ) : (
              <span className="grid h-12 w-12 place-items-center rounded-lg bg-white text-brand ring-1 ring-line"><FileText className="h-5 w-5" /></span>
            )}
            <a href={`/api/files/${file.id}`} target="_blank" rel="noreferrer" className="min-w-0 flex-1 truncate text-sm font-medium text-navy hover:text-brand">{file.name}</a>
            <button type="button" className="btn-ghost btn-sm" onClick={() => input.current?.click()}>Replace</button>
            <button type="button" className="btn-ghost btn-sm text-red-600" aria-label="Remove file" onClick={() => setFile(null)}><X className="h-4 w-4" /></button>
          </>
        ) : (
          <button type="button" onClick={() => input.current?.click()} disabled={progress !== null} className="flex w-full items-center justify-center gap-2 py-2 text-sm font-semibold text-brand">
            {progress !== null ? <><Loader2 className="h-4 w-4 animate-spin" /> Uploading… {progress}%</> : <><Upload className="h-4 w-4" /> Choose file</>}
          </button>
        )}
        <input ref={input} type="file" accept={ACCEPT[purpose]} className="hidden" onChange={(e) => onPick(e.target.files?.[0])} />
      </div>
      {error ? <p className="mt-1 text-xs font-medium text-red-600" role="alert">{error}</p> : help ? <p className="hint">{help}</p> : null}
    </div>
  );
}

/** Uploads several images at once; each uploaded id is submitted as a repeated hidden input. */
export function MultiImageUpload({ name }: { name: string }) {
  const [items, setItems] = useState<Uploaded[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const input = useRef<HTMLInputElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  // After the surrounding form is saved (React resets the form), clear the pending list so images aren't added twice.
  useEffect(() => {
    const form = wrap.current?.closest("form");
    if (!form) return;
    const onReset = () => setItems([]);
    form.addEventListener("reset", onReset);
    return () => form.removeEventListener("reset", onReset);
  }, []);
  const onPick = async (list: FileList | null) => {
    if (!list?.length) return;
    setError(null);
    for (const [i, f] of Array.from(list).entries()) {
      setBusy(`Uploading ${i + 1} of ${list.length}…`);
      try {
        const u = await uploadFile(f, "image");
        setItems((p) => [...p, u]);
      } catch (e) {
        setError(`${f.name}: ${e instanceof Error ? e.message : "failed"}`);
      }
    }
    setBusy(null);
    if (input.current) input.current.value = "";
  };
  return (
    <div ref={wrap}>
      {items.map((x) => <input key={x.id} type="hidden" name={name} value={x.id} />)}
      <div className="flex flex-wrap gap-2">
        {items.map((x) => (
          <div key={x.id} className="relative">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={`/api/files/${x.id}`} alt="" className="h-16 w-24 rounded-lg border border-line object-cover" />
            <button type="button" aria-label="Remove" onClick={() => setItems((p) => p.filter((y) => y.id !== x.id))} className="absolute -right-1.5 -top-1.5 grid h-5 w-5 place-items-center rounded-full bg-red-600 text-white"><X className="h-3 w-3" /></button>
          </div>
        ))}
        <button type="button" onClick={() => input.current?.click()} disabled={Boolean(busy)} className="flex h-16 min-w-24 items-center justify-center gap-1 rounded-lg border border-dashed border-line px-3 text-xs font-semibold text-brand">
          {busy ? <><Loader2 className="h-3.5 w-3.5 animate-spin" /> {busy}</> : <><Upload className="h-3.5 w-3.5" /> Add images</>}
        </button>
      </div>
      <input ref={input} type="file" accept={ACCEPT.image} multiple className="hidden" onChange={(e) => onPick(e.target.files)} />
      {error && <p className="mt-1 text-xs font-medium text-red-600">{error}</p>}
    </div>
  );
}
