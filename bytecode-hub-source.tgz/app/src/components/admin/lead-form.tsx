"use client";
import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save } from "lucide-react";
import { FormMessage } from "@/components/admin/ui";
import { TIMELINES, PRIORITIES, CONTACT_METHODS, MEETING_PREFERENCES } from "@/lib/enquiry-config";

type Opt = { id: string; name?: string; label?: string };
type State = { ok?: boolean; error?: string; message?: string; fieldErrors?: Record<string, string> } | null;

export type LeadFormValues = Partial<{
  id: string; businessName: string; industryId: string; location: string; address: string; website: string; facebook: string; instagram: string; socialOther: string;
  contactName: string; designation: string; phone: string; whatsapp: string; email: string; services: string[]; requirements: string; initialInterest: string;
  budgetRangeId: string; budgetCustom: string; estimatedValue: string; timeline: string; campaignId: string; sourceId: string; priority: string; assignedTo: string;
  preferredContactMethod: string; meetingPreference: string; comments: string;
}>;

export const LEAD_DRAFT_KEY = "bc_internal_lead_draft_v1";
const DRAFT = LEAD_DRAFT_KEY;

export function LeadForm({ action, mode, values = {}, lookups, canAssign, currentUserId, defaultCampaignId, defaultSourceId }: {
  action: (prev: State, fd: FormData) => Promise<State>;
  mode: "create" | "edit";
  values?: LeadFormValues;
  lookups: { industries: Opt[]; services: Opt[]; budgets: Opt[]; campaigns: Opt[]; sources: Opt[]; users: Opt[] };
  canAssign: boolean;
  currentUserId: string;
  defaultCampaignId?: string;
  defaultSourceId?: string;
}) {
  const [state, formAction] = useActionState(action, null);
  const ref = useRef<HTMLFormElement>(null);
  const [clientRef] = useState(() => (typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : String(Date.now())));
  const [restored, setRestored] = useState(false);

  const lastSubmitted = useRef<Record<string, string | string[]> | null>(null);

  const serialize = () => {
    const obj: Record<string, string | string[]> = {};
    if (!ref.current) return obj;
    const fd = new FormData(ref.current);
    for (const k of new Set(fd.keys())) { if (k === "clientRef" || k === "id") continue; const all = fd.getAll(k).map(String); obj[k] = all.length > 1 || k === "services" ? all : all[0]; }
    // Unchecked service boxes must be remembered as "none selected".
    if (!("services" in obj)) obj.services = [];
    return obj;
  };
  const apply = (data: Record<string, string | string[]>) => {
    if (!ref.current) return;
    for (const [k, val] of Object.entries(data)) {
      ref.current.querySelectorAll<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>(`[name="${k}"]`).forEach((el) => {
        if (el instanceof HTMLInputElement && el.type === "checkbox") el.checked = Array.isArray(val) ? val.includes(el.value) : val === "on";
        else if (!(el instanceof HTMLInputElement && el.type === "hidden")) el.value = Array.isArray(val) ? val[0] ?? "" : val;
      });
    }
  };

  // Autosave drafts of NEW leads on this device, so nothing is lost if the connection drops mid-visit.
  useEffect(() => {
    if (mode !== "create") return;
    try {
      const raw = window.localStorage.getItem(DRAFT);
      if (raw) { apply(JSON.parse(raw)); setRestored(true); }
    } catch { /* ignore */ }
  }, [mode]);
  // React resets forms after an action; if the server rejected the save, put the user's input back.
  useEffect(() => {
    if (state?.error && lastSubmitted.current) apply(lastSubmitted.current);
  }, [state]);
  const persist = () => {
    if (mode !== "create") return;
    try { window.localStorage.setItem(DRAFT, JSON.stringify(serialize())); } catch { /* ignore */ }
  };

  const v = values;
  const opt = (list: Opt[]) => list.map((o) => <option key={o.id} value={o.id}>{o.name ?? o.label}</option>);

  return (
    <form ref={ref} action={(fd) => { lastSubmitted.current = serialize(); return formAction(fd); }} onInput={persist} onChange={persist} className="space-y-6">
      {v.id && <input type="hidden" name="id" value={v.id} />}
      {mode === "create" && <input type="hidden" name="clientRef" value={clientRef} />}
      {restored && <p className="rounded-xl bg-brand/5 px-4 py-2 text-sm text-brand">Restored your unsaved draft. <button type="button" className="underline" onClick={() => { try { window.localStorage.removeItem(DRAFT); } catch { /* ignore */ } ref.current?.reset(); setRestored(false); }}>Clear</button></p>}

      <fieldset className="card grid gap-4 p-5 sm:grid-cols-2 sm:p-6">
        <legend className="sr-only">Business</legend>
        <h2 className="text-lg font-bold sm:col-span-2">Business</h2>
        <F label="Business name *"><input name="businessName" required defaultValue={v.businessName} className="input" /></F>
        <F label="Industry"><select name="industryId" defaultValue={v.industryId ?? ""} className="input"><option value="">—</option>{opt(lookups.industries)}</select></F>
        <F label="Location"><input name="location" defaultValue={v.location} placeholder="e.g. Lakeside, Pokhara" className="input" /></F>
        <F label="Address"><input name="address" defaultValue={v.address} className="input" /></F>
        <F label="Website"><input name="website" defaultValue={v.website} inputMode="url" className="input" /></F>
        <F label="Facebook"><input name="facebook" defaultValue={v.facebook} className="input" /></F>
        <F label="Instagram"><input name="instagram" defaultValue={v.instagram} className="input" /></F>
        <F label="Other social media / links"><input name="socialOther" defaultValue={v.socialOther} className="input" /></F>
      </fieldset>

      <fieldset className="card grid gap-4 p-5 sm:grid-cols-2 sm:p-6">
        <h2 className="text-lg font-bold sm:col-span-2">Contact person</h2>
        <F label="Contact person"><input name="contactName" defaultValue={v.contactName} className="input" /></F>
        <F label="Designation"><input name="designation" defaultValue={v.designation} className="input" /></F>
        <F label="Phone"><input name="phone" type="tel" inputMode="tel" defaultValue={v.phone} placeholder="98XXXXXXXX" className="input" /></F>
        <F label="WhatsApp" hint={mode === "create" ? "Leave blank if same as phone" : undefined}><input name="whatsapp" type="tel" inputMode="tel" defaultValue={v.whatsapp} className="input" /></F>
        <F label="Email" className="sm:col-span-2"><input name="email" type="email" inputMode="email" defaultValue={v.email} className="input" /></F>
      </fieldset>

      <fieldset className="card space-y-4 p-5 sm:p-6">
        <h2 className="text-lg font-bold">Interest & requirements</h2>
        <div>
          <span className="label">Interested services</span>
          <div className="flex flex-wrap gap-2">
            {lookups.services.map((s) => (
              <label key={s.id} className="flex min-h-[44px] cursor-pointer items-center gap-2 rounded-xl border border-line px-3 text-sm has-[:checked]:border-brand has-[:checked]:bg-brand/5">
                <input type="checkbox" name="services" value={s.id} defaultChecked={v.services?.includes(s.id)} className="check" /> {s.label}
              </label>
            ))}
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <F label="Initial requirements" className="sm:col-span-2"><textarea name="requirements" defaultValue={v.requirements} rows={4} className="input" /></F>
          {mode === "edit" && <F label="Initial interest (quick capture)" className="sm:col-span-2"><input name="initialInterest" defaultValue={v.initialInterest} className="input" /></F>}
          <F label="Budget range"><select name="budgetRangeId" defaultValue={v.budgetRangeId ?? ""} className="input"><option value="">Not discussed</option>{opt(lookups.budgets)}</select></F>
          <F label="Budget (custom / notes)"><input name="budgetCustom" defaultValue={v.budgetCustom} className="input" /></F>
          <F label="Estimated deal value (NPR)" hint="Your estimate — reported separately from actual results"><input name="estimatedValue" inputMode="numeric" defaultValue={v.estimatedValue} placeholder="e.g. 150000" className="input" /></F>
          <F label="Timeline"><select name="timeline" defaultValue={v.timeline ?? ""} className="input"><option value="">—</option>{TIMELINES.map((x) => <option key={x}>{x}</option>)}</select></F>
          {mode === "edit" && (
            <>
              <F label="Preferred contact method"><select name="preferredContactMethod" defaultValue={v.preferredContactMethod ?? ""} className="input"><option value="">—</option>{CONTACT_METHODS.map((x) => <option key={x}>{x}</option>)}</select></F>
              <F label="Meeting preference"><select name="meetingPreference" defaultValue={v.meetingPreference ?? ""} className="input"><option value="">—</option>{MEETING_PREFERENCES.map((x) => <option key={x}>{x}</option>)}</select></F>
              <F label="Client comments" className="sm:col-span-2"><textarea name="comments" defaultValue={v.comments} rows={2} className="input" /></F>
            </>
          )}
        </div>
      </fieldset>

      <fieldset className="card grid gap-4 p-5 sm:grid-cols-2 sm:p-6">
        <h2 className="text-lg font-bold sm:col-span-2">Campaign & ownership</h2>
        <F label="Campaign"><select name="campaignId" defaultValue={v.campaignId ?? defaultCampaignId ?? ""} className="input"><option value="">—</option>{opt(lookups.campaigns)}</select></F>
        <F label="Lead source"><select name="sourceId" defaultValue={v.sourceId ?? defaultSourceId ?? ""} className="input"><option value="">—</option>{opt(lookups.sources)}</select></F>
        <F label="Priority"><select name="priority" defaultValue={v.priority ?? ""} className="input"><option value="">—</option>{PRIORITIES.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}</select></F>
        {mode === "create" && (canAssign ? (
          <F label="Assigned team member"><select name="assignedTo" defaultValue={v.assignedTo ?? currentUserId} className="input"><option value="">Unassigned</option>{opt(lookups.users)}</select></F>
        ) : <input type="hidden" name="assignedTo" value={currentUserId} />)}
      </fieldset>

      {mode === "create" && (
        <fieldset className="card grid gap-4 p-5 sm:grid-cols-2 sm:p-6">
          <h2 className="text-lg font-bold sm:col-span-2">Meeting, notes & next step</h2>
          <F label="Meeting date & time" hint="Past = meeting held; future = meeting scheduled"><input type="datetime-local" name="meetingAt" className="input" /></F>
          <F label="Meeting location"><input name="meetingLocation" className="input" /></F>
          <F label="Meeting details" className="sm:col-span-2"><textarea name="meetingNotes" rows={2} className="input" /></F>
          <F label="Discussion notes" className="sm:col-span-2"><textarea name="notes" rows={3} className="input" /></F>
          <F label="Next action"><input name="nextAction" placeholder="e.g. Send SEO proposal" className="input" /></F>
          <F label="Follow-up date"><input type="datetime-local" name="followUpAt" className="input" /></F>
          <label className="flex items-start gap-3 text-sm text-ink-soft sm:col-span-2"><input type="checkbox" name="consent" className="check mt-0.5" /> The contact agreed to be contacted by ByteCode about this enquiry.</label>
        </fieldset>
      )}

      <FormMessage state={state} />
      <div className="sticky bottom-20 z-10 flex justify-end lg:bottom-4"><Submit label={mode === "create" ? "Save lead" : "Save changes"} /></div>
      <p className="text-xs text-ink-muted">Only the business name is required — you can save partial information and complete it later.</p>
    </form>
  );
}

function F({ label, hint, children, className }: { label: string; hint?: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className ?? ""}`}><span className="label">{label}</span>{children}{hint && <span className="hint block">{hint}</span>}</label>;
}

function Submit({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return <button className="btn-primary shadow-lift" disabled={pending}>{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} {label}</button>;
}
