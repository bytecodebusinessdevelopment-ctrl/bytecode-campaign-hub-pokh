"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { CheckCircle2, CloudOff, Loader2, RefreshCcw, Wifi, Zap, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

type Opt = { id: string; name: string };
type Payload = {
  businessName: string; industryId: string; location: string; phone: string; contactName: string; website: string;
  initialInterest: string; serviceIds: string[]; notes: string; priority: string; clientRef: string; campaignId: string; sourceSlug: string;
};
type Queued = Payload & { queuedAt: number; lastError?: string };

const DRAFT = "bc_quick_draft_v1";
const QUEUE = "bc_quick_queue_v1";

const read = <T,>(k: string, d: T): T => { try { const v = window.localStorage.getItem(k); return v ? (JSON.parse(v) as T) : d; } catch { return d; } };
const write = (k: string, v: unknown) => { try { window.localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage unavailable */ } };
const ref = () => (typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`);

const blank = (campaignId: string, sourceSlug: string): Payload => ({
  businessName: "", industryId: "", location: "", phone: "", contactName: "", website: "", initialInterest: "", serviceIds: [], notes: "", priority: "", clientRef: ref(), campaignId, sourceSlug,
});

/**
 * Quick prospect capture — designed for one-handed use during physical visits.
 * Drafts autosave on the device; if the network is down, the lead is queued on the phone and sent automatically later.
 * Every submission carries a clientRef so retries can never create duplicate leads.
 */
export function QuickCapture({ industries, services, campaigns, defaultCampaignId, defaultLocation }: {
  industries: Opt[]; services: { id: string; label: string }[]; campaigns: Opt[]; defaultCampaignId: string; defaultLocation: string;
}) {
  const [f, setF] = useState<Payload>(() => blank(defaultCampaignId, "pokhara-physical-visit"));
  const [queue, setQueue] = useState<Queued[]>([]);
  const [online, setOnline] = useState(true);
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState<{ code: string; id: string; dup: boolean } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const d = read<Payload | null>(DRAFT, null);
    if (d?.clientRef) setF(d);
    else setF((p) => ({ ...p, location: defaultLocation }));
    setQueue(read<Queued[]>(QUEUE, []));
    setOnline(navigator.onLine);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, [defaultLocation]);
  useEffect(() => { if (f.businessName || f.phone || f.notes) write(DRAFT, f); }, [f]);

  const send = async (p: Payload) => {
    const res = await fetch("/api/leads/quick", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...p, priority: p.priority || null }) });
    const json = await res.json().catch(() => ({}));
    if (res.status === 401) throw Object.assign(new Error(json.error ?? "Session expired"), { auth: true });
    if (!res.ok) throw Object.assign(new Error(json.error ?? "Could not save"), { validation: res.status === 400, fieldErrors: json.fieldErrors });
    return json as { id: string; leadCode: string; duplicateOf: string | null };
  };

  const flush = useCallback(async () => {
    const q = read<Queued[]>(QUEUE, []);
    if (!q.length || !navigator.onLine) return;
    const remaining: Queued[] = [];
    for (const item of q) {
      try { await send(item); } catch (e) { remaining.push({ ...item, lastError: e instanceof Error ? e.message : "failed" }); }
    }
    write(QUEUE, remaining);
    setQueue(remaining);
  }, []);
  useEffect(() => { if (online) void flush(); }, [online, flush]);

  const submit = async () => {
    setError(null);
    if (f.businessName.trim().length < 2) { setError("Business name is required."); return; }
    setBusy(true);
    try {
      if (!navigator.onLine) throw Object.assign(new Error("offline"), { offline: true });
      const r = await send(f);
      setSaved({ code: r.leadCode, id: r.id, dup: Boolean(r.duplicateOf) });
      try { window.localStorage.removeItem(DRAFT); } catch { /* ignore */ }
      setF({ ...blank(f.campaignId, f.sourceSlug), location: f.location, industryId: "" });
    } catch (e) {
      const err = e as Error & { validation?: boolean; auth?: boolean };
      if (err.validation) setError(err.message);
      else if (err.auth) setError("Your session has expired — sign in again. Your entry is saved on this phone.");
      else {
        // Network problem: queue on the device and carry on.
        const q = [...read<Queued[]>(QUEUE, []), { ...f, queuedAt: Date.now() }];
        write(QUEUE, q);
        setQueue(q);
        setSaved({ code: "Saved offline", id: "", dup: false });
        try { window.localStorage.removeItem(DRAFT); } catch { /* ignore */ }
        setF({ ...blank(f.campaignId, f.sourceSlug), location: f.location });
      }
    } finally {
      setBusy(false);
    }
  };

  const set = <K extends keyof Payload>(k: K, v: Payload[K]) => { setSaved(null); setF((p) => ({ ...p, [k]: v })); };

  return (
    <div className="mx-auto max-w-xl">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="flex items-center gap-2 text-2xl font-extrabold"><Zap className="h-6 w-6 text-teal" /> Quick capture</h1>
        <span className={cn("chip", online ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-amber-300 bg-amber-50 text-amber-800")}>{online ? <><Wifi className="h-3.5 w-3.5" /> Online</> : <><CloudOff className="h-3.5 w-3.5" /> Offline</>}</span>
      </div>

      {queue.length > 0 && (
        <div className="mb-4 flex items-center justify-between gap-3 rounded-2xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          <span><strong>{queue.length}</strong> lead{queue.length > 1 ? "s" : ""} waiting to upload from this phone{queue[0].lastError ? ` (${queue[0].lastError})` : ""}.</span>
          <button type="button" onClick={() => void flush()} className="btn-outline btn-sm shrink-0"><RefreshCcw className="h-4 w-4" /> Retry</button>
        </div>
      )}

      {saved && (
        <div className="mb-4 flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900" role="status">
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" />
          <div>
            {saved.id ? <>Saved as <strong className="font-mono">{saved.code}</strong>. <Link href={`/admin/leads/${saved.id}`} className="font-semibold underline">Add more details</Link></> : <>No connection — the lead is <strong>saved on this phone</strong> and will upload automatically.</>}
            {saved.dup && <p className="mt-1 flex items-center gap-1 text-amber-800"><AlertTriangle className="h-4 w-4" /> This may be a duplicate of an existing lead — it has been flagged for review.</p>}
          </div>
        </div>
      )}

      <div className="card space-y-4 p-5">
        <Q label="Business name *"><input value={f.businessName} onChange={(e) => set("businessName", e.target.value)} className="input text-base" autoComplete="off" autoFocus /></Q>
        <div className="grid grid-cols-2 gap-3">
          <Q label="Industry"><select value={f.industryId} onChange={(e) => set("industryId", e.target.value)} className="input"><option value="">—</option>{industries.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</select></Q>
          <Q label="Location"><input value={f.location} onChange={(e) => set("location", e.target.value)} className="input" /></Q>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Q label="Contact number"><input type="tel" inputMode="tel" value={f.phone} onChange={(e) => set("phone", e.target.value)} className="input" placeholder="98XXXXXXXX" /></Q>
          <Q label="Contact person"><input value={f.contactName} onChange={(e) => set("contactName", e.target.value)} className="input" /></Q>
        </div>
        <Q label="Website"><input value={f.website} onChange={(e) => set("website", e.target.value)} inputMode="url" className="input" /></Q>
        <div>
          <span className="label">Initial interest</span>
          <div className="flex flex-wrap gap-2">
            {services.map((s) => {
              const on = f.serviceIds.includes(s.id);
              return <button key={s.id} type="button" aria-pressed={on} onClick={() => set("serviceIds", on ? f.serviceIds.filter((x) => x !== s.id) : [...f.serviceIds, s.id])} className={cn("min-h-[40px] rounded-xl border px-3 text-sm", on ? "border-brand bg-brand text-white" : "border-line text-ink-soft")}>{s.label}</button>;
            })}
          </div>
          <input value={f.initialInterest} onChange={(e) => set("initialInterest", e.target.value)} placeholder="Anything specific? (optional)" className="input mt-2" />
        </div>
        <Q label="Notes"><textarea value={f.notes} onChange={(e) => set("notes", e.target.value)} rows={3} className="input" placeholder="What did you discuss?" /></Q>
        <div>
          <span className="label">Priority</span>
          <div className="grid grid-cols-3 gap-2">
            {[["hot", "Hot", "bg-red-600"], ["warm", "Warm", "bg-amber-500"], ["cold", "Cold", "bg-slate-500"]].map(([v, l, c]) => (
              <button key={v} type="button" aria-pressed={f.priority === v} onClick={() => set("priority", f.priority === v ? "" : v)} className={cn("min-h-[44px] rounded-xl border text-sm font-semibold", f.priority === v ? `${c} border-transparent text-white` : "border-line text-ink-soft")}>{l}</button>
            ))}
          </div>
        </div>
        {campaigns.length > 1 && (
          <Q label="Campaign"><select value={f.campaignId} onChange={(e) => set("campaignId", e.target.value)} className="input">{campaigns.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Q>
        )}
        {error && <p className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700" role="alert">{error}</p>}
        <button type="button" onClick={submit} disabled={busy} className="btn-accent w-full py-4 text-base">{busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Zap className="h-5 w-5" />} Save prospect</button>
        <p className="text-center text-xs text-ink-muted">A unique Lead ID is generated automatically. Drafts are kept on this phone until saved.</p>
      </div>
    </div>
  );
}

function Q({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block"><span className="label">{label}</span>{children}</label>;
}
