"use client";
import { useEffect } from "react";

/** Clears the "new lead" draft once the lead has been saved successfully. */
export function ClearLeadDraft() {
  useEffect(() => { try { window.localStorage.removeItem("bc_internal_lead_draft_v1"); } catch { /* ignore */ } }, []);
  return null;
}
