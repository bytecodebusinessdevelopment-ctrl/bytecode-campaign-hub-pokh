"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import {
  LayoutDashboard, Users, Zap, CalendarClock, BarChart3, Briefcase, MonitorPlay, FolderOpen, Tags, Megaphone, ListChecks,
  UserCog, Settings, RefreshCcw, ScrollText, MessageSquareQuote, Presentation, Menu, X, LogOut, Plus, Bell, KeyRound,
} from "lucide-react";
import { Logo } from "@/components/logo";
import { cn } from "@/lib/utils";
import type { Role } from "@/lib/permissions";
import { can, type Permission, ROLE_LABELS } from "@/lib/permissions";

type Item = { href: string; label: string; Icon: typeof LayoutDashboard; perm?: Permission; exact?: boolean };

const GROUPS: { title: string; items: Item[] }[] = [
  { title: "Sales", items: [
    { href: "/admin", label: "Dashboard", Icon: LayoutDashboard, exact: true },
    { href: "/admin/leads", label: "Leads", Icon: Users },
    { href: "/admin/leads/quick", label: "Quick capture", Icon: Zap, exact: true },
    { href: "/admin/follow-ups", label: "Follow-ups", Icon: CalendarClock },
    { href: "/admin/present", label: "Presenter kit", Icon: Presentation },
    { href: "/admin/reports", label: "Reports", Icon: BarChart3, perm: "viewReports" },
  ] },
  { title: "Content", items: [
    { href: "/admin/portfolio", label: "Portfolio", Icon: Briefcase, perm: "manageContent" },
    { href: "/admin/showcase", label: "Demos & UI/UX", Icon: MonitorPlay, perm: "manageContent" },
    { href: "/admin/resources", label: "Resources", Icon: FolderOpen, perm: "manageContent" },
    { href: "/admin/testimonials", label: "Testimonials", Icon: MessageSquareQuote, perm: "manageContent" },
    { href: "/admin/services", label: "Services & packages", Icon: Tags, perm: "managePricing" },
  ] },
  { title: "Configuration", items: [
    { href: "/admin/campaigns", label: "Campaigns", Icon: Megaphone, perm: "manageCampaigns" },
    { href: "/admin/lookups", label: "Lists & options", Icon: ListChecks, perm: "manageLookups" },
    { href: "/admin/users", label: "Users", Icon: UserCog, perm: "manageUsers" },
    { href: "/admin/integrations", label: "Google Sheets sync", Icon: RefreshCcw, perm: "retrySync" },
    { href: "/admin/settings", label: "Settings", Icon: Settings, perm: "manageSettings" },
    { href: "/admin/audit", label: "Audit log", Icon: ScrollText, perm: "viewAudit" },
  ] },
];

export function AdminNav({ user, unread, logoutAction }: { user: { name: string; role: Role }; unread: number; logoutAction: () => Promise<void> }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [pathname]);
  const isActive = (i: Item) => (i.exact ? pathname === i.href : pathname === i.href || (pathname.startsWith(`${i.href}/`) && !(i.href === "/admin/leads" && pathname === "/admin/leads/quick")));
  const groups = GROUPS.map((g) => ({ ...g, items: g.items.filter((i) => !i.perm || can(user.role, i.perm)) })).filter((g) => g.items.length);

  const nav = (
    <nav className="flex flex-col gap-6" aria-label="Admin">
      {groups.map((g) => (
        <div key={g.title}>
          <p className="px-3 text-[11px] font-semibold uppercase tracking-wider text-white/40">{g.title}</p>
          <ul className="mt-2 space-y-0.5">
            {g.items.map((i) => (
              <li key={i.href}>
                <Link href={i.href} className={cn("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition", isActive(i) ? "bg-white/12 text-white" : "text-white/70 hover:bg-white/5 hover:text-white")} style={isActive(i) ? { backgroundColor: "rgb(255 255 255 / .12)" } : undefined}>
                  <i.Icon className="h-4 w-4" /> {i.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </nav>
  );

  const userBox = (
    <div className="border-t border-white/10 p-4">
      <p className="truncate text-sm font-semibold text-white">{user.name}</p>
      <p className="text-xs text-white/50">{ROLE_LABELS[user.role]}</p>
      <div className="mt-3 flex gap-2">
        <Link href="/admin/account" className="btn-sm inline-flex items-center gap-1 rounded-lg bg-white/10 px-3 text-xs font-semibold text-white hover:bg-white/20"><KeyRound className="h-3.5 w-3.5" /> Account</Link>
        <form action={logoutAction}><button className="btn-sm inline-flex items-center gap-1 rounded-lg bg-white/10 px-3 text-xs font-semibold text-white hover:bg-white/20"><LogOut className="h-3.5 w-3.5" /> Sign out</button></form>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col bg-navy lg:flex">
        <div className="flex h-16 items-center px-5"><Link href="/admin" className="flex items-center gap-2"><Logo dark compact /><span className="rounded-md bg-white/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-white/70">Hub</span></Link></div>
        <div className="flex-1 overflow-y-auto px-3 py-4">{nav}</div>
        {userBox}
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-line bg-white/95 px-4 backdrop-blur lg:hidden">
        <Link href="/admin"><Logo /></Link>
        <div className="flex items-center gap-1">
          <Link href="/admin/notifications" className="btn-ghost relative px-2.5" aria-label={`Notifications${unread ? ` (${unread} unread)` : ""}`}>
            <Bell className="h-5 w-5" />{unread > 0 && <span className="absolute right-1.5 top-1.5 h-2.5 w-2.5 rounded-full bg-red-500" />}
          </Link>
          <button type="button" className="btn-ghost px-2.5" onClick={() => setOpen(true)} aria-label="Open menu"><Menu className="h-6 w-6" /></button>
        </div>
      </header>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 right-0 flex w-[85%] max-w-xs flex-col bg-navy">
            <div className="flex h-14 items-center justify-between px-4"><Logo dark /><button className="p-2 text-white" onClick={() => setOpen(false)} aria-label="Close menu"><X className="h-6 w-6" /></button></div>
            <div className="flex-1 overflow-y-auto px-3 py-2">{nav}</div>
            {userBox}
          </div>
        </div>
      )}

      {/* Mobile bottom tab bar — large touch targets for field use */}
      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-white pb-[env(safe-area-inset-bottom)] lg:hidden" aria-label="Quick navigation">
        {[
          { href: "/admin", label: "Home", Icon: LayoutDashboard, exact: true },
          { href: "/admin/leads", label: "Leads", Icon: Users },
          { href: "/admin/leads/quick", label: "Capture", Icon: Plus, exact: true, primary: true },
          { href: "/admin/follow-ups", label: "Follow-ups", Icon: CalendarClock },
          { href: "/admin/present", label: "Present", Icon: Presentation },
        ].map((i) => (
          <Link key={i.href} href={i.href} className={cn("flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-medium", isActive(i as Item) ? "text-brand" : "text-ink-muted")}>
            {i.primary ? <span className="-mt-5 grid h-12 w-12 place-items-center rounded-2xl bg-teal text-white shadow-lift"><i.Icon className="h-6 w-6" /></span> : <i.Icon className="h-5 w-5" />}
            {i.label}
          </Link>
        ))}
      </nav>
    </>
  );
}

export function RegisterSW() {
  useEffect(() => {
    if ("serviceWorker" in navigator && process.env.NODE_ENV === "production") {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }
  }, []);
  return null;
}
