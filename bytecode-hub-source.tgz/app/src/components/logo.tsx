import { cn } from "@/lib/utils";

/** Uses the uploaded logo (Admin → Settings) when available, otherwise a text wordmark. */
export function Logo({ fileId, dark = false, name = "ByteCode", className, compact = false }: { fileId?: string | null; dark?: boolean; name?: string; className?: string; compact?: boolean }) {
  if (fileId) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={`/api/files/${fileId}`} alt={name} className={cn("h-9 w-auto", className)} />;
  }
  return (
    <span className={cn("inline-flex items-center gap-2 font-display text-lg font-extrabold tracking-tight", dark ? "text-white" : "text-navy", className)}>
      <span aria-hidden className={cn("grid h-9 w-9 place-items-center rounded-xl text-sm font-black", dark ? "bg-white/10 text-white ring-1 ring-white/20" : "bg-navy text-white")}>
        {"</>"}
      </span>
      <span>
        Byte<span className="text-teal">Code</span>
        {!compact && <span className={cn("ml-1 hidden text-xs font-semibold uppercase tracking-[0.2em] sm:inline", dark ? "text-white/60" : "text-ink-muted")}>Developers</span>}
      </span>
    </span>
  );
}
