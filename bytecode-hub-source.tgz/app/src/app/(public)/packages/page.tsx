import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/public/cards";
import { PackageCard } from "@/components/public/package-card";
import { getPublishedPackages, getPublishedServices } from "@/lib/public-data";

export const revalidate = 60;
export const metadata: Metadata = { title: "Packages & Pricing", description: "Website development, SEO and digital service packages from ByteCode Developers." };

export default async function PackagesPage() {
  const [rows, services] = await Promise.all([getPublishedPackages(), getPublishedServices()]);
  const byService = services.map((s) => ({ s, pkgs: rows.filter((r) => r.service.slug === s.slug).map((r) => r.pkg) }));
  const withPkgs = byService.filter((x) => x.pkgs.length);
  const custom = byService.filter((x) => !x.pkgs.length);
  return (
    <>
      <PageHero eyebrow="Packages & pricing" title="Clear scopes. Clear deliverables." intro="Standard packages where the scope is predictable, and custom quotations where your requirements are unique. All prices are in Nepali Rupees (NPR)." />
      <div className="container space-y-16 py-16">
        {withPkgs.map(({ s, pkgs }) => (
          <section key={s.id} id={s.slug} className="scroll-mt-24">
            <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-end">
              <h2 className="text-2xl font-bold">{s.name}</h2>
              <Link href={`/services/${s.slug}`} className="text-sm font-semibold text-brand">About this service →</Link>
            </div>
            <div className="mt-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">{pkgs.map((p) => <PackageCard key={p.id} p={p} serviceSlug={s.slug} />)}</div>
          </section>
        ))}
        {withPkgs.length === 0 && (
          <div className="card p-8">
            <h2 className="text-xl font-bold">Packages are being finalised</h2>
            <p className="mt-2 max-w-2xl text-ink-soft">Our standard website and SEO packages are being updated. In the meantime, every service below is available on a custom quotation — tell us what you need and we&apos;ll send a clear, itemised proposal.</p>
          </div>
        )}
        <section>
          <h2 className="text-2xl font-bold">{withPkgs.length ? "Custom quotation services" : "Services available on quotation"}</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {custom.map(({ s }) => (
              <div key={s.id} className="card flex flex-col p-6">
                <h3 className="font-bold">{s.name}</h3>
                <p className="mt-2 flex-1 text-sm text-ink-soft">{s.pricingNote ?? s.summary}</p>
                <div className="mt-4 flex gap-2">
                  <Link href={`/services/${s.slug}`} className="btn-outline btn-sm flex-1">Details</Link>
                  <Link href={`/request-proposal?service=${s.slug}`} className="btn-primary btn-sm flex-1">Get a quote</Link>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}
