import { Header } from "@/components/public/header";
import { Footer } from "@/components/public/footer";
import { WhatsAppFab } from "@/components/public/whatsapp-fab";
import { Tracking } from "@/components/public/tracking";
import { getSettings } from "@/lib/settings";
import { getPublishedServices } from "@/lib/public-data";

export default async function PublicLayout({ children }: { children: React.ReactNode }) {
  const [s, services] = await Promise.all([getSettings(), getPublishedServices()]);
  return (
    <>
      <Header services={services.map((x) => ({ slug: x.slug, name: x.name, icon: x.icon, tagline: x.tagline }))} logoFileId={s.logoFileId} companyShort={s.shortName} />
      <main id="main">{children}</main>
      <Footer s={s} services={services} />
      {s.whatsapp && <WhatsAppFab number={s.whatsapp} company={s.companyName} />}
      <Tracking ga4Id={s.analytics.ga4Id} metaPixelId={s.analytics.metaPixelId} />
    </>
  );
}
