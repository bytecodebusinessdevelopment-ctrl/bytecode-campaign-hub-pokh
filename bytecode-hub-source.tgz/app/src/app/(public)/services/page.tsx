import type { Metadata } from "next";
import Link from "next/link";
import { PageHero, ServiceCard } from "@/components/public/cards";
import { getPublishedServices } from "@/lib/public-data";

export const revalidate = 60;
export const metadata: Metadata = { title: "Our Services", description: "Website development, applications, custom software, SEO, travel SEO content, content writing, digital marketing, video and business automation." };

const GROUPS: Record<string, string> = {
  development: "Website & Software Development",
  growth: "SEO & Digital Growth",
  creative: "Content & Creative",
  consulting: "Automation & Consulting",
};

export default async function ServicesPage() {
  const services = await getPublishedServices();
  const groups = Object.entries(GROUPS).map(([key, label]) => ({ key, label, items: services.filter((s) => s.groupKey === key) })).filter((g) => g.items.length);
  return (
    <>
      <PageHero eyebrow="Our services" title="Everything you need to build and grow online — under one roof." intro="Choose a service to see what's included, related work and documents, or request a proposal for a combination of services." />
      <div className="container space-y-16 py-16">
        {groups.map((g) => (
          <section key={g.key} id={g.key}>
            <h2 className="text-2xl font-bold">{g.label}</h2>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{g.items.map((s) => <ServiceCard key={s.id} s={s} />)}</div>
          </section>
        ))}
        <div className="card flex flex-col items-start justify-between gap-4 p-8 sm:flex-row sm:items-center">
          <div><h2 className="text-xl font-bold">Need more than one service?</h2><p className="mt-1 text-ink-soft">Most projects combine several — tell us what you&apos;re trying to achieve.</p></div>
          <Link href="/request-proposal" className="btn-primary">Request a Proposal</Link>
        </div>
      </div>
    </>
  );
}
