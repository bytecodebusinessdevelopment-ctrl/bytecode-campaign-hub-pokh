import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Icon } from "@/components/icon";
import { PackageCard } from "@/components/public/package-card";
import { ProjectCard, ResourceCard } from "@/components/public/cards";
import { getServiceBySlug, getPublishedProjects, getPublicResources, getPublishedServices } from "@/lib/public-data";

export const revalidate = 60;

export async function generateStaticParams() {
  return (await getPublishedServices().catch(() => [])).map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const s = await getServiceBySlug((await params).slug);
  if (!s) return {};
  return { title: s.seoTitle || s.name, description: s.seoDescription || s.summary || undefined, alternates: { canonical: `/services/${s.slug}` } };
}

export default async function ServicePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const s = await getServiceBySlug(slug);
  if (!s) notFound();
  const [projects, resources, all] = await Promise.all([getPublishedProjects({ service: slug, limit: 6 }), getPublicResources({ service: slug, limit: 6 }), getPublishedServices()]);
  const others = all.filter((x) => x.id !== s.id).slice(0, 4);

  return (
    <>
      <section className="relative overflow-hidden bg-navy text-white">
        <div className="grid-bg absolute inset-0 opacity-60" aria-hidden />
        <div className="absolute -right-24 top-0 h-80 w-80 rounded-full bg-teal/30 blur-3xl" aria-hidden />
        <div className="container relative py-14 sm:py-20">
          <nav className="text-sm text-white/60" aria-label="Breadcrumb"><Link href="/services" className="hover:text-white">Services</Link> / <span className="text-white/90">{s.name}</span></nav>
          <div className="mt-6 flex items-start gap-5">
            <span className="hidden h-16 w-16 shrink-0 place-items-center rounded-2xl bg-white/10 text-teal ring-1 ring-white/20 sm:grid"><Icon name={s.icon} className="h-8 w-8" /></span>
            <div>
              <h1 className="text-3xl font-extrabold text-white sm:text-5xl">{s.name}</h1>
              {s.tagline && <p className="mt-4 max-w-2xl text-lg text-white/75">{s.tagline}</p>}
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link href={`/request-proposal?service=${s.slug}`} className="btn-accent">Request a quotation <ArrowRight className="h-4 w-4" /></Link>
                {projects.length > 0 && <a href="#work" className="btn-light">See related work</a>}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container grid gap-12 lg:grid-cols-[1.2fr_1fr]">
          <div>
            <h2 className="text-2xl font-bold">Overview</h2>
            {s.description && <p className="mt-4 whitespace-pre-line text-lg leading-relaxed text-ink-soft">{s.description}</p>}
            {s.sections.map((sec) => (
              <div key={sec.title} className="mt-10">
                <h3 className="text-xl font-bold">{sec.title}</h3>
                <p className="mt-3 whitespace-pre-line leading-relaxed text-ink-soft">{sec.body}</p>
              </div>
            ))}
          </div>
          <aside className="card h-fit p-6 lg:sticky lg:top-24">
            <h2 className="text-lg font-bold">What we offer</h2>
            <ul className="mt-4 space-y-3">
              {s.offerings.map((o) => <li key={o} className="flex gap-3 text-ink-soft"><CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-teal" />{o}</li>)}
            </ul>
            <Link href={`/request-proposal?service=${s.slug}`} className="btn-primary mt-6 w-full">Discuss your project</Link>
          </aside>
        </div>
      </section>

      <section className="section bg-surface" id="packages">
        <div className="container">
          <p className="eyebrow">Packages & pricing</p>
          <h2 className="h-section mt-3">{s.packages.length ? "Choose a package" : "Pricing"}</h2>
          {s.packages.length > 0 ? (
            <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">{s.packages.map((p) => <PackageCard key={p.id} p={p} serviceSlug={s.slug} />)}</div>
          ) : (
            <div className="card mt-8 flex flex-col items-start gap-4 p-8 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="font-display text-2xl font-extrabold text-navy">Custom quotation</p>
                <p className="mt-2 max-w-xl text-ink-soft">{s.pricingNote ?? "Pricing depends on your requirements. Tell us what you need and we will send a clear, itemised quotation."}</p>
              </div>
              <Link href={`/request-proposal?service=${s.slug}`} className="btn-primary">Request a quotation</Link>
            </div>
          )}
        </div>
      </section>

      {projects.length > 0 && (
        <section className="section" id="work">
          <div className="container">
            <p className="eyebrow">Related work</p>
            <h2 className="h-section mt-3">Projects using this service</h2>
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{projects.map((p) => <ProjectCard key={p.id} p={p} />)}</div>
          </div>
        </section>
      )}

      {resources.length > 0 && (
        <section className="section bg-surface">
          <div className="container">
            <p className="eyebrow">Documents & samples</p>
            <h2 className="h-section mt-3">Related resources</h2>
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{resources.map((r) => <ResourceCard key={r.id} r={r} />)}</div>
          </div>
        </section>
      )}

      <section className="section">
        <div className="container">
          <h2 className="text-2xl font-bold">Other services</h2>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {others.map((o) => (
              <Link key={o.id} href={`/services/${o.slug}`} className="flex items-center gap-3 rounded-2xl border border-line p-4 hover:border-brand">
                <Icon name={o.icon} className="h-5 w-5 text-brand" /><span className="font-medium text-navy">{o.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
