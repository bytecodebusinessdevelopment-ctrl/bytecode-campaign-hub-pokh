import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { HomeView } from "@/components/public/home-view";
import { getCampaignBySlug } from "@/lib/public-data";

export const revalidate = 60;

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const c = await getCampaignBySlug((await params).slug);
  if (!c) return {};
  return { title: c.location ? `Digital solutions for businesses in ${c.location.split(",")[0]}` : c.name, description: c.heroSubtitle ?? undefined };
}

/** Campaign landing page, e.g. /c/pokhara — campaign-specific hero, intro and resource collection. */
export default async function CampaignPage({ params }: { params: Promise<{ slug: string }> }) {
  const c = await getCampaignBySlug((await params).slug);
  if (!c) notFound();
  return <HomeView campaign={c} />;
}
