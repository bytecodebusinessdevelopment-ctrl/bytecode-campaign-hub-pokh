import type { Metadata } from "next";
import { PageHero } from "@/components/public/cards";
import { ProseText } from "@/components/public/prose-text";
import { getSettings } from "@/lib/settings";
import { defaultTerms } from "@/lib/legal-defaults";

export const revalidate = 300;
export const metadata: Metadata = { title: "Terms of Use" };

export default async function TermsPage() {
  const s = await getSettings();
  return (
    <>
      <PageHero eyebrow="Legal" title="Terms of Use" />
      <div className="container max-w-3xl py-14"><ProseText text={s.termsOfUse || defaultTerms(s.companyName, s.email)} /></div>
    </>
  );
}
