import { HomeView } from "@/components/public/home-view";
import { getDefaultCampaign } from "@/lib/leads";
import { getSettings } from "@/lib/settings";
import { siteUrl } from "@/lib/request";

export const revalidate = 60;

export default async function HomePage() {
  const [campaign, s] = await Promise.all([getDefaultCampaign(), getSettings()]);
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: s.companyName,
    url: siteUrl(),
    email: s.email || undefined,
    telephone: s.phone || undefined,
    address: s.address ? { "@type": "PostalAddress", streetAddress: s.address, addressCountry: "NP" } : undefined,
    sameAs: Object.values(s.social).filter(Boolean),
  };
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      {/* The company home page uses company-wide copy; campaign-specific copy lives at /c/<campaign>. */}
      <HomeView campaign={campaign?.status === "active" ? { ...campaign, heroTitle: null, heroSubtitle: null, landingIntro: null } : null} />
    </>
  );
}
