import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Download, ExternalLink } from "lucide-react";
import { fileKindIcon, fileTypeLabel } from "@/components/public/cards";
import { getResourceBySlug } from "@/lib/public-data";
import { getCurrentUser } from "@/lib/auth";
import { videoEmbedUrl, figmaEmbedUrl, officeViewerUrl } from "@/lib/embed";
import { siteUrl } from "@/lib/request";
import { formatBytes, formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const r = await getResourceBySlug((await params).slug);
  return r ? { title: r.title, description: r.description ?? undefined } : { robots: { index: false } };
}

export default async function ResourcePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const user = await getCurrentUser();
  const r = await getResourceBySlug(slug, Boolean(user)); // signed-in team members can also open "Internal only" resources
  if (!r) notFound();
  const mime = r.file?.mimeType ?? "";
  const fileSrc = r.fileId ? `/api/files/${r.fileId}` : null;
  const isOffice = /word|presentation|powerpoint|spreadsheet|excel|msword/.test(mime);
  const publicBase = siteUrl();
  const canUseOfficeViewer = isOffice && r.visibility === "public" && !/localhost|127\.0\.0\.1/.test(publicBase);
  const I = fileKindIcon(mime, r.kind);
  const linkEmbed = r.kind === "video_link" ? videoEmbedUrl(r.url) : r.kind === "figma" ? figmaEmbedUrl(r.url) : null;

  return (
    <div className="container py-10">
      <nav className="text-sm text-ink-muted" aria-label="Breadcrumb"><Link href="/resources" className="hover:text-brand">Resources</Link> / <span className="text-navy">{r.title}</span></nav>
      <div className="mt-5 grid gap-10 lg:grid-cols-[1.6fr_1fr]">
        <div className="min-w-0">
          {r.visibility === "internal" && <p className="placeholder-note mb-4">Internal only — visible to signed-in ByteCode team members. Do not share this link with clients.</p>}
          <div className="flex items-start gap-4">
            <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-surface text-brand ring-1 ring-line"><I className="h-7 w-7" /></span>
            <div>
              <p className="text-sm text-ink-muted">{[r.category?.name, fileTypeLabel(mime, r.kind)].filter(Boolean).join(" · ")}</p>
              <h1 className="text-2xl font-extrabold sm:text-3xl">{r.title}</h1>
            </div>
          </div>
          {r.description && <p className="mt-5 whitespace-pre-line text-ink-soft">{r.description}</p>}

          <div className="mt-8">
            {fileSrc && mime === "application/pdf" && (
              <iframe src={`${fileSrc}#view=FitH`} title={r.title} className="h-[80vh] w-full rounded-2xl border border-line" />
            )}
            {fileSrc && mime.startsWith("image/") && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={fileSrc} alt={r.title} className="w-full rounded-2xl border border-line" />
            )}
            {fileSrc && mime.startsWith("video/") && <video src={fileSrc} controls preload="metadata" className="w-full rounded-2xl border border-line bg-black" />}
            {fileSrc && canUseOfficeViewer && (
              <iframe src={officeViewerUrl(`${publicBase}${fileSrc}`)} title={r.title} className="h-[75vh] w-full rounded-2xl border border-line" />
            )}
            {fileSrc && isOffice && !canUseOfficeViewer && (
              <div className="card p-6 text-sm text-ink-soft">An online preview is available for public documents once the site is live on its public domain. Use the download button to open this file.</div>
            )}
            {linkEmbed && <div className="aspect-video overflow-hidden rounded-2xl border border-line bg-black"><iframe src={linkEmbed} title={r.title} className="h-full w-full" allow="fullscreen; encrypted-media" loading="lazy" /></div>}
            {!fileSrc && !linkEmbed && r.previewFileId && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={`/api/files/${r.previewFileId}`} alt={`${r.title} preview`} className="w-full rounded-2xl border border-line" />
            )}
          </div>
        </div>
        <aside className="space-y-5">
          <div className="card p-6">
            {r.kind === "file" && r.fileId ? (
              r.allowDownload ? (
                <a href={`/api/files/${r.fileId}?download=1&r=${r.slug}`} className="btn-primary w-full"><Download className="h-4 w-4" /> Download {fileTypeLabel(mime, r.kind)}</a>
              ) : <p className="text-sm text-ink-muted">This document is available to view online only.</p>
            ) : r.url ? (
              <a href={r.url} target="_blank" rel="noopener noreferrer" className="btn-primary w-full">Open <ExternalLink className="h-4 w-4" /></a>
            ) : null}
            <dl className="mt-5 space-y-2 text-sm">
              {r.file && <div className="flex justify-between"><dt className="text-ink-muted">Size</dt><dd>{formatBytes(r.file.sizeBytes)}</dd></div>}
              {r.industry && <div className="flex justify-between"><dt className="text-ink-muted">Industry</dt><dd>{r.industry.name}</dd></div>}
              <div className="flex justify-between"><dt className="text-ink-muted">Updated</dt><dd>{formatDate(r.updatedAt)}</dd></div>
            </dl>
          </div>
          {r.services.length > 0 && (
            <div className="card p-6"><h2 className="font-bold">Related services</h2><ul className="mt-3 space-y-2">{r.services.map(({ service }) => <li key={service.id}><Link href={`/services/${service.slug}`} className="text-brand hover:underline">{service.name}</Link></li>)}</ul></div>
          )}
          {r.projects.filter((p) => p.project.status === "published").length > 0 && (
            <div className="card p-6"><h2 className="font-bold">Related projects</h2><ul className="mt-3 space-y-2">{r.projects.filter((p) => p.project.status === "published").map(({ project }) => <li key={project.slug}><Link href={`/portfolio/${project.slug}`} className="text-brand hover:underline">{project.title}</Link></li>)}</ul></div>
          )}
          <div className="card bg-surface p-6"><h2 className="font-bold">Have questions?</h2><p className="mt-2 text-sm text-ink-soft">We&apos;re happy to walk you through any of our materials.</p><Link href="/request-proposal" className="btn-outline mt-4 w-full">Request a Proposal</Link></div>
        </aside>
      </div>
    </div>
  );
}
