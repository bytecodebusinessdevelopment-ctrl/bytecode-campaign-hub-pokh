import type { Metadata } from "next";
import Link from "next/link";
import { Search } from "lucide-react";
import { PageHero, ResourceCard, EmptyState } from "@/components/public/cards";
import { getIndustries, getPublicResources, getPublishedServices, getResourceCategories } from "@/lib/public-data";
import { getSettings } from "@/lib/settings";

export const revalidate = 60;
export const metadata: Metadata = { title: "Resources & Downloads", description: "Company profile, service brochures, packages, samples, case studies and demonstrations from ByteCode Developers." };

const TYPES = [["pdf", "PDF"], ["word", "Word"], ["powerpoint", "PowerPoint"], ["excel", "Excel"], ["image", "Images"], ["video", "Video"], ["link", "Links & demos"]];

type SP = { q?: string; category?: string; industry?: string; service?: string; type?: string };

export default async function ResourcesPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const q = sp.q?.slice(0, 80);
  const [resources, categories, industries, services, s] = await Promise.all([
    getPublicResources({ ...sp, q }), getResourceCategories(), getIndustries(), getPublishedServices(), getSettings(),
  ]);
  const filtered = Boolean(q || sp.category || sp.industry || sp.service || sp.type);
  return (
    <>
      <PageHero eyebrow="Resources & showcase" title={s.publicResourcesLabel} intro="Browse and download our company profile, service brochures, packages, content samples, case studies and technical demonstrations." />
      <div className="container py-10">
        <form method="get" className="card grid gap-3 p-4 md:grid-cols-[2fr_repeat(4,1fr)_auto]" role="search">
          <label className="relative">
            <span className="sr-only">Search by title</span>
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
            <input name="q" defaultValue={q} placeholder="Search by title…" className="input pl-9" />
          </label>
          <Select name="category" label="Category" value={sp.category} options={categories.map((c) => [c.slug, c.name])} />
          <Select name="industry" label="Industry" value={sp.industry} options={industries.map((c) => [c.slug, c.name])} />
          <Select name="service" label="Service" value={sp.service} options={services.map((c) => [c.slug, c.name])} />
          <Select name="type" label="File type" value={sp.type} options={TYPES} />
          <button className="btn-primary">Filter</button>
        </form>
        <div className="mt-8">
          {resources.length ? (
            <>
              <p className="mb-4 text-sm text-ink-muted">{resources.length} resource{resources.length === 1 ? "" : "s"}{filtered && <> · <Link href="/resources" className="text-brand">Clear filters</Link></>}</p>
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{resources.map((r) => <ResourceCard key={r.id} r={r} />)}</div>
            </>
          ) : (
            <EmptyState title={filtered ? "No resources match your search" : "Resources are on their way"} body={filtered ? "Try different keywords or filters." : "Our company profile, brochures and samples will appear here. Contact us and we'll send what you need."}>
              {filtered ? <Link href="/resources" className="btn-outline">Clear filters</Link> : <Link href="/contact" className="btn-primary">Contact us</Link>}
            </EmptyState>
          )}
        </div>
      </div>
    </>
  );
}

function Select({ name, label, value, options }: { name: string; label: string; value?: string; options: (string[] | [string, string])[] }) {
  return (
    <label>
      <span className="sr-only">{label}</span>
      <select name={name} defaultValue={value ?? ""} className="input">
        <option value="">All {label.toLowerCase()}s</option>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </label>
  );
}
