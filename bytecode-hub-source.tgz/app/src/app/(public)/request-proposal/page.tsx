import type { Metadata } from "next";
import { Clock, MessageCircle, ShieldCheck, Phone } from "lucide-react";
import { eq } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { EnquiryForm } from "@/components/forms/enquiry-form";
import { getEnquiryOptions } from "@/lib/public-data";
import { getSettings } from "@/lib/settings";
import { issueFormToken } from "@/lib/form-token";
import { telLink, whatsappLink } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Request a Proposal", description: "Tell us about your business and requirements — we'll come back with a plan and quotation." };

export default async function RequestProposalPage({ searchParams }: { searchParams: Promise<{ service?: string; package?: string }> }) {
  const sp = await searchParams;
  const [opts, s] = await Promise.all([getEnquiryOptions(), getSettings()]);
  let preselect: string[] = [];
  if (sp.service) {
    const [svc] = await db.select({ id: t.services.id }).from(t.services).where(eq(t.services.slug, sp.service)).limit(1);
    if (svc) preselect = (await db.select({ key: t.enquiryServices.key }).from(t.enquiryServices).where(eq(t.enquiryServices.serviceId, svc.id))).map((x) => x.key).slice(0, 1);
  }
  const wa = whatsappLink(s.whatsapp);
  return (
    <div className="bg-surface">
      <div className="container grid gap-10 py-10 sm:py-14 lg:grid-cols-[1fr_320px]">
        <div className="min-w-0">
          <p className="eyebrow">Request a proposal</p>
          <h1 className="mt-2 text-3xl font-extrabold sm:text-4xl">Tell us about your project</h1>
          <p className="mt-3 max-w-2xl text-ink-soft">It takes about 3–5 minutes. We&apos;ll only ask questions relevant to the services you choose, and you can go back at any time.</p>
          <div className="mt-8">
            <EnquiryForm {...opts} formToken={issueFormToken()} preselectKeys={preselect} packageName={sp.package?.slice(0, 120) ?? null} turnstileSiteKey={process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY || undefined} />
          </div>
        </div>
        <aside className="space-y-4 lg:pt-24">
          <div className="card p-6">
            <h2 className="font-bold">What happens next?</h2>
            <ol className="mt-4 space-y-4 text-sm text-ink-soft">
              <li className="flex gap-3"><span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-brand text-xs font-bold text-white">1</span>We review your requirements.</li>
              <li className="flex gap-3"><span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-brand text-xs font-bold text-white">2</span>We contact you to clarify details or arrange a meeting.</li>
              <li className="flex gap-3"><span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-brand text-xs font-bold text-white">3</span>You receive a clear proposal and quotation.</li>
            </ol>
          </div>
          <div className="card space-y-3 p-6 text-sm">
            <p className="flex items-center gap-2 text-ink-soft"><Clock className="h-4 w-4 text-teal" /> Prefer to talk instead?</p>
            {s.phone && <a href={telLink(s.phone)!} className="btn-outline w-full"><Phone className="h-4 w-4" /> {s.phone}</a>}
            {wa && <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-outline w-full"><MessageCircle className="h-4 w-4" /> WhatsApp</a>}
          </div>
          <p className="flex items-start gap-2 px-2 text-xs text-ink-muted"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-teal" /> Your details are used only to respond to your enquiry. See our Privacy Policy.</p>
        </aside>
      </div>
    </div>
  );
}
