import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { PageHero, ServiceCard } from "@/components/public/cards";
import { getSettings } from "@/lib/settings";
import { getPublishedServices } from "@/lib/public-data";

export const revalidate = 300;
export const metadata: Metadata = { title: "About ByteCode", description: "ByteCode Developers is a Nepal-based technology and software development company operating from Kathmandu." };

export default async function AboutPage() {
  const [s, services] = await Promise.all([getSettings(), getPublishedServices()]);
  return (
    <>
      <PageHero eyebrow={`About ${s.shortName}`} title="We build. You move forward." intro={s.aboutIntro} />
      <section className="section">
        <div className="container grid gap-12 lg:grid-cols-2">
          <div>
            <h2 className="h-section">Who we are</h2>
            <div className="mt-5 space-y-4 text-lg leading-relaxed text-ink-soft">
              {(s.aboutBody || `${s.companyName} brings website development, application and software development, SEO, content, digital marketing and video production together in one team — so businesses can plan, build and grow their digital presence with a single partner.`)
                .split(/\n{2,}/).map((p, i) => <p key={i}>{p}</p>)}
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {s.whyChoose.map((w) => (
              <div key={w.title} className="card p-6"><h3 className="font-bold">{w.title}</h3><p className="mt-2 text-sm text-ink-soft">{w.body}</p></div>
            ))}
          </div>
        </div>
      </section>
      <section className="section bg-surface">
        <div className="container">
          <h2 className="h-section">What we do</h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{services.map((x) => <ServiceCard key={x.id} s={x} />)}</div>
        </div>
      </section>
      <section className="section">
        <div className="container flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
          <div><h2 className="text-2xl font-bold">Ready to talk?</h2><p className="mt-2 text-ink-soft">{s.address}</p></div>
          <div className="flex gap-3"><Link href="/contact" className="btn-outline">Contact</Link><Link href="/request-proposal" className="btn-primary">Request a Proposal <ArrowRight className="h-4 w-4" /></Link></div>
        </div>
      </section>
    </>
  );
}
