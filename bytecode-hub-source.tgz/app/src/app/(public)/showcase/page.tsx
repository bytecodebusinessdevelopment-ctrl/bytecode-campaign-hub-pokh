import type { Metadata } from "next";
import Link from "next/link";
import { PageHero, DemoCard, EmptyState } from "@/components/public/cards";
import { getPublicDemos } from "@/lib/public-data";

export const revalidate = 60;
export const metadata: Metadata = { title: "UI/UX & Live Demos", description: "Live websites, Vercel deployments, UI/UX previews and Figma prototypes by ByteCode Developers." };

export default async function ShowcasePage() {
  const demos = await getPublicDemos();
  return (
    <>
      <PageHero eyebrow="Showcase" title="UI/UX & live demonstrations" intro="Interactive frontends, UI/UX concepts and prototypes you can open and explore. Each item is labelled so you always know whether it is a completed client project, an internal demonstration or a concept." />
      <div className="container py-12">
        {demos.length ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{demos.map((d) => <DemoCard key={d.id} d={d} />)}</div>
        ) : (
          <EmptyState title="Live demos coming soon" body="We're preparing interactive demonstrations. Ask us for a live walkthrough during a meeting.">
            <Link href="/portfolio" className="btn-outline">Portfolio</Link>
            <Link href="/request-proposal" className="btn-primary">Request a walkthrough</Link>
          </EmptyState>
        )}
      </div>
    </>
  );
}
