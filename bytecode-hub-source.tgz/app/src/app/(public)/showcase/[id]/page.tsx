import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ExternalLink } from "lucide-react";
import { ClassificationBadge } from "@/components/public/cards";
import { EmbedFrame } from "@/components/public/embed-frame";
import { getDemo } from "@/lib/public-data";
import { DEMO_TYPE_LABELS } from "@/lib/enquiry-config";
import { figmaEmbedUrl, videoEmbedUrl } from "@/lib/embed";

export const revalidate = 60;

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const d = await getDemo((await params).id);
  return d ? { title: d.title, description: d.description ?? undefined } : {};
}

export default async function DemoPage({ params }: { params: Promise<{ id: string }> }) {
  const d = await getDemo((await params).id);
  if (!d) notFound();
  const embed = d.demoType === "figma" ? figmaEmbedUrl(d.url) : d.demoType === "video" ? videoEmbedUrl(d.url) : d.embeddable ? d.url : null;
  return (
    <div className="container py-10">
      <nav className="text-sm text-ink-muted" aria-label="Breadcrumb"><Link href="/showcase" className="hover:text-brand">Showcase</Link> / <span className="text-navy">{d.title}</span></nav>
      <div className="mt-4 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <div className="flex flex-wrap gap-2"><ClassificationBadge value={d.classification} /><span className="badge bg-surface text-ink-soft">{DEMO_TYPE_LABELS[d.demoType]}</span>{d.status === "beta" && <span className="badge bg-amber-100 text-amber-800">Beta</span>}</div>
          <h1 className="mt-3 text-3xl font-extrabold sm:text-4xl">{d.title}</h1>
          {d.description && <p className="mt-3 max-w-2xl text-ink-soft">{d.description}</p>}
          {d.technologies.length > 0 && <div className="mt-4 flex flex-wrap gap-2">{d.technologies.map((x) => <span key={x} className="chip">{x}</span>)}</div>}
        </div>
        <div className="flex gap-2">
          {d.project?.status === "published" && <Link href={`/portfolio/${d.project.slug}`} className="btn-outline">Project details</Link>}
          <a href={d.url} target="_blank" rel="noopener noreferrer" className="btn-primary">Open <ExternalLink className="h-4 w-4" /></a>
        </div>
      </div>
      <div className="mt-8">
        {embed && d.demoType !== "figma" && d.demoType !== "video" ? (
          <EmbedFrame url={embed} title={d.title} />
        ) : embed ? (
          <div className="aspect-video overflow-hidden rounded-2xl border border-line bg-black"><iframe src={embed} title={d.title} className="h-full w-full" allow="fullscreen; encrypted-media" loading="lazy" /></div>
        ) : (
          <div className="card overflow-hidden">
            {d.previewFileId && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={`/api/files/${d.previewFileId}`} alt={`${d.title} preview`} className="w-full" />
            )}
            <div className="flex flex-col items-start gap-3 p-6 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-ink-soft">This demo opens in a new tab.</p>
              <a href={d.url} target="_blank" rel="noopener noreferrer" className="btn-primary">Open live demo <ExternalLink className="h-4 w-4" /></a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
