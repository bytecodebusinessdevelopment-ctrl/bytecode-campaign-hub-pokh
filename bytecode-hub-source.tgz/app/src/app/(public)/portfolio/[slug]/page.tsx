import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ExternalLink, Rocket, Figma, Images, BookOpen, Download, CheckCircle2 } from "lucide-react";
import { ClassificationBadge } from "@/components/public/cards";
import { getProjectBySlug } from "@/lib/public-data";
import { videoEmbedUrl } from "@/lib/embed";
import { DEMO_TYPE_LABELS } from "@/lib/enquiry-config";

export const revalidate = 60;

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const p = await getProjectBySlug((await params).slug);
  if (!p) return {};
  return { title: p.title, description: p.summary ?? undefined, openGraph: p.coverFileId ? { images: [`/api/files/${p.coverFileId}`] } : undefined };
}

export default async function ProjectPage({ params }: { params: Promise<{ slug: string }> }) {
  const p = await getProjectBySlug((await params).slug);
  if (!p) notFound();
  const desktop = p.media.filter((m) => m.kind === "desktop");
  const mobile = p.media.filter((m) => m.kind === "mobile");
  const gallery = p.media.filter((m) => m.kind === "gallery");
  const video = videoEmbedUrl(p.videoUrl);
  const vercel = p.demos.find((d) => d.demoType === "vercel");
  const uiux = p.demos.find((d) => d.demoType === "uiux_preview" || d.demoType === "figma");
  const resources = p.resources.map((r) => r.resource).filter((r) => r.published && r.visibility === "public");
  const hasCaseStudy = Boolean(p.objectives || p.problems || p.solution);

  return (
    <>
      <section className="relative overflow-hidden bg-navy text-white">
        <div className="grid-bg absolute inset-0 opacity-60" aria-hidden />
        <div className="container relative py-12 sm:py-16">
          <nav className="text-sm text-white/60" aria-label="Breadcrumb"><Link href="/portfolio" className="hover:text-white">Portfolio</Link> / <span className="text-white/90">{p.title}</span></nav>
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <ClassificationBadge value={p.classification} className="bg-white text-navy" />
            {p.industry && <span className="badge bg-white/10 text-white/90">{p.industry.name}</span>}
            {p.projectType && <span className="badge bg-white/10 text-white/90">{p.projectType.name}</span>}
          </div>
          <h1 className="mt-4 max-w-4xl text-3xl font-extrabold text-white sm:text-5xl">{p.title}</h1>
          {p.clientNamePublic && p.clientName && <p className="mt-3 text-white/70">Client: <span className="font-semibold text-white">{p.clientName}</span></p>}
          {p.summary && <p className="mt-4 max-w-2xl text-lg text-white/75">{p.summary}</p>}
          <div className="mt-8 flex flex-wrap gap-3">
            {p.liveUrl && <a href={p.liveUrl} target="_blank" rel="noopener noreferrer" className="btn-accent">View Live Website <ExternalLink className="h-4 w-4" /></a>}
            {vercel && <a href={vercel.url} target="_blank" rel="noopener noreferrer" className="btn-light"><Rocket className="h-4 w-4" /> View Live Demo</a>}
            {uiux && <a href={uiux.url} target="_blank" rel="noopener noreferrer" className="btn-light"><Figma className="h-4 w-4" /> Explore UI/UX</a>}
            {p.media.length > 0 && <a href="#screenshots" className="btn-light"><Images className="h-4 w-4" /> View Screenshots</a>}
            {hasCaseStudy && <a href="#case-study" className="btn-light"><BookOpen className="h-4 w-4" /> View Case Study</a>}
          </div>
        </div>
      </section>

      {p.coverFileId && (
        <div className="container -mt-2 pt-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={`/api/files/${p.coverFileId}`} alt={`${p.title} — preview`} className="w-full rounded-3xl border border-line shadow-lift" />
        </div>
      )}

      <section className="section">
        <div className="container grid gap-12 lg:grid-cols-[1.3fr_1fr]">
          <div className="space-y-10">
            {p.description && <div><h2 className="text-2xl font-bold">About the project</h2><p className="mt-4 whitespace-pre-line text-lg leading-relaxed text-ink-soft">{p.description}</p></div>}
            {hasCaseStudy && (
              <div id="case-study" className="scroll-mt-24 space-y-8">
                {p.objectives && <Block title="Business objectives" body={p.objectives} />}
                {p.problems && <Block title="Problems addressed" body={p.problems} />}
                {p.solution && <Block title="Solution delivered" body={p.solution} />}
              </div>
            )}
            {p.features.length > 0 && (
              <div>
                <h2 className="text-xl font-bold">Features and functionality</h2>
                <ul className="mt-4 grid gap-2 sm:grid-cols-2">{p.features.map((f) => <li key={f} className="flex gap-2 text-ink-soft"><CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-teal" />{f}</li>)}</ul>
              </div>
            )}
            {video && (
              <div>
                <h2 className="text-xl font-bold">Video walkthrough</h2>
                <div className="mt-4 aspect-video overflow-hidden rounded-2xl border border-line bg-black"><iframe src={video} title="Video walkthrough" className="h-full w-full" allow="encrypted-media; picture-in-picture; fullscreen" loading="lazy" /></div>
              </div>
            )}
          </div>
          <aside className="space-y-6">
            {p.technologies.length > 0 && (
              <div className="card p-6"><h2 className="font-bold">Technologies used</h2><div className="mt-3 flex flex-wrap gap-2">{p.technologies.map((x) => <span key={x} className="chip">{x}</span>)}</div></div>
            )}
            {p.services.length > 0 && (
              <div className="card p-6"><h2 className="font-bold">Related services</h2><ul className="mt-3 space-y-2">{p.services.map(({ service }) => <li key={service.id}><Link href={`/services/${service.slug}`} className="text-brand hover:underline">{service.name}</Link></li>)}</ul></div>
            )}
            {p.demos.length > 0 && (
              <div className="card p-6"><h2 className="font-bold">Demonstration links</h2>
                <ul className="mt-3 space-y-2">{p.demos.map((d) => <li key={d.id}><a href={d.url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between gap-2 rounded-xl border border-line px-3 py-2.5 text-sm hover:border-brand"><span><span className="block font-medium text-navy">{d.title}</span><span className="text-xs text-ink-muted">{DEMO_TYPE_LABELS[d.demoType]}</span></span><ExternalLink className="h-4 w-4 text-brand" /></a></li>)}</ul>
              </div>
            )}
            {resources.length > 0 && (
              <div className="card p-6"><h2 className="font-bold">Related documents</h2>
                <ul className="mt-3 space-y-2">{resources.map((r) => <li key={r.id}><Link href={`/resources/${r.slug}`} className="flex items-center justify-between gap-2 rounded-xl border border-line px-3 py-2.5 text-sm hover:border-brand"><span className="font-medium text-navy">{r.title}</span><Download className="h-4 w-4 text-brand" /></Link></li>)}</ul>
              </div>
            )}
            <div className="card bg-surface p-6"><h2 className="font-bold">Want something similar?</h2><p className="mt-2 text-sm text-ink-soft">Tell us about your business and we&apos;ll show you what&apos;s possible.</p><Link href="/request-proposal" className="btn-primary mt-4 w-full">Request a Proposal</Link></div>
          </aside>
        </div>
      </section>

      {p.media.length > 0 && (
        <section id="screenshots" className="section scroll-mt-20 bg-surface">
          <div className="container space-y-12">
            <Gallery title="Desktop screenshots" items={desktop} cols="md:grid-cols-2" />
            <Gallery title="Mobile screenshots" items={mobile} cols="grid-cols-2 sm:grid-cols-3 lg:grid-cols-4" />
            <Gallery title="Gallery" items={gallery} cols="sm:grid-cols-2 lg:grid-cols-3" />
          </div>
        </section>
      )}
    </>
  );
}

function Block({ title, body }: { title: string; body: string }) {
  return <div><h2 className="text-xl font-bold">{title}</h2><p className="mt-3 whitespace-pre-line leading-relaxed text-ink-soft">{body}</p></div>;
}

function Gallery({ title, items, cols }: { title: string; items: { id: string; fileId: string; caption: string | null }[]; cols: string }) {
  if (!items.length) return null;
  return (
    <div>
      <h2 className="text-xl font-bold">{title}</h2>
      <div className={`mt-5 grid gap-5 ${cols}`}>
        {items.map((m) => (
          <figure key={m.id}>
            <a href={`/api/files/${m.fileId}`} target="_blank" rel="noopener noreferrer">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={`/api/files/${m.fileId}`} alt={m.caption ?? title} loading="lazy" className="w-full rounded-2xl border border-line bg-white shadow-card" />
            </a>
            {m.caption && <figcaption className="mt-2 text-sm text-ink-muted">{m.caption}</figcaption>}
          </figure>
        ))}
      </div>
    </div>
  );
}
