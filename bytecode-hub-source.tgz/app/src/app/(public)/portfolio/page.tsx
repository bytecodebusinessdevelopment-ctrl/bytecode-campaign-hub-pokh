import type { Metadata } from "next";
import Link from "next/link";
import { ExternalLink } from "lucide-react";
import { PageHero, ProjectCard, EmptyState } from "@/components/public/cards";
import { FilterChips } from "@/components/public/filter-bar";
import { getIndustries, getProjectTypes, getPublishedProjects, getPublicDemos } from "@/lib/public-data";
import { getSettings } from "@/lib/settings";

export const revalidate = 60;
export const metadata: Metadata = { title: "Portfolio", description: "Websites, applications, systems and digital projects delivered by ByteCode Developers." };

export default async function PortfolioPage({ searchParams }: { searchParams: Promise<{ industry?: string; type?: string }> }) {
  const sp = await searchParams;
  const [projects, industries, types, demos, s] = await Promise.all([
    getPublishedProjects({ industry: sp.industry, type: sp.type }), getIndustries(), getProjectTypes(), getPublicDemos({ limit: 1 }), getSettings(),
  ]);
  return (
    <>
      <PageHero eyebrow="Portfolio" title="Work we're proud of." intro="Explore completed client projects by industry and project type. Each project is clearly labelled — completed client work, internal demonstrations, UI/UX concepts and prototypes are never mixed up.">
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/showcase" className="btn-light">UI/UX & live demos</Link>
        </div>
      </PageHero>
      <div className="container py-12">
        <div className="space-y-3">
          <FilterChips basePath="/portfolio" param="industry" current={sp.industry} params={sp} options={industries.map((i) => ({ value: i.slug, label: i.name }))} />
          <FilterChips basePath="/portfolio" param="type" current={sp.type} params={sp} options={types.map((i) => ({ value: i.slug, label: i.name }))} />
        </div>
        <div className="mt-10">
          {projects.length ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{projects.map((p) => <ProjectCard key={p.id} p={p} />)}</div>
          ) : (
            <EmptyState
              title={sp.industry || sp.type ? "No projects match these filters yet" : "Our portfolio is being updated"}
              body={sp.industry || sp.type ? "Try another industry or project type." : "We're adding detailed case studies with screenshots and live links. Ask us for a live walkthrough of relevant projects for your industry."}
            >
              {(sp.industry || sp.type) && <Link href="/portfolio" className="btn-outline">Clear filters</Link>}
              {s.externalPortfolioUrl && <a href={s.externalPortfolioUrl} target="_blank" rel="noopener noreferrer" className="btn-outline">Current portfolio <ExternalLink className="h-4 w-4" /></a>}
              {demos.length > 0 && <Link href="/showcase" className="btn-outline">Live demos</Link>}
              <Link href="/request-proposal" className="btn-primary">Request a walkthrough</Link>
            </EmptyState>
          )}
        </div>
      </div>
    </>
  );
}
