import type { Metadata } from "next";
import { PageHero } from "@/components/public/cards";
import { ProseText } from "@/components/public/prose-text";
import { getSettings } from "@/lib/settings";
import { defaultPrivacyPolicy } from "@/lib/legal-defaults";

export const revalidate = 300;
export const metadata: Metadata = { title: "Privacy Policy" };

export default async function PrivacyPage() {
  const s = await getSettings();
  return (
    <>
      <PageHero eyebrow="Legal" title="Privacy Policy" />
      <div className="container max-w-3xl py-14"><ProseText text={s.privacyPolicy || defaultPrivacyPolicy(s.companyName, s.email, s.address, s.leadRetentionMonths)} /></div>
    </>
  );
}
