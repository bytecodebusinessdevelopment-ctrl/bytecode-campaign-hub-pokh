"use server";
import { after } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { createLead } from "@/lib/leads";
import { processSyncJobs } from "@/lib/sheets";
import { notifyNewEnquiry, sendEnquiryAcknowledgement } from "@/lib/notify";
import { rateLimit } from "@/lib/rate-limit";
import { clientIp, hashIp } from "@/lib/request";
import { checkFormToken, verifyTurnstile } from "@/lib/form-token";
import { publicEnquirySchema, contactFormSchema, flattenErrors, type PublicEnquiryInput } from "@/lib/validation";
import { safeUrl } from "@/lib/utils";

export type SubmitResult =
  | { ok: true; leadCode: string }
  | { ok: false; error: string; fieldErrors?: Record<string, string> };

async function spamGuard(hp: string | undefined, formToken: string, turnstile?: string | null) {
  const ip = await clientIp();
  const ipHash = hashIp(ip);
  if (hp) return { blocked: true as const, ipHash, silent: true };
  const tok = checkFormToken(formToken);
  if (!tok.ok) return { blocked: true as const, ipHash, error: tok.reason === "too fast" ? "Please take a moment to review your details and try again." : "Your session expired. Please refresh the page and try again." };
  if (!(await rateLimit(`enquiry:${ipHash}`, 6, 3600))) return { blocked: true as const, ipHash, error: "Too many submissions from your connection. Please try again later or contact us by phone." };
  if (!(await verifyTurnstile(turnstile, ip))) return { blocked: true as const, ipHash, error: "Please complete the security check." };
  return { blocked: false as const, ipHash };
}

async function campaignFromAttribution(utm?: Record<string, string>) {
  const slug = utm?.campaign?.toLowerCase().replace(/[^a-z0-9-]/g, "");
  if (!slug) return null;
  const [c] = await db.select({ id: t.campaigns.id }).from(t.campaigns).where(eq(t.campaigns.slug, slug)).limit(1);
  return c?.id ?? null;
}

export async function submitEnquiry(input: PublicEnquiryInput): Promise<SubmitResult> {
  const parsed = publicEnquirySchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: "Please check the highlighted fields.", fieldErrors: flattenErrors(parsed.error) };
  const d = parsed.data;
  const guard = await spamGuard(d.hp, d.formToken, d.turnstileToken);
  if (guard.blocked) {
    // Honeypot hits get a fake success so bots learn nothing.
    if ("silent" in guard) return { ok: true, leadCode: "RECEIVED" };
    return { ok: false, error: guard.error };
  }

  const services = await db.select({ id: t.enquiryServices.id, label: t.enquiryServices.label }).from(t.enquiryServices).where(inArray(t.enquiryServices.id, d.serviceIds));
  try {
    const lead = await createLead({
      entryType: "public_enquiry",
      business: { ...d.business, website: safeUrl(d.business.website), facebook: d.business.facebook, instagram: d.business.instagram },
      contact: d.contact,
      enquiryServiceIds: services.map((s) => s.id),
      answers: d.answers,
      requirements: d.requirements,
      budgetRangeId: d.budgetRangeId,
      budgetCustom: d.budgetCustom,
      timeline: d.timeline,
      preferredContactMethod: d.preferredContactMethod,
      meetingPreference: d.meetingPreference,
      comments: d.comments,
      consentToContact: true,
      campaignId: await campaignFromAttribution(d.attribution?.utm),
      utm: d.attribution?.utm ?? null,
      referrer: d.attribution?.referrer ?? null,
      landingPage: d.attribution?.landingPage ?? null,
      clientRef: `pub-${d.clientRef}`,
      ipHash: guard.ipHash,
    });
    if (!lead.existing) {
      after(async () => {
        await processSyncJobs({ leadIds: [lead.id] }).catch((e) => console.error(e));
        await notifyNewEnquiry({ id: lead.id, leadCode: lead.leadCode, businessName: d.business.name, services: services.map((s) => s.label) }).catch((e) => console.error(e));
        if (d.contact.email) await sendEnquiryAcknowledgement(d.contact.email, d.contact.fullName, lead.leadCode).catch((e) => console.error(e));
      });
    }
    return { ok: true, leadCode: lead.leadCode };
  } catch (e) {
    console.error("[enquiry] failed", e);
    return { ok: false, error: "Something went wrong while saving your enquiry. Please try again — your details have been kept." };
  }
}

export async function submitContact(input: unknown): Promise<SubmitResult> {
  const parsed = contactFormSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: "Please check the highlighted fields.", fieldErrors: flattenErrors(parsed.error) };
  const d = parsed.data;
  const guard = await spamGuard(d.hp, d.formToken);
  if (guard.blocked) {
    if ("silent" in guard) return { ok: true, leadCode: "RECEIVED" };
    return { ok: false, error: guard.error };
  }
  try {
    const lead = await createLead({
      entryType: "public_enquiry",
      business: { name: d.business },
      contact: { fullName: d.name, phone: d.phone, email: d.email },
      requirements: d.message,
      consentToContact: true,
      campaignId: await campaignFromAttribution(d.attribution?.utm),
      utm: d.attribution?.utm ?? null,
      referrer: d.attribution?.referrer ?? null,
      landingPage: d.attribution?.landingPage ?? null,
      clientRef: `contact-${d.clientRef}`,
      ipHash: guard.ipHash,
    });
    if (!lead.existing) {
      after(async () => {
        await processSyncJobs({ leadIds: [lead.id] }).catch((e) => console.error(e));
        await notifyNewEnquiry({ id: lead.id, leadCode: lead.leadCode, businessName: d.business, services: ["Contact form message"] }).catch((e) => console.error(e));
      });
    }
    return { ok: true, leadCode: lead.leadCode };
  } catch (e) {
    console.error("[contact] failed", e);
    return { ok: false, error: "Something went wrong. Please try again or call us." };
  }
}
