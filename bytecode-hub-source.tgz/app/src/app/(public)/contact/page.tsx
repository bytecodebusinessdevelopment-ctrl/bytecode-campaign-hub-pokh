import type { Metadata } from "next";
import Link from "next/link";
import { Mail, MapPin, Phone, MessageCircle, Clock, ArrowRight } from "lucide-react";
import { PageHero } from "@/components/public/cards";
import { ContactForm } from "@/components/forms/contact-form";
import { getSettings } from "@/lib/settings";
import { issueFormToken } from "@/lib/form-token";
import { telLink, whatsappLink } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Contact", description: "Contact ByteCode Developers — phone, email, WhatsApp and office address." };

export default async function ContactPage() {
  const s = await getSettings();
  const wa = whatsappLink(s.whatsapp);
  const items = [
    s.phone && { Icon: Phone, label: "Phone", value: s.phone, href: telLink(s.phone) },
    wa && { Icon: MessageCircle, label: "WhatsApp", value: s.whatsapp, href: wa },
    s.email && { Icon: Mail, label: "Email", value: s.email, href: `mailto:${s.email}` },
    s.address && { Icon: MapPin, label: "Office", value: s.address, href: s.mapUrl || null },
    s.officeHours && { Icon: Clock, label: "Office hours", value: s.officeHours, href: null },
  ].filter(Boolean) as { Icon: typeof Phone; label: string; value: string; href: string | null }[];
  return (
    <>
      <PageHero eyebrow="Contact" title="Let's talk." intro="Call, message or send us a note. For a detailed quotation, use the proposal form — it helps us prepare a better answer." />
      <div className="container grid gap-10 py-14 lg:grid-cols-[1fr_1.3fr]">
        <div className="space-y-4">
          {items.map(({ Icon, label, value, href }) => (
            <div key={label} className="card flex items-start gap-4 p-5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand"><Icon className="h-5 w-5" /></span>
              <div><p className="text-xs font-semibold uppercase tracking-wide text-ink-muted">{label}</p>{href ? <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer" className="break-words font-semibold text-navy hover:text-brand">{value}</a> : <p className="font-semibold text-navy">{value}</p>}</div>
            </div>
          ))}
          <Link href="/request-proposal" className="card flex items-center justify-between bg-navy p-5 text-white hover:bg-navy-950"><span><span className="block font-semibold">Need a quotation?</span><span className="text-sm text-white/70">Use the detailed proposal form</span></span><ArrowRight className="h-5 w-5" /></Link>
        </div>
        <div>
          <h2 className="mb-4 text-2xl font-bold">Send a message</h2>
          <ContactForm formToken={issueFormToken()} />
        </div>
      </div>
    </>
  );
}
