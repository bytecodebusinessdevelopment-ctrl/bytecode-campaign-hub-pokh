"use client";
import Link from "next/link";

export default function Error({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center px-6 text-center">
      <h1 className="text-2xl font-extrabold text-navy">Something went wrong</h1>
      <p className="mt-3 max-w-md text-ink-soft">Please try again. If the problem continues, contact us by phone or WhatsApp.</p>
      <div className="mt-6 flex gap-3"><button onClick={reset} className="btn-primary">Try again</button><Link href="/" className="btn-outline">Home</Link></div>
    </div>
  );
}
