import type { Metadata } from "next";
import { asc, desc } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Tabs } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { saveLookup } from "./actions";

export const metadata: Metadata = { title: "Lists & options" };

const TABS = [
  ["leadStatuses", "Pipeline statuses"], ["leadSources", "Lead sources"], ["industries", "Industries"], ["enquiryServices", "Enquiry services"],
  ["budgetRanges", "Budget ranges"], ["projectTypes", "Project types"], ["resourceCategories", "Resource categories"],
] as const;

type Row = { id: string; name: string; sortOrder: number; active: boolean; extra?: Record<string, unknown> };

export default async function LookupsPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  await requirePagePermission("manageLookups");
  const { tab = "leadStatuses" } = await searchParams;
  const [campaigns, services] = await Promise.all([db.select().from(t.campaigns).orderBy(desc(t.campaigns.isDefault)), db.select().from(t.services).orderBy(asc(t.services.sortOrder))]);
  let rows: Row[] = [];
  if (tab === "industries") rows = (await db.select().from(t.industries).orderBy(asc(t.industries.sortOrder))).map((r) => ({ ...r }));
  if (tab === "projectTypes") rows = (await db.select().from(t.projectTypes).orderBy(asc(t.projectTypes.sortOrder))).map((r) => ({ ...r }));
  if (tab === "resourceCategories") rows = (await db.select().from(t.resourceCategories).orderBy(asc(t.resourceCategories.sortOrder))).map((r) => ({ ...r }));
  if (tab === "leadSources") rows = (await db.select().from(t.leadSources).orderBy(asc(t.leadSources.sortOrder))).map((r) => ({ ...r, extra: { campaignId: r.campaignId } }));
  if (tab === "leadStatuses") rows = (await db.select().from(t.leadStatuses).orderBy(asc(t.leadStatuses.sortOrder))).map((r) => ({ ...r, extra: { color: r.color, isWon: r.isWon, isLost: r.isLost, isQualified: r.isQualified } }));
  if (tab === "budgetRanges") rows = (await db.select().from(t.budgetRanges).orderBy(asc(t.budgetRanges.sortOrder))).map((r) => ({ ...r, name: r.label, extra: { minNpr: r.minNpr, maxNpr: r.maxNpr } }));
  if (tab === "enquiryServices") rows = (await db.select().from(t.enquiryServices).orderBy(asc(t.enquiryServices.sortOrder))).map((r) => ({ ...r, name: r.label, extra: { serviceId: r.serviceId, key: r.key } }));

  const extraFields = (r?: Row) => {
    const e = r?.extra ?? {};
    if (tab === "leadSources") return <select name="campaignId" defaultValue={(e.campaignId as string) ?? ""} className="input-sm" aria-label="Campaign"><option value="">All campaigns</option>{campaigns.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>;
    if (tab === "leadStatuses") return (
      <div className="flex flex-wrap items-center gap-3 text-xs">
        <input type="color" name="color" defaultValue={(e.color as string) ?? "#64748B"} className="h-9 w-12 rounded border border-line" aria-label="Colour" />
        <label className="flex items-center gap-1"><input type="checkbox" name="isQualified" defaultChecked={Boolean(e.isQualified)} className="check" /> Qualified+</label>
        <label className="flex items-center gap-1"><input type="checkbox" name="isWon" defaultChecked={Boolean(e.isWon)} className="check" /> Won</label>
        <label className="flex items-center gap-1"><input type="checkbox" name="isLost" defaultChecked={Boolean(e.isLost)} className="check" /> Lost</label>
      </div>
    );
    if (tab === "budgetRanges") return <div className="flex gap-2"><input name="minNpr" defaultValue={(e.minNpr as number) ?? ""} placeholder="Min NPR" className="input-sm w-28" /><input name="maxNpr" defaultValue={(e.maxNpr as number) ?? ""} placeholder="Max NPR" className="input-sm w-28" /></div>;
    if (tab === "enquiryServices") return <select name="serviceId" defaultValue={(e.serviceId as string) ?? ""} className="input-sm" aria-label="Linked service page"><option value="">No service page</option>{services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>;
    return null;
  };

  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Lists & options" subtitle="Configure the options used in forms, filters and reports. Deactivate items instead of deleting them to keep history intact." />
      <Tabs current={tab} tabs={TABS.map(([k, l]) => ({ key: k, label: l, href: `/admin/lookups?tab=${k}` }))} />
      {tab === "enquiryServices" && <p className="mb-4 text-sm text-ink-muted">Conditional questions are attached to the built-in keys (website, ecommerce, app, seo, travel, marketing, video, system, automation). New options appear in the forms without extra questions.</p>}
      {tab === "leadStatuses" && <p className="mb-4 text-sm text-ink-muted">Statuses are shown in display order. Exactly one status should be marked Won and one Lost. &ldquo;Qualified+&rdquo; marks the stages counted as qualified in reports.</p>}
      <div className="space-y-2">
        {[...rows, undefined].map((r) => (
          <ActionForm key={r?.id ?? "new"} action={saveLookup} resetOnSuccess={!r} className={`card grid items-center gap-2 p-3 md:grid-cols-[1fr_auto_80px_auto_auto] ${r && !r.active ? "opacity-60" : ""}`}>
            <input type="hidden" name="kind" value={tab} />
            {r && <input type="hidden" name="id" value={r.id} />}
            <input name="name" defaultValue={r?.name} placeholder={r ? "" : "Add new…"} className="input-sm" required aria-label="Name" />
            {extraFields(r)}
            <input name="sortOrder" defaultValue={r?.sortOrder ?? rows.length} className="input-sm" aria-label="Order" />
            {r ? <label className="flex items-center gap-1 text-xs"><input type="checkbox" name="active" defaultChecked={r.active} className="check" /> Active</label> : <span />}
            <div className="flex gap-1">
              <SubmitButton className="btn-primary btn-sm">{r ? "Save" : "Add"}</SubmitButton>
              {r && <SubmitButton className="btn-ghost btn-sm text-red-600" name="intent" value="delete" confirm="Delete this item? Records using it will lose the value.">Delete</SubmitButton>}
            </div>
          </ActionForm>
        ))}
      </div>
    </div>
  );
}
