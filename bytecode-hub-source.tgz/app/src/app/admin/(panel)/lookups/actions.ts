"use server";
import { revalidatePath } from "next/cache";
import { eq, sql } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { safeAction } from "@/lib/action";
import { requirePermission } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { bool, int, slugify, str } from "@/lib/utils";

const LOOKUP_KINDS = ["industries", "projectTypes", "resourceCategories", "leadSources", "leadStatuses", "budgetRanges", "enquiryServices"] as const;
type Kind = (typeof LOOKUP_KINDS)[number];

export const saveLookup = safeAction(async (fd) => {
  const user = await requirePermission("manageLookups");
  const kind = String(fd.get("kind")) as Kind;
  if (!LOOKUP_KINDS.includes(kind)) throw new Error("Unknown list.");
  const id = str(fd.get("id"));
  const intent = String(fd.get("intent") ?? "save");
  const sortOrder = int(fd.get("sortOrder")) ?? 0;
  const active = bool(fd.get("active"));

  if (intent === "delete" && id) {
    if (kind === "leadStatuses") {
      const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(t.leads).where(eq(t.leads.statusId, id));
      if (Number(n)) throw new Error(`This status is used by ${n} lead(s). Deactivate it instead.`);
    }
    const table = t[kind] as typeof t.industries;
    await db.delete(table).where(eq(table.id, id));
    await audit(user.id, "delete", kind, id);
    revalidatePath("/", "layout");
    return { ok: true, message: "Deleted." };
  }

  const name = str(fd.get("name"));
  if (!name) throw new Error("Name is required.");
  const slug = slugify(str(fd.get("slug")) ?? name);

  switch (kind) {
    case "industries": case "projectTypes": case "resourceCategories": {
      const table = t[kind];
      if (id) await db.update(table).set({ name, sortOrder, active }).where(eq(table.id, id));
      else await db.insert(table).values({ name, slug, sortOrder, active: true });
      break;
    }
    case "leadSources": {
      const values = { name, sortOrder, active, campaignId: str(fd.get("campaignId")) };
      if (id) await db.update(t.leadSources).set(values).where(eq(t.leadSources.id, id));
      else await db.insert(t.leadSources).values({ ...values, slug, active: true });
      break;
    }
    case "leadStatuses": {
      const values = { name, sortOrder, active, color: /^#[0-9a-f]{6}$/i.test(String(fd.get("color"))) ? String(fd.get("color")) : "#64748B", isWon: bool(fd.get("isWon")), isLost: bool(fd.get("isLost")), isQualified: bool(fd.get("isQualified")) };
      if (values.isWon && values.isLost) throw new Error("A status cannot be both Won and Lost.");
      if (id) await db.update(t.leadStatuses).set(values).where(eq(t.leadStatuses.id, id));
      else await db.insert(t.leadStatuses).values({ ...values, slug, active: true });
      break;
    }
    case "budgetRanges": {
      const values = { label: name, minNpr: int(fd.get("minNpr")), maxNpr: int(fd.get("maxNpr")), sortOrder, active };
      if (id) await db.update(t.budgetRanges).set(values).where(eq(t.budgetRanges.id, id));
      else await db.insert(t.budgetRanges).values({ ...values, active: true });
      break;
    }
    case "enquiryServices": {
      const values = { label: name, serviceId: str(fd.get("serviceId")), sortOrder, active };
      if (id) await db.update(t.enquiryServices).set(values).where(eq(t.enquiryServices.id, id));
      else await db.insert(t.enquiryServices).values({ ...values, key: slug.replace(/-/g, "_"), active: true });
      break;
    }
  }
  await audit(user.id, id ? "update" : "create", kind, id, { name });
  revalidatePath("/", "layout");
  return { ok: true, message: "Saved." };
});
