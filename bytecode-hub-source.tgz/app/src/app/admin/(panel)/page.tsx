import type { Metadata } from "next";
import Link from "next/link";
import { and, asc, desc, eq, isNull, isNotNull, lt, gte } from "drizzle-orm";
import { AlertTriangle, ArrowRight, Zap, UserPlus } from "lucide-react";
import { requireUser, leadScope } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db, t } from "@/lib/db";
import { dashboardStats } from "@/lib/stats";
import { syncSummary, sheetsConfigured } from "@/lib/sheets";
import { PageHeader, Stat, Section } from "@/components/admin/server-ui";
import { HBarChart, ColumnChart } from "@/components/admin/charts";
import { Badge } from "@/components/admin/ui";
import { formatDate, formatDateTime, formatNpr, relativeDays } from "@/lib/format";

export const metadata: Metadata = { title: "Dashboard" };

export default async function Dashboard({ searchParams }: { searchParams: Promise<{ campaign?: string; denied?: string }> }) {
  const user = await requireUser();
  const sp = await searchParams;
  const [stats, campaigns] = await Promise.all([
    dashboardStats(user, { campaign: sp.campaign }),
    db.select({ id: t.campaigns.id, name: t.campaigns.name }).from(t.campaigns).orderBy(desc(t.campaigns.isDefault)),
  ]);
  const scope = leadScope(user);
  const openStatus = and(eq(t.leadStatuses.isWon, false), eq(t.leadStatuses.isLost, false));
  const followUps = await db
    .select({ id: t.leads.id, code: t.leads.leadCode, business: t.businesses.name, due: t.leads.nextFollowUpAt, action: t.leads.nextAction, assignee: t.users.name })
    .from(t.leads)
    .innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId))
    .innerJoin(t.leadStatuses, eq(t.leadStatuses.id, t.leads.statusId))
    .leftJoin(t.users, eq(t.users.id, t.leads.assignedTo))
    .where(and(isNull(t.leads.mergedInto), isNotNull(t.leads.nextFollowUpAt), openStatus, lt(t.leads.nextFollowUpAt, new Date(Date.now() + 3 * 86400000)), scope, sp.campaign ? eq(t.leads.campaignId, sp.campaign) : undefined))
    .orderBy(asc(t.leads.nextFollowUpAt))
    .limit(8);
  const recent = await db
    .select({ id: t.leads.id, code: t.leads.leadCode, business: t.businesses.name, location: t.businesses.location, created: t.leads.createdAt, status: t.leadStatuses.name, color: t.leadStatuses.color, entry: t.leads.entryType })
    .from(t.leads)
    .innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId))
    .innerJoin(t.leadStatuses, eq(t.leadStatuses.id, t.leads.statusId))
    .where(and(isNull(t.leads.mergedInto), scope, sp.campaign ? eq(t.leads.campaignId, sp.campaign) : undefined))
    .orderBy(desc(t.leads.createdAt))
    .limit(8);
  const meetings = await db
    .select({ id: t.meetings.id, leadId: t.leads.id, code: t.leads.leadCode, business: t.businesses.name, at: t.meetings.scheduledAt, location: t.meetings.location })
    .from(t.meetings)
    .innerJoin(t.leads, eq(t.leads.id, t.meetings.leadId))
    .innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId))
    .where(and(gte(t.meetings.scheduledAt, new Date()), eq(t.meetings.completed, false), scope))
    .orderBy(asc(t.meetings.scheduledAt))
    .limit(5);
  const sync = can(user.role, "retrySync") ? await syncSummary() : null;
  const T = stats.totals;
  const statusHref = (id?: string | null) => `/admin/leads?status=${id ?? ""}${sp.campaign ? `&campaign=${sp.campaign}` : ""}`;
  const isAll = can(user.role, "viewAllLeads");

  return (
    <div>
      {sp.denied && <p className="placeholder-note mb-4">You don&apos;t have permission to open that page.</p>}
      <PageHeader
        title={`Namaste, ${user.name.split(" ")[0]}`}
        subtitle={isAll ? "Campaign overview — all leads" : "Your leads and follow-ups"}
        actions={
          <>
            <form className="flex w-full min-w-0 gap-2 sm:w-auto">
              <select name="campaign" defaultValue={sp.campaign ?? ""} className="input-sm min-w-0 flex-1 sm:w-56 sm:flex-none" aria-label="Campaign">
                <option value="">All campaigns</option>
                {campaigns.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <button className="btn-outline btn-sm">Apply</button>
            </form>
            <Link href="/admin/leads/new" className="btn-outline btn-sm"><UserPlus className="h-4 w-4" /> New lead</Link>
            <Link href="/admin/leads/quick" className="btn-accent btn-sm"><Zap className="h-4 w-4" /> Quick capture</Link>
          </>
        }
      />

      {T.overdue > 0 && (
        <Link href="/admin/follow-ups?tab=overdue" className="mb-5 flex items-center gap-3 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800 hover:bg-red-100">
          <AlertTriangle className="h-5 w-5 shrink-0" /> <span><strong>{T.overdue} overdue follow-up{T.overdue > 1 ? "s" : ""}</strong> {T.overdue > 1 ? "need" : "needs"} attention.</span> <ArrowRight className="ml-auto h-4 w-4" />
        </Link>
      )}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Total leads" value={T.total} hint={`${T.new7d} in the last 7 days`} href="/admin/leads" />
        <Stat label="Overdue follow-ups" value={T.overdue} tone={T.overdue ? "bad" : "good"} hint={`${T.dueToday} due in the next 24h`} href="/admin/follow-ups?tab=overdue" />
        <Stat label="Upcoming meetings" value={T.meetingsUpcoming} href="/admin/follow-ups?tab=meetings" />
        <Stat label="Est. pipeline value" value={formatNpr(T.openValue)} hint={<>Estimate · Won: {formatNpr(T.wonValue)}</>} />
      </div>

      <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4 xl:grid-cols-8">
        {stats.byStatus.map((s) => (
          <Link key={s.id} href={statusHref(s.id)} className="card p-3 hover:shadow-lift">
            <span className="flex items-center gap-1.5 text-xs font-medium text-ink-muted"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: s.color ?? undefined }} />{s.label}</span>
            <span className="mt-1 block font-display text-xl font-extrabold tabular-nums text-navy">{s.value}</span>
          </Link>
        ))}
      </div>

      {(T.duplicates > 0 || (isAll && T.unassigned > 0)) && (
        <div className="mt-3 flex flex-wrap gap-2 text-sm">
          {T.duplicates > 0 && <Link href="/admin/leads?duplicates=1" className="chip border-amber-300 bg-amber-50 text-amber-800">{T.duplicates} possible duplicate{T.duplicates > 1 ? "s" : ""} to review</Link>}
          {isAll && T.unassigned > 0 && <Link href="/admin/leads?assigned=none" className="chip">{T.unassigned} open lead{T.unassigned > 1 ? "s" : ""} not assigned</Link>}
        </div>
      )}

      <div className="mt-6 grid gap-5 xl:grid-cols-3">
        <Section title="New leads per week" className="xl:col-span-2"><ColumnChart data={stats.weekly} /></Section>
        <Section title="Follow-ups due" actions={<Link href="/admin/follow-ups" className="text-sm font-semibold text-brand">All</Link>}>
          {followUps.length ? (
            <ul className="divide-y divide-line">
              {followUps.map((f) => {
                const overdue = f.due && f.due.getTime() < Date.now();
                return (
                  <li key={f.id}><Link href={`/admin/leads/${f.id}`} className="flex items-start justify-between gap-3 py-2.5 hover:text-brand">
                    <span className="min-w-0"><span className="block truncate text-sm font-semibold text-navy">{f.business}</span><span className="block truncate text-xs text-ink-muted">{f.action ?? "Follow up"}{isAll && f.assignee ? ` · ${f.assignee}` : ""}</span></span>
                    <span className={`shrink-0 text-xs font-semibold ${overdue ? "text-red-600" : "text-ink-soft"}`}>{relativeDays(f.due)}</span>
                  </Link></li>
                );
              })}
            </ul>
          ) : <p className="py-6 text-center text-sm text-ink-muted">Nothing due in the next 3 days.</p>}
        </Section>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <Section title="Leads by source"><HBarChart data={stats.bySource} /></Section>
        <Section title="Leads by industry"><HBarChart data={stats.byIndustry} /></Section>
        <Section title="Service interest"><HBarChart data={stats.byService} /></Section>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <Section title="Recent leads" className="lg:col-span-2" actions={<Link href="/admin/leads" className="text-sm font-semibold text-brand">All leads</Link>}>
          {recent.length ? (
            <ul className="divide-y divide-line">
              {recent.map((r) => (
                <li key={r.id}><Link href={`/admin/leads/${r.id}`} className="flex items-center justify-between gap-3 py-2.5 hover:text-brand">
                  <span className="min-w-0"><span className="block truncate text-sm font-semibold text-navy">{r.business}</span><span className="text-xs text-ink-muted">{r.code} · {r.location ?? "—"} · {formatDate(r.created)}</span></span>
                  <Badge color={r.color}>{r.status}</Badge>
                </Link></li>
              ))}
            </ul>
          ) : <p className="py-6 text-center text-sm text-ink-muted">No leads yet. Use <Link href="/admin/leads/quick" className="text-brand">Quick capture</Link> during your next visit.</p>}
        </Section>
        <div className="space-y-5">
          <Section title="Upcoming meetings">
            {meetings.length ? (
              <ul className="space-y-2">{meetings.map((m) => <li key={m.id}><Link href={`/admin/leads/${m.leadId}`} className="block rounded-xl border border-line p-3 hover:border-brand"><span className="block text-sm font-semibold text-navy">{m.business}</span><span className="text-xs text-ink-muted">{formatDateTime(m.at)}{m.location ? ` · ${m.location}` : ""}</span></Link></li>)}</ul>
            ) : <p className="text-sm text-ink-muted">No meetings scheduled.</p>}
          </Section>
          {sync && (
            <Section title="Google Sheets sync" actions={<Link href="/admin/integrations" className="text-sm font-semibold text-brand">Details</Link>}>
              {!sheetsConfigured() ? <p className="text-sm text-amber-700">Not configured yet — leads are safely stored in the database and will sync once credentials are added.</p> : null}
              <dl className="mt-2 grid grid-cols-3 gap-2 text-center text-sm">
                <div className="rounded-xl bg-surface p-2"><dt className="text-xs text-ink-muted">Pending</dt><dd className="font-bold">{sync.pending + sync.running}</dd></div>
                <div className="rounded-xl bg-surface p-2"><dt className="text-xs text-ink-muted">Synced</dt><dd className="font-bold text-emerald-600">{sync.success}</dd></div>
                <div className="rounded-xl bg-surface p-2"><dt className="text-xs text-ink-muted">Failed</dt><dd className={`font-bold ${sync.failed ? "text-red-600" : ""}`}>{sync.failed}</dd></div>
              </dl>
            </Section>
          )}
        </div>
      </div>
    </div>
  );
}
