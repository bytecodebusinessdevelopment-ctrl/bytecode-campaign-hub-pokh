import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { PageHeader, Empty } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { formatDateTime } from "@/lib/format";
import { markAllRead } from "./actions";

export const metadata: Metadata = { title: "Notifications" };

export default async function NotificationsPage() {
  const user = await requireUser();
  const rows = await db.select().from(t.notifications).where(eq(t.notifications.userId, user.id)).orderBy(desc(t.notifications.createdAt)).limit(100);
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="Notifications" actions={rows.some((r) => !r.readAt) ? <ActionForm action={markAllRead}><SubmitButton className="btn-outline btn-sm">Mark all as read</SubmitButton></ActionForm> : undefined} />
      {rows.length ? (
        <ul className="space-y-2">{rows.map((n) => (
          <li key={n.id} className={`card p-4 ${n.readAt ? "" : "border-brand/40 bg-brand/[.03]"}`}>
            {n.link ? <Link href={n.link} className="font-semibold text-navy hover:text-brand">{n.title}</Link> : <p className="font-semibold text-navy">{n.title}</p>}
            {n.body && <p className="text-sm text-ink-soft">{n.body}</p>}
            <p className="mt-1 text-xs text-ink-muted">{formatDateTime(n.createdAt)}</p>
          </li>
        ))}</ul>
      ) : <Empty>No notifications yet.</Empty>}
    </div>
  );
}
