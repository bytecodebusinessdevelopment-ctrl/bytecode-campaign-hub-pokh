"use server";
import { and, eq, isNull } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { safeAction } from "@/lib/action";
import { getCurrentUser } from "@/lib/auth";

export const markAllRead = safeAction(async () => {
  const user = await getCurrentUser();
  if (!user) return { error: "Please sign in." };
  await db.update(t.notifications).set({ readAt: new Date() }).where(and(eq(t.notifications.userId, user.id), isNull(t.notifications.readAt)));
  return { ok: true, message: "All caught up." };
});
