"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { and, eq, ne } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { safeAction } from "@/lib/action";
import { requirePermission } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { refreshFilePublicity, deleteFile } from "@/lib/storage";
import { bool, int, safeUrl, slugify, str } from "@/lib/utils";

const KINDS = ["file", "link", "video_link", "website", "vercel", "figma"] as const;

async function uniqueSlug(base: string, excludeId?: string | null) {
  let slug = slugify(base);
  for (let i = 2; ; i++) {
    const [hit] = await db.select({ id: t.resources.id }).from(t.resources).where(excludeId ? and(eq(t.resources.slug, slug), ne(t.resources.id, excludeId)) : eq(t.resources.slug, slug));
    if (!hit) return slug;
    slug = `${slugify(base)}-${i}`;
  }
}

export const saveResource = safeAction(async (fd) => {
  const user = await requirePermission("manageContent");
  const id = str(fd.get("id"));
  const title = str(fd.get("title"));
  if (!title) throw new Error("Title is required.");
  const kind = String(fd.get("kind")) as (typeof KINDS)[number];
  if (!KINDS.includes(kind)) throw new Error("Choose a resource type.");
  const fileId = str(fd.get("fileId"));
  const url = safeUrl(str(fd.get("url")));
  if (kind === "file" && !fileId) throw new Error("Upload a file for this resource.");
  if (kind !== "file" && !url) throw new Error("Enter a valid URL for this resource.");
  const visibility = String(fd.get("visibility")) as "public" | "private" | "internal";
  if (!["public", "private", "internal"].includes(visibility)) throw new Error("Choose visibility.");
  const [existing] = id ? await db.select().from(t.resources).where(eq(t.resources.id, id)) : [];
  const values = {
    title, slug: await uniqueSlug(str(fd.get("slug")) ?? title, id), description: str(fd.get("description")),
    categoryId: str(fd.get("categoryId")), industryId: str(fd.get("industryId")), kind,
    fileId: kind === "file" ? fileId : null, url: kind === "file" ? null : url, previewFileId: str(fd.get("previewFileId")),
    visibility, published: bool(fd.get("published")), allowDownload: bool(fd.get("allowDownload")), featured: bool(fd.get("featured")),
    sortOrder: int(fd.get("sortOrder")) ?? 0, updatedAt: new Date(),
  };
  let resourceId = id;
  if (id) await db.update(t.resources).set(values).where(eq(t.resources.id, id));
  else resourceId = (await db.insert(t.resources).values({ ...values, createdBy: user.id }).returning({ id: t.resources.id }))[0].id;

  // One resource → many services / projects / campaign collections (no duplicate uploads needed).
  const services = fd.getAll("services").map(String).filter(Boolean);
  const projects = fd.getAll("projects").map(String).filter(Boolean);
  const campaigns = fd.getAll("campaigns").map(String).filter(Boolean);
  await db.delete(t.resourceServices).where(eq(t.resourceServices.resourceId, resourceId!));
  await db.delete(t.resourceProjects).where(eq(t.resourceProjects.resourceId, resourceId!));
  await db.delete(t.campaignResources).where(eq(t.campaignResources.resourceId, resourceId!));
  if (services.length) await db.insert(t.resourceServices).values(services.map((serviceId) => ({ resourceId: resourceId!, serviceId })));
  if (projects.length) await db.insert(t.resourceProjects).values(projects.map((projectId) => ({ resourceId: resourceId!, projectId })));
  if (campaigns.length) await db.insert(t.campaignResources).values(campaigns.map((campaignId) => ({ resourceId: resourceId!, campaignId })));

  // Replaced file? Remove the old one from storage.
  if (existing?.fileId && existing.fileId !== values.fileId) await deleteFile(existing.fileId);
  if (existing?.previewFileId && existing.previewFileId !== values.previewFileId) await deleteFile(existing.previewFileId);
  await refreshFilePublicity([values.fileId, values.previewFileId]);
  await audit(user.id, id ? "update" : "create", "resource", resourceId, { title, visibility, published: values.published });
  revalidatePath("/resources");
  revalidatePath("/", "layout");
  if (!id) redirect(`/admin/resources/${resourceId}?saved=1`);
  return { ok: true, message: "Resource saved." };
});

export const deleteResource = safeAction(async (fd) => {
  const user = await requirePermission("manageContent");
  const id = String(fd.get("id"));
  const [r] = await db.select().from(t.resources).where(eq(t.resources.id, id));
  if (r) {
    await db.delete(t.resources).where(eq(t.resources.id, id));
    if (r.fileId) await deleteFile(r.fileId);
    if (r.previewFileId) await deleteFile(r.previewFileId);
    await audit(user.id, "delete", "resource", id, { title: r.title });
  }
  revalidatePath("/resources");
  redirect("/admin/resources?deleted=1");
});

export const togglePublish = safeAction(async (fd) => {
  const user = await requirePermission("manageContent");
  const id = String(fd.get("id"));
  const [r] = await db.select().from(t.resources).where(eq(t.resources.id, id));
  if (!r) return { error: "Not found" };
  await db.update(t.resources).set({ published: !r.published, updatedAt: new Date() }).where(eq(t.resources.id, id));
  await refreshFilePublicity([r.fileId, r.previewFileId]);
  await audit(user.id, r.published ? "unpublish" : "publish", "resource", id);
  revalidatePath("/", "layout");
  return { ok: true, message: r.published ? "Unpublished." : "Published." };
});
