import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, desc, eq } from "drizzle-orm";
import { ExternalLink, Trash2 } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { FileUpload } from "@/components/admin/file-upload";
import { ResourceKindFields } from "@/components/admin/resource-kind-fields";
import { RESOURCE_KIND_LABELS } from "@/lib/enquiry-config";
import { getSettings } from "@/lib/settings";
import { saveResource, deleteResource } from "../actions";

export const metadata: Metadata = { title: "Edit resource" };

export default async function EditResource({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ saved?: string }> }) {
  await requirePagePermission("manageContent");
  const { id } = await params;
  const sp = await searchParams;
  const isNew = id === "new";
  const r = isNew ? null : await db.query.resources.findFirst({ where: eq(t.resources.id, id), with: { file: true, preview: true, services: true, projects: true, campaigns: true } });
  if (!isNew && !r) notFound();
  const [cats, industries, services, projects, campaigns, s] = await Promise.all([
    db.select().from(t.resourceCategories).orderBy(asc(t.resourceCategories.sortOrder)),
    db.select().from(t.industries).orderBy(asc(t.industries.sortOrder)),
    db.select().from(t.services).orderBy(asc(t.services.sortOrder)),
    db.select({ id: t.portfolioProjects.id, title: t.portfolioProjects.title, status: t.portfolioProjects.status }).from(t.portfolioProjects).orderBy(desc(t.portfolioProjects.status), asc(t.portfolioProjects.title)),
    db.select().from(t.campaigns).orderBy(desc(t.campaigns.isDefault)),
    getSettings(),
  ]);
  const has = (list: { serviceId?: string; projectId?: string; campaignId?: string }[] | undefined, key: "serviceId" | "projectId" | "campaignId", v: string) => Boolean(list?.some((x) => x[key] === v));

  return (
    <div className="mx-auto max-w-4xl">
      {sp.saved && <p className="mb-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">Resource created.</p>}
      <PageHeader title={isNew ? "Add resource" : r!.title} back={{ href: "/admin/resources", label: "Resources" }} actions={r && r.published && r.visibility !== "private" ? <Link href={`/resources/${r.slug}`} target="_blank" className="btn-outline btn-sm">View <ExternalLink className="h-4 w-4" /></Link> : undefined} />
      <ActionForm action={saveResource} className="space-y-5">
        {r && <input type="hidden" name="id" value={r.id} />}
        <Section title="Resource">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Title *" className="sm:col-span-2"><input name="title" required defaultValue={r?.title} className="input" /></L>
            <L label="Description" className="sm:col-span-2"><textarea name="description" rows={3} defaultValue={r?.description ?? ""} className="input" /></L>
            <L label="Category"><select name="categoryId" defaultValue={r?.categoryId ?? ""} className="input"><option value="">—</option>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></L>
            <L label="Industry"><select name="industryId" defaultValue={r?.industryId ?? ""} className="input"><option value="">All industries</option>{industries.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></L>
            <ResourceKindFields
              kinds={Object.entries(RESOURCE_KIND_LABELS)}
              initialKind={r?.kind ?? "file"}
              initialUrl={r?.url ?? ""}
              fileSlot={<FileUpload name="fileId" purpose="any" initial={r?.file ? { id: r.file.id, name: r.file.originalName } : null} help={`PDF, Word, PowerPoint, Excel, JPG/PNG/WebP or video. Limits: documents ${s.uploadLimitsMb.document} MB, images ${s.uploadLimitsMb.image} MB, video ${s.uploadLimitsMb.video} MB.`} />}
            />
            <div className="sm:col-span-2"><FileUpload name="previewFileId" purpose="image" label="Preview image (optional)" initial={r?.preview ? { id: r.preview.id, name: r.preview.originalName } : null} /></div>
            <L label="URL slug" hint="Leave blank to generate"><input name="slug" defaultValue={r?.slug} className="input" /></L>
          </div>
        </Section>

        <Section title="Visibility & publishing">
          <div className="grid gap-4 sm:grid-cols-3">
            <L label="Visibility" hint="Public = website; Internal = signed-in team only; Private = admins/managers only" className="sm:col-span-3">
              <select name="visibility" defaultValue={r?.visibility ?? "public"} className="input"><option value="public">Public — anyone can view/download</option><option value="internal">Internal only — ByteCode team (presenter kit)</option><option value="private">Private — not listed anywhere</option></select>
            </L>
            <label className="flex items-center gap-3 text-sm"><input type="checkbox" name="published" defaultChecked={r?.published ?? false} className="check" /> Published</label>
            <label className="flex items-center gap-3 text-sm"><input type="checkbox" name="allowDownload" defaultChecked={r?.allowDownload ?? true} className="check" /> Allow download</label>
            <label className="flex items-center gap-3 text-sm"><input type="checkbox" name="featured" defaultChecked={r?.featured} className="check" /> Featured</label>
            <L label="Display order"><input name="sortOrder" defaultValue={r?.sortOrder ?? 0} className="input" /></L>
          </div>
          <p className="mt-3 text-xs text-ink-muted">Never make internal proposals, private client documents or sensitive business information public.</p>
        </Section>

        <Section title="Show this resource on…">
          <p className="label">Service pages</p>
          <div className="flex flex-wrap gap-2">{services.map((x) => <Chk key={x.id} name="services" value={x.id} checked={has(r?.services, "serviceId", x.id)} label={x.name} />)}</div>
          <p className="label mt-5">Portfolio projects</p>
          <div className="flex max-h-56 flex-wrap gap-2 overflow-y-auto">{projects.map((x) => <Chk key={x.id} name="projects" value={x.id} checked={has(r?.projects, "projectId", x.id)} label={`${x.title}${x.status === "draft" ? " (draft)" : ""}`} />)}</div>
          <p className="label mt-5">Campaign resource collections</p>
          <div className="flex flex-wrap gap-2">{campaigns.map((x) => <Chk key={x.id} name="campaigns" value={x.id} checked={has(r?.campaigns, "campaignId", x.id)} label={x.name} />)}</div>
        </Section>
        <div className="sticky bottom-20 z-10 flex justify-end lg:bottom-4"><SubmitButton className="btn-primary shadow-lift">Save resource</SubmitButton></div>
      </ActionForm>
      {r && <Section title="Delete" className="mt-5"><ActionForm action={deleteResource} refresh={false}><input type="hidden" name="id" value={r.id} /><SubmitButton className="btn-danger btn-sm" confirm="Delete this resource and its file permanently?"><Trash2 className="h-4 w-4" /> Delete resource</SubmitButton></ActionForm></Section>}
    </div>
  );
}

function L({ label, hint, children, className }: { label: string; hint?: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className ?? ""}`}><span className="label">{label}</span>{children}{hint && <span className="hint block">{hint}</span>}</label>;
}
function Chk({ name, value, checked, label }: { name: string; value: string; checked: boolean; label: string }) {
  return <label className="flex min-h-[40px] items-center gap-2 rounded-xl border border-line px-3 text-sm has-[:checked]:border-brand has-[:checked]:bg-brand/5"><input type="checkbox" name={name} value={value} defaultChecked={checked} className="check" /> {label}</label>;
}
