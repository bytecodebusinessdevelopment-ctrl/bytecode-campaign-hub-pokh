import type { Metadata } from "next";
import Link from "next/link";
import { and, asc, desc, eq, ilike, or, type SQL } from "drizzle-orm";
import { Plus, Search, Lock, Globe, Users } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Empty } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { fileTypeLabel } from "@/components/public/cards";
import { formatDate } from "@/lib/format";
import { togglePublish } from "./actions";

export const metadata: Metadata = { title: "Resources" };

const VIS = { public: { label: "Public", Icon: Globe, cls: "bg-emerald-100 text-emerald-700" }, internal: { label: "Internal only", Icon: Users, cls: "bg-blue-100 text-blue-700" }, private: { label: "Private", Icon: Lock, cls: "bg-slate-100 text-slate-700" } } as const;

export default async function AdminResources({ searchParams }: { searchParams: Promise<{ q?: string; category?: string; visibility?: string; deleted?: string }> }) {
  await requirePagePermission("manageContent");
  const sp = await searchParams;
  const conds: (SQL | undefined)[] = [];
  if (sp.q) conds.push(or(ilike(t.resources.title, `%${sp.q}%`), ilike(t.resources.description, `%${sp.q}%`)));
  if (sp.category) conds.push(eq(t.resources.categoryId, sp.category));
  if (sp.visibility) conds.push(eq(t.resources.visibility, sp.visibility as "public"));
  const [rows, cats] = await Promise.all([
    db.query.resources.findMany({ where: and(...conds), with: { category: true, file: true, services: { with: { service: { columns: { name: true } } } } }, orderBy: [desc(t.resources.featured), asc(t.resources.sortOrder), desc(t.resources.updatedAt)] }),
    db.select().from(t.resourceCategories).orderBy(asc(t.resourceCategories.sortOrder)),
  ]);
  return (
    <div>
      {sp.deleted && <p className="mb-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">Resource deleted.</p>}
      <PageHeader title="Resources" subtitle="Company documents, samples, links and demonstrations. Upload once and attach to many services." actions={<Link href="/admin/resources/new" className="btn-primary btn-sm"><Plus className="h-4 w-4" /> Add resource</Link>} />
      <form className="card mb-4 grid gap-2 p-3 sm:grid-cols-[1fr_200px_180px_auto]">
        <label className="relative"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" /><input name="q" defaultValue={sp.q} placeholder="Search…" className="input-sm pl-9" /></label>
        <select name="category" defaultValue={sp.category ?? ""} className="input-sm" aria-label="Category"><option value="">All categories</option>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        <select name="visibility" defaultValue={sp.visibility ?? ""} className="input-sm" aria-label="Visibility"><option value="">Any visibility</option><option value="public">Public</option><option value="internal">Internal only</option><option value="private">Private</option></select>
        <button className="btn-primary btn-sm">Filter</button>
      </form>
      {rows.length ? (
        <div className="table-wrap"><table className="table">
          <thead><tr><th>Resource</th><th>Type</th><th>Category</th><th>Services</th><th>Visibility</th><th>Published</th><th className="text-right">Downloads</th></tr></thead>
          <tbody>{rows.map((r) => {
            const V = VIS[r.visibility];
            return (
              <tr key={r.id}>
                <td className="min-w-[220px]"><Link href={`/admin/resources/${r.id}`} className="font-semibold text-navy hover:text-brand">{r.title}</Link><div className="text-xs text-ink-muted">Updated {formatDate(r.updatedAt)}</div></td>
                <td className="text-xs">{fileTypeLabel(r.file?.mimeType, r.kind)}</td>
                <td className="text-xs text-ink-soft">{r.category?.name ?? "—"}</td>
                <td className="max-w-[200px] text-xs text-ink-soft">{r.services.map((s) => s.service.name).join(", ") || "—"}</td>
                <td><span className={`badge ${V.cls}`}><V.Icon className="h-3 w-3" /> {V.label}</span></td>
                <td><ActionForm action={togglePublish}><input type="hidden" name="id" value={r.id} /><SubmitButton className={`btn-sm rounded-full px-3 text-xs font-semibold ${r.published ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>{r.published ? "Published" : "Draft"}</SubmitButton></ActionForm></td>
                <td className="text-right text-xs tabular-nums">{r.downloadCount}</td>
              </tr>
            );
          })}</tbody>
        </table></div>
      ) : <Empty>No resources yet. Upload your company profile, brochures and samples.</Empty>}
    </div>
  );
}
