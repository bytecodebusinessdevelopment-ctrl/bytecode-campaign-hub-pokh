import type { Metadata } from "next";
import { inArray } from "drizzle-orm";
import { requirePagePermission } from "@/lib/auth";
import { lookupsForLeads } from "@/lib/lead-queries";
import { getDefaultCampaign } from "@/lib/leads";
import { QuickCapture } from "@/components/admin/quick-capture";
import { db, t } from "@/lib/db";

export const metadata: Metadata = { title: "Quick capture" };

export default async function QuickPage() {
  await requirePagePermission("createLeads");
  const [lk, campaign] = await Promise.all([lookupsForLeads(), getDefaultCampaign()]);
  const active = await db.select({ id: t.campaigns.id, name: t.campaigns.name }).from(t.campaigns).where(inArray(t.campaigns.status, ["active", "draft"]));
  return (
    <QuickCapture
      industries={lk.industries.map((i) => ({ id: i.id, name: i.name }))}
      services={lk.services.map((s) => ({ id: s.id, label: s.label }))}
      campaigns={active}
      defaultCampaignId={campaign?.id ?? ""}
      defaultLocation={campaign?.location?.split(",")[0] ?? ""}
    />
  );
}
