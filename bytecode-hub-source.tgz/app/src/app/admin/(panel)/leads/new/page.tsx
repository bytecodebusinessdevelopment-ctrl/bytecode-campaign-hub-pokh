import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { requirePagePermission } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { lookupsForLeads } from "@/lib/lead-queries";
import { getDefaultCampaign } from "@/lib/leads";
import { db, t } from "@/lib/db";
import { PageHeader } from "@/components/admin/server-ui";
import { LeadForm } from "@/components/admin/lead-form";
import { createInternalLead } from "../actions";

export const metadata: Metadata = { title: "New lead" };

export default async function NewLeadPage() {
  const user = await requirePagePermission("createLeads");
  const [lk, campaign] = await Promise.all([lookupsForLeads(), getDefaultCampaign()]);
  const [visit] = await db.select({ id: t.leadSources.id }).from(t.leadSources).where(eq(t.leadSources.slug, "pokhara-physical-visit"));
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="New lead" subtitle="Full lead entry — for a quick note during a visit, use Quick capture." back={{ href: "/admin/leads", label: "Leads" }} />
      <LeadForm
        action={createInternalLead}
        mode="create"
        lookups={{
          industries: lk.industries, services: lk.services, budgets: lk.budgets.map((b) => ({ id: b.id, name: b.label })),
          campaigns: lk.campaigns.filter((c) => c.status !== "archived"), sources: lk.sources, users: lk.users,
        }}
        canAssign={can(user.role, "assignLeads")}
        currentUserId={user.id}
        defaultCampaignId={campaign?.id}
        defaultSourceId={campaign?.slug === "pokhara" ? visit?.id : undefined}
      />
    </div>
  );
}
