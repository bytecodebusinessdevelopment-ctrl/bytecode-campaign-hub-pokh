"use server";
import { redirect } from "next/navigation";
import { after } from "next/server";
import { revalidatePath } from "next/cache";
import { and, asc, eq, isNull } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { safeAction } from "@/lib/action";
import { assertLeadAccess, requirePermission, getCurrentUser, ForbiddenError } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { createLead, changeLeadStatus, mergeLeads } from "@/lib/leads";
import { enqueueLeadSync, processSyncJobs } from "@/lib/sheets";
import { notifyUsers } from "@/lib/notify";
import { audit } from "@/lib/audit";
import { refreshFilePublicity, deleteFile } from "@/lib/storage";
import { fromNepalInput } from "@/lib/format";
import { str, int, safeUrl, isValidPhone, normalizePhone } from "@/lib/utils";

async function me() {
  const u = await getCurrentUser();
  if (!u) throw new ForbiddenError("Please sign in again.");
  return u;
}

function syncSoon(leadId: string) {
  after(() => processSyncJobs({ leadIds: [leadId] }).catch((e) => console.error(e)));
}

function checkPhone(v: string | null, label: string) {
  if (v && !isValidPhone(v)) throw new Error(`${label} is not a valid phone number.`);
  return v;
}

/** Recalculate the lead's next follow-up from its open follow-up activities. */
async function refreshNextFollowUp(leadId: string) {
  const [next] = await db
    .select({ dueAt: t.activities.dueAt, title: t.activities.title })
    .from(t.activities)
    .where(and(eq(t.activities.leadId, leadId), eq(t.activities.type, "follow_up"), isNull(t.activities.completedAt)))
    .orderBy(asc(t.activities.dueAt))
    .limit(1);
  await db.update(t.leads).set({ nextFollowUpAt: next?.dueAt ?? null, nextAction: next?.title ?? null, updatedAt: new Date() }).where(eq(t.leads.id, leadId));
}

export const createInternalLead = safeAction(async (fd) => {
  const user = await requirePermission("createLeads");
  const name = str(fd.get("businessName"));
  if (!name) throw new Error("Business name is required.");
  const followUp = fromNepalInput(str(fd.get("followUpAt")));
  const meetingAt = fromNepalInput(str(fd.get("meetingAt")));
  const assignedTo = can(user.role, "assignLeads") ? str(fd.get("assignedTo")) : user.id;
  const estimated = int(fd.get("estimatedValue"));
  const lead = await createLead({
    entryType: "internal",
    business: {
      name, industryId: str(fd.get("industryId")), location: str(fd.get("location")), address: str(fd.get("address")),
      website: safeUrl(str(fd.get("website"))), facebook: str(fd.get("facebook")), instagram: str(fd.get("instagram")), otherLinks: str(fd.get("socialOther")),
    },
    contact: {
      fullName: str(fd.get("contactName")), designation: str(fd.get("designation")),
      phone: checkPhone(str(fd.get("phone")), "Phone"), whatsapp: checkPhone(str(fd.get("whatsapp")) ?? str(fd.get("phone")), "WhatsApp"), email: str(fd.get("email")),
    },
    enquiryServiceIds: fd.getAll("services").map(String).filter(Boolean),
    requirements: str(fd.get("requirements")),
    budgetRangeId: str(fd.get("budgetRangeId")),
    budgetCustom: str(fd.get("budgetCustom")),
    estimatedValueNpr: estimated,
    timeline: str(fd.get("timeline")),
    campaignId: str(fd.get("campaignId")),
    sourceId: str(fd.get("sourceId")),
    priority: (str(fd.get("priority")) as "hot" | "warm" | "cold" | null) ?? null,
    assignedTo: assignedTo || user.id,
    nextAction: str(fd.get("nextAction")),
    nextFollowUpAt: followUp,
    discussionNotes: str(fd.get("notes")),
    meeting: meetingAt ? { scheduledAt: meetingAt, location: str(fd.get("meetingLocation")), agenda: str(fd.get("meetingNotes")), completed: meetingAt.getTime() < Date.now(), outcome: meetingAt.getTime() < Date.now() ? str(fd.get("meetingNotes")) : null } : null,
    clientRef: str(fd.get("clientRef")) ? `int-${str(fd.get("clientRef"))}` : null,
    createdBy: user.id,
    consentToContact: fd.get("consent") === "on",
  });
  await audit(user.id, "create", "lead", lead.id, { via: "internal", leadCode: lead.leadCode });
  if (assignedTo && assignedTo !== user.id) await notifyUsers([assignedTo], { type: "assigned", title: `Lead ${lead.leadCode} assigned to you`, body: name, link: `/admin/leads/${lead.id}` });
  syncSoon(lead.id);
  redirect(`/admin/leads/${lead.id}?created=1`);
});

export const updateLead = safeAction(async (fd) => {
  const user = await me();
  const id = String(fd.get("id"));
  await assertLeadAccess(user, id);
  const [lead] = await db.select().from(t.leads).where(eq(t.leads.id, id));
  const estimated = int(fd.get("estimatedValue"));
  await db.transaction(async (tx) => {
    await tx.update(t.businesses).set({
      name: str(fd.get("businessName")) ?? "Unnamed business", industryId: str(fd.get("industryId")), location: str(fd.get("location")), address: str(fd.get("address")),
      website: safeUrl(str(fd.get("website"))), facebook: str(fd.get("facebook")), instagram: str(fd.get("instagram")), otherLinks: str(fd.get("socialOther")), updatedAt: new Date(),
    }).where(eq(t.businesses.id, lead.businessId));
    const contact = {
      fullName: str(fd.get("contactName")), designation: str(fd.get("designation")), phone: checkPhone(str(fd.get("phone")), "Phone"),
      whatsapp: checkPhone(str(fd.get("whatsapp")), "WhatsApp"), email: str(fd.get("email"))?.toLowerCase() ?? null,
    };
    let contactId = lead.contactId;
    if (contactId) await tx.update(t.contacts).set({ ...contact, phoneNormalized: normalizePhone(contact.phone) ?? normalizePhone(contact.whatsapp) }).where(eq(t.contacts.id, contactId));
    else if (Object.values(contact).some(Boolean)) {
      const [c] = await tx.insert(t.contacts).values({ businessId: lead.businessId, ...contact, phoneNormalized: normalizePhone(contact.phone) ?? normalizePhone(contact.whatsapp) }).returning({ id: t.contacts.id });
      contactId = c.id;
    }
    const services = fd.getAll("services").map(String).filter(Boolean);
    await tx.delete(t.leadServices).where(eq(t.leadServices.leadId, id));
    if (services.length) await tx.insert(t.leadServices).values(services.map((s) => ({ leadId: id, enquiryServiceId: s })));
    const values = {
      contactId,
      campaignId: str(fd.get("campaignId")), sourceId: str(fd.get("sourceId")),
      priority: (str(fd.get("priority")) as "hot" | "warm" | "cold" | null) ?? null,
      budgetRangeId: str(fd.get("budgetRangeId")), budgetCustom: str(fd.get("budgetCustom")),
      estimatedValueNpr: estimated != null ? String(estimated) : null, timeline: str(fd.get("timeline")),
      requirements: str(fd.get("requirements")), initialInterest: str(fd.get("initialInterest")),
      preferredContactMethod: str(fd.get("preferredContactMethod")), meetingPreference: str(fd.get("meetingPreference")), comments: str(fd.get("comments")),
      updatedAt: new Date(),
    };
    const complete = Boolean(str(fd.get("businessName")) && str(fd.get("industryId")) && str(fd.get("location")) && (contact.phone || contact.email) && contact.fullName && services.length && (values.requirements || values.initialInterest));
    await tx.update(t.leads).set({ ...values, isComplete: complete }).where(eq(t.leads.id, id));
  });
  await audit(user.id, "update", "lead", id);
  await enqueueLeadSync(id);
  syncSoon(id);
  revalidatePath(`/admin/leads/${id}`);
  return { ok: true, message: "Lead updated." };
});

export const setStatus = safeAction(async (fd) => {
  const user = await me();
  const id = String(fd.get("id"));
  await assertLeadAccess(user, id);
  await changeLeadStatus(id, String(fd.get("statusId")), user.id, str(fd.get("note")));
  await audit(user.id, "status_change", "lead", id, { to: fd.get("statusId") });
  syncSoon(id);
  return { ok: true, message: "Status updated." };
});

export const assignLead = safeAction(async (fd) => {
  const user = await requirePermission("assignLeads");
  const id = String(fd.get("id"));
  const to = str(fd.get("assignedTo"));
  const [lead] = await db.select({ code: t.leads.leadCode, assignedTo: t.leads.assignedTo, businessId: t.leads.businessId }).from(t.leads).where(eq(t.leads.id, id));
  if (lead.assignedTo === to) return { ok: true, message: "No change." };
  await db.update(t.leads).set({ assignedTo: to, updatedAt: new Date() }).where(eq(t.leads.id, id));
  const [assignee] = to ? await db.select({ name: t.users.name }).from(t.users).where(eq(t.users.id, to)) : [];
  await db.insert(t.activities).values({ leadId: id, type: "system", title: to ? `Assigned to ${assignee?.name}` : "Unassigned", createdBy: user.id });
  // Move open follow-ups to the new owner.
  if (to) await db.update(t.activities).set({ assignedTo: to }).where(and(eq(t.activities.leadId, id), eq(t.activities.type, "follow_up"), isNull(t.activities.completedAt)));
  await audit(user.id, "assign", "lead", id, { to });
  if (to && to !== user.id) {
    const [b] = await db.select({ name: t.businesses.name }).from(t.businesses).where(eq(t.businesses.id, lead.businessId));
    await notifyUsers([to], { type: "assigned", title: `Lead ${lead.code} assigned to you`, body: b?.name, link: `/admin/leads/${id}` });
  }
  await enqueueLeadSync(id);
  syncSoon(id);
  return { ok: true, message: "Assignment updated." };
});

export const addActivity = safeAction(async (fd) => {
  const user = await me();
  const id = String(fd.get("id"));
  await assertLeadAccess(user, id);
  const type = String(fd.get("type")) as "note" | "call" | "whatsapp" | "email";
  if (!["note", "call", "whatsapp", "email"].includes(type)) throw new Error("Invalid activity type.");
  const body = str(fd.get("body"));
  if (!body) throw new Error("Please write something.");
  const titles = { note: "Internal note", call: "Phone call", whatsapp: "WhatsApp conversation", email: "Email" };
  await db.insert(t.activities).values({ leadId: id, type, title: titles[type], body, createdBy: user.id });
  await db.update(t.leads).set({ updatedAt: new Date() }).where(eq(t.leads.id, id));
  return { ok: true, message: "Added to timeline." };
});

export const scheduleFollowUp = safeAction(async (fd) => {
  const user = await me();
  const id = String(fd.get("id"));
  await assertLeadAccess(user, id);
  const due = fromNepalInput(str(fd.get("dueAt")));
  if (!due) throw new Error("Choose a follow-up date.");
  const title = str(fd.get("title")) ?? "Follow up";
  const [lead] = await db.select({ assignedTo: t.leads.assignedTo }).from(t.leads).where(eq(t.leads.id, id));
  await db.insert(t.activities).values({ leadId: id, type: "follow_up", title, body: str(fd.get("body")), dueAt: due, assignedTo: lead.assignedTo ?? user.id, createdBy: user.id });
  await refreshNextFollowUp(id);
  await enqueueLeadSync(id);
  syncSoon(id);
  return { ok: true, message: "Follow-up scheduled." };
});

export const completeFollowUp = safeAction(async (fd) => {
  const user = await me();
  const activityId = String(fd.get("activityId"));
  const [a] = await db.select().from(t.activities).where(eq(t.activities.id, activityId));
  if (!a) throw new Error("Follow-up not found.");
  await assertLeadAccess(user, a.leadId);
  const outcome = str(fd.get("outcome"));
  await db.update(t.activities).set({ completedAt: new Date(), body: outcome ? `${a.body ? `${a.body}\n\n` : ""}Outcome: ${outcome}` : a.body }).where(eq(t.activities.id, activityId));
  await refreshNextFollowUp(a.leadId);
  await enqueueLeadSync(a.leadId);
  syncSoon(a.leadId);
  return { ok: true, message: "Follow-up completed." };
});

export const addMeeting = safeAction(async (fd) => {
  const user = await me();
  const id = String(fd.get("id"));
  await assertLeadAccess(user, id);
  const at = fromNepalInput(str(fd.get("scheduledAt")));
  if (!at) throw new Error("Choose the meeting date and time.");
  await db.insert(t.meetings).values({
    leadId: id, scheduledAt: at, mode: str(fd.get("mode")) ?? "in_person", location: str(fd.get("location")), attendees: str(fd.get("attendees")),
    agenda: str(fd.get("agenda")), createdBy: user.id,
  });
  await db.insert(t.activities).values({ leadId: id, type: "meeting", title: at.getTime() > Date.now() ? "Meeting scheduled" : "Meeting recorded", body: str(fd.get("agenda")), dueAt: at, createdBy: user.id });
  // Move a "New"/"Contacted" lead forward automatically when a future meeting is booked.
  if (at.getTime() > Date.now() && fd.get("advance") === "on") {
    const [ms] = await db.select().from(t.leadStatuses).where(eq(t.leadStatuses.slug, "meeting-scheduled"));
    const [cur] = await db.select({ order: t.leadStatuses.sortOrder }).from(t.leads).innerJoin(t.leadStatuses, eq(t.leadStatuses.id, t.leads.statusId)).where(eq(t.leads.id, id));
    if (ms && cur && cur.order < ms.sortOrder) await changeLeadStatus(id, ms.id, user.id, "Meeting booked");
  }
  await enqueueLeadSync(id);
  syncSoon(id);
  return { ok: true, message: "Meeting saved." };
});

export const completeMeeting = safeAction(async (fd) => {
  const user = await me();
  const meetingId = String(fd.get("meetingId"));
  const [m] = await db.select().from(t.meetings).where(eq(t.meetings.id, meetingId));
  if (!m) throw new Error("Meeting not found.");
  await assertLeadAccess(user, m.leadId);
  const outcome = str(fd.get("outcome"));
  await db.update(t.meetings).set({ completed: true, outcome }).where(eq(t.meetings.id, meetingId));
  await db.insert(t.activities).values({ leadId: m.leadId, type: "meeting", title: "Meeting completed", body: outcome, createdBy: user.id });
  return { ok: true, message: "Meeting marked as completed." };
});

export const addAttachment = safeAction(async (fd) => {
  const user = await me();
  const id = String(fd.get("id"));
  await assertLeadAccess(user, id);
  const fileId = str(fd.get("fileId"));
  if (!fileId) throw new Error("Upload a file first.");
  await db.insert(t.leadAttachments).values({ leadId: id, fileId, caption: str(fd.get("caption")), createdBy: user.id });
  await refreshFilePublicity([fileId]); // stays private
  await db.insert(t.activities).values({ leadId: id, type: "system", title: "Attachment added", body: str(fd.get("caption")), createdBy: user.id });
  return { ok: true, message: "Attachment added." };
});

export const removeAttachment = safeAction(async (fd) => {
  const user = await me();
  const attId = String(fd.get("attachmentId"));
  const [a] = await db.select().from(t.leadAttachments).where(eq(t.leadAttachments.id, attId));
  if (!a) return { ok: true };
  await assertLeadAccess(user, a.leadId);
  await db.delete(t.leadAttachments).where(eq(t.leadAttachments.id, attId));
  await deleteFile(a.fileId);
  await audit(user.id, "delete", "lead_attachment", attId, { leadId: a.leadId });
  return { ok: true, message: "Attachment removed." };
});

export const mergeLeadAction = safeAction(async (fd) => {
  const user = await requirePermission("mergeLeads");
  const duplicateId = String(fd.get("duplicateId"));
  const primaryId = String(fd.get("primaryId"));
  await mergeLeads(duplicateId, primaryId, user.id);
  await audit(user.id, "merge", "lead", primaryId, { merged: duplicateId });
  syncSoon(primaryId);
  redirect(`/admin/leads/${primaryId}?merged=1`);
});

export const dismissDuplicate = safeAction(async (fd) => {
  const user = await me();
  const id = String(fd.get("id"));
  await assertLeadAccess(user, id);
  await db.update(t.leads).set({ duplicateReviewed: true }).where(eq(t.leads.id, id));
  await db.insert(t.activities).values({ leadId: id, type: "system", title: "Marked as not a duplicate", createdBy: user.id });
  return { ok: true, message: "Marked as not a duplicate." };
});

export const deleteLead = safeAction(async (fd) => {
  const user = await requirePermission("deleteLeads");
  const id = String(fd.get("id"));
  const [lead] = await db.select({ code: t.leads.leadCode, businessId: t.leads.businessId }).from(t.leads).where(eq(t.leads.id, id));
  if (!lead) redirect("/admin/leads");
  const atts = await db.select({ fileId: t.leadAttachments.fileId }).from(t.leadAttachments).where(eq(t.leadAttachments.leadId, id));
  await db.transaction(async (tx) => {
    await tx.delete(t.leads).where(eq(t.leads.id, id));
    const others = await tx.select({ id: t.leads.id }).from(t.leads).where(eq(t.leads.businessId, lead.businessId)).limit(1);
    if (!others.length) await tx.delete(t.businesses).where(eq(t.businesses.id, lead.businessId));
  });
  for (const a of atts) await deleteFile(a.fileId);
  await audit(user.id, "delete", "lead", id, { leadCode: lead.code, note: "Row remains in Google Sheets for record-keeping; remove manually if required." });
  redirect("/admin/leads?deleted=1");
});

export const resyncLead = safeAction(async (fd) => {
  const user = await requirePermission("retrySync");
  const id = String(fd.get("id"));
  await enqueueLeadSync(id);
  const r = await processSyncJobs({ leadIds: [id] });
  await audit(user.id, "resync", "lead", id);
  return { ok: true, message: "skipped" in r ? `Queued — ${r.skipped}.` : `Sync attempted: ${r.ok} succeeded, ${r.failed} failed.` };
});
