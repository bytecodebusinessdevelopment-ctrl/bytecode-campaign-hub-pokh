import type { Metadata } from "next";
import Link from "next/link";
import { Download, Phone, MessageCircle, Plus, Zap, AlertTriangle, Search } from "lucide-react";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { listLeads, lookupsForLeads, type LeadFilters } from "@/lib/lead-queries";
import { PageHeader, Pagination, Empty } from "@/components/admin/server-ui";
import { Badge } from "@/components/admin/ui";
import { formatDate, formatNpr, relativeDays } from "@/lib/format";
import { telLink, whatsappLink } from "@/lib/utils";

export const metadata: Metadata = { title: "Leads" };

export default async function LeadsPage({ searchParams }: { searchParams: Promise<LeadFilters> }) {
  const user = await requireUser();
  const f = await searchParams;
  const [{ rows, total, page, pages }, lk] = await Promise.all([listLeads(user, f), lookupsForLeads()]);
  const qs = new URLSearchParams(Object.entries(f).filter(([k, v]) => v && k !== "page") as [string, string][]).toString();
  const filtered = Object.entries(f).some(([k, v]) => v && !["page", "sort"].includes(k));
  const viewAll = can(user.role, "viewAllLeads");

  return (
    <div>
      <PageHeader
        title="Leads"
        subtitle={`${total} lead${total === 1 ? "" : "s"}${filtered ? " match your filters" : ""}${viewAll ? "" : " assigned to or created by you"}`}
        actions={
          <>
            {can(user.role, "exportLeads") && (
              <>
                <a href={`/api/leads/export?format=csv&${qs}`} className="btn-outline btn-sm"><Download className="h-4 w-4" /> CSV</a>
                <a href={`/api/leads/export?format=xlsx&${qs}`} className="btn-outline btn-sm"><Download className="h-4 w-4" /> Excel</a>
              </>
            )}
            <Link href="/admin/leads/new" className="btn-outline btn-sm"><Plus className="h-4 w-4" /> New lead</Link>
            <Link href="/admin/leads/quick" className="btn-accent btn-sm"><Zap className="h-4 w-4" /> Quick capture</Link>
          </>
        }
      />

      <form className="card mb-4 p-4" role="search">
        <div className="flex gap-2">
          <label className="relative flex-1"><span className="sr-only">Search</span><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" /><input name="q" defaultValue={f.q} placeholder="Search business, contact, phone, email or Lead ID" className="input pl-9" /></label>
          <button className="btn-primary">Search</button>
        </div>
        <details className="mt-3" open={filtered}>
          <summary className="cursor-pointer text-sm font-semibold text-brand">Filters & sorting</summary>
          <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
            <Sel name="status" label="Status" v={f.status} opts={lk.statuses.map((s) => [s.id, s.name])} />
            <Sel name="source" label="Source" v={f.source} opts={lk.sources.map((s) => [s.id, s.name])} />
            <Sel name="campaign" label="Campaign" v={f.campaign} opts={lk.campaigns.map((s) => [s.id, s.name])} />
            <Sel name="industry" label="Industry" v={f.industry} opts={lk.industries.map((s) => [s.id, s.name])} />
            <Sel name="service" label="Service" v={f.service} opts={lk.services.map((s) => [s.id, s.label])} />
            <Sel name="assigned" label="Assigned to" v={f.assigned} opts={[["me", "Me"], ...(viewAll ? [["none", "Unassigned"], ...lk.users.map((u) => [u.id, u.name])] : [])]} />
            <Sel name="priority" label="Priority" v={f.priority} opts={[["hot", "Hot"], ["warm", "Warm"], ["cold", "Cold"]]} />
            <Sel name="entry" label="Entry type" v={f.entry} opts={[["public_enquiry", "Website enquiry"], ["internal", "Internal entry"], ["quick_capture", "Quick capture"]]} />
            <Sel name="followup" label="Follow-up" v={f.followup} opts={[["overdue", "Overdue"], ["today", "Due today"], ["none", "No follow-up set"]]} />
            <label className="text-xs font-medium text-ink-muted">From<input type="date" name="from" defaultValue={f.from} className="input-sm mt-1" /></label>
            <label className="text-xs font-medium text-ink-muted">To<input type="date" name="to" defaultValue={f.to} className="input-sm mt-1" /></label>
            <Sel name="sort" label="Sort" v={f.sort} placeholder="Newest first" opts={[["oldest", "Oldest first"], ["updated", "Recently updated"], ["followup", "Follow-up date"], ["value", "Estimated value"], ["business", "Business name"]]} />
          </div>
          <label className="mt-3 flex items-center gap-2 text-sm text-ink-soft"><input type="checkbox" name="duplicates" value="1" defaultChecked={f.duplicates === "1"} className="check" /> Only possible duplicates awaiting review</label>
          <div className="mt-3 flex gap-2"><button className="btn-primary btn-sm">Apply</button><Link href="/admin/leads" className="btn-ghost btn-sm">Reset</Link></div>
        </details>
      </form>

      {rows.length === 0 ? (
        <Empty>No leads found. {filtered ? <Link href="/admin/leads" className="text-brand">Clear filters</Link> : <Link href="/admin/leads/quick" className="text-brand">Capture your first lead</Link>}</Empty>
      ) : (
        <>
          {/* Mobile cards */}
          <ul className="space-y-3 md:hidden">
            {rows.map((r) => {
              const overdue = r.nextFollowUpAt && r.nextFollowUpAt.getTime() < Date.now() && !r.statusIsWon && !r.statusIsLost;
              return (
                <li key={r.id} className="card p-4">
                  <Link href={`/admin/leads/${r.id}`} className="block">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0"><p className="truncate font-semibold text-navy">{r.businessName}</p><p className="text-xs text-ink-muted">{r.leadCode} · {r.location ?? "—"}</p></div>
                      <Badge color={r.statusColor}>{r.statusName}</Badge>
                    </div>
                    {r.services && <p className="mt-2 line-clamp-1 text-xs text-ink-soft">{r.services}</p>}
                    {r.nextFollowUpAt && <p className={`mt-2 text-xs font-medium ${overdue ? "text-red-600" : "text-ink-soft"}`}>Follow-up {relativeDays(r.nextFollowUpAt)}{r.nextAction ? ` — ${r.nextAction}` : ""}</p>}
                  </Link>
                  {(r.phone || r.whatsapp) && (
                    <div className="mt-3 flex gap-2 border-t border-line pt-3">
                      {r.phone && <a href={telLink(r.phone)!} className="btn-outline btn-sm flex-1"><Phone className="h-4 w-4" /> Call</a>}
                      {(r.whatsapp || r.phone) && <a href={whatsappLink(r.whatsapp || r.phone)!} target="_blank" rel="noopener noreferrer" className="btn-outline btn-sm flex-1"><MessageCircle className="h-4 w-4" /> WhatsApp</a>}
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
          {/* Desktop table */}
          <div className="table-wrap hidden md:block">
            <table className="table">
              <thead><tr><th>Lead</th><th>Contact</th><th>Services</th><th>Source</th><th>Status</th>{viewAll && <th>Assigned</th>}<th>Follow-up</th><th className="text-right">Est. value</th><th>Created</th></tr></thead>
              <tbody>
                {rows.map((r) => {
                  const overdue = r.nextFollowUpAt && r.nextFollowUpAt.getTime() < Date.now() && !r.statusIsWon && !r.statusIsLost;
                  return (
                    <tr key={r.id} className="hover:bg-surface/60">
                      <td className="min-w-[200px]">
                        <Link href={`/admin/leads/${r.id}`} className="font-semibold text-navy hover:text-brand">{r.businessName}</Link>
                        <div className="text-xs text-ink-muted">{r.leadCode} · {r.location ?? "—"}{r.industry ? ` · ${r.industry}` : ""}</div>
                        <div className="mt-1 flex gap-1">
                          {r.priority && <span className={`badge ${r.priority === "hot" ? "bg-red-100 text-red-700" : r.priority === "warm" ? "bg-amber-100 text-amber-800" : "bg-slate-100 text-slate-600"}`}>{r.priority}</span>}
                          {r.possibleDuplicateOf && !r.duplicateReviewed && <span className="badge bg-amber-100 text-amber-800"><AlertTriangle className="h-3 w-3" /> Duplicate?</span>}
                          {!r.isComplete && <span className="badge bg-slate-100 text-slate-600">Partial</span>}
                        </div>
                      </td>
                      <td className="text-xs"><div className="font-medium text-navy">{r.contactName ?? "—"}</div><div className="text-ink-muted">{r.phone ?? r.email ?? ""}</div></td>
                      <td className="max-w-[220px] text-xs text-ink-soft">{r.services ?? "—"}</td>
                      <td className="text-xs text-ink-soft">{r.sourceName ?? "—"}</td>
                      <td><Badge color={r.statusColor}>{r.statusName}</Badge></td>
                      {viewAll && <td className="text-xs text-ink-soft">{r.assigneeName ?? <span className="text-amber-700">Unassigned</span>}</td>}
                      <td className={`whitespace-nowrap text-xs ${overdue ? "font-semibold text-red-600" : "text-ink-soft"}`}>{r.nextFollowUpAt ? <>{formatDate(r.nextFollowUpAt)}<div className="font-normal">{relativeDays(r.nextFollowUpAt)}</div></> : "—"}</td>
                      <td className="whitespace-nowrap text-right text-xs tabular-nums">{r.estimatedValueNpr ? formatNpr(r.estimatedValueNpr) : "—"}</td>
                      <td className="whitespace-nowrap text-xs text-ink-muted">{formatDate(r.createdAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination page={page} pages={pages} params={f as Record<string, string | undefined>} basePath="/admin/leads" />
        </>
      )}
    </div>
  );
}

function Sel({ name, label, v, opts, placeholder }: { name: string; label: string; v?: string; opts: (string[] | [string, string])[]; placeholder?: string }) {
  return (
    <label className="text-xs font-medium text-ink-muted">{label}
      <select name={name} defaultValue={v ?? ""} className="input-sm mt-1">
        <option value="">{placeholder ?? "Any"}</option>
        {opts.map(([val, l]) => <option key={val} value={val}>{l}</option>)}
      </select>
    </label>
  );
}
