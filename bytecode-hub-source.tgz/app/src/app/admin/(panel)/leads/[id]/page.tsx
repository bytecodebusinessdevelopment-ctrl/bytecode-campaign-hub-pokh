import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq } from "drizzle-orm";
import { Phone, MessageCircle, Mail, Globe, AlertTriangle, CheckCircle2, Calendar, Paperclip, RefreshCcw, ExternalLink, Trash2 } from "lucide-react";
import { db, t } from "@/lib/db";
import { requireUser, leadScope } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { lookupsForLeads } from "@/lib/lead-queries";
import { QUESTION_SETS } from "@/lib/enquiry-config";
import { formatDate, formatDateTime, formatNpr, relativeDays, toNepalInput } from "@/lib/format";
import { telLink, whatsappLink } from "@/lib/utils";
import { Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton, Badge } from "@/components/admin/ui";
import { LeadForm } from "@/components/admin/lead-form";
import { FileUpload } from "@/components/admin/file-upload";
import { ClearLeadDraft } from "@/components/admin/clear-draft";
import {
  updateLead, setStatus, assignLead, addActivity, scheduleFollowUp, completeFollowUp, addMeeting, completeMeeting,
  addAttachment, removeAttachment, mergeLeadAction, dismissDuplicate, deleteLead, resyncLead,
} from "../actions";

export const metadata: Metadata = { title: "Lead" };

const ENTRY_LABEL = { public_enquiry: "Website enquiry", internal: "Internal entry", quick_capture: "Quick capture" } as const;
const ACTIVITY_ICON: Record<string, string> = { note: "📝", call: "📞", whatsapp: "💬", email: "✉️", meeting: "🤝", follow_up: "⏰", status_change: "🔁", system: "•" };

export default async function LeadPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ created?: string; merged?: string }> }) {
  const user = await requireUser();
  const { id } = await params;
  const sp = await searchParams;
  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const scope = leadScope(user);
  const lead = await db.query.leads.findFirst({
    where: scope ? and(eq(t.leads.id, id), scope) : eq(t.leads.id, id),
    with: {
      business: { with: { industry: true, contacts: true } }, contact: true, campaign: true, source: true, status: true, budgetRange: true,
      assignee: { columns: { id: true, name: true } }, creator: { columns: { name: true } },
      services: { with: { enquiryService: true } }, answers: true,
      activities: { orderBy: desc(t.activities.createdAt), with: { creator: { columns: { name: true } }, assignee: { columns: { name: true } } } },
      meetings: { orderBy: desc(t.meetings.scheduledAt) },
      attachments: { with: { file: true }, orderBy: desc(t.leadAttachments.createdAt) },
    },
  });
  if (!lead) notFound();
  if (lead.mergedInto) {
    return <div className="card p-8 text-center"><p className="font-semibold">This lead ({lead.leadCode}) was merged into another lead.</p><Link href={`/admin/leads/${lead.mergedInto}`} className="btn-primary mt-4">Open the primary lead</Link></div>;
  }
  const [lk, sync, dupOf] = await Promise.all([
    lookupsForLeads(),
    db.select().from(t.sheetSyncJobs).where(eq(t.sheetSyncJobs.leadId, id)).orderBy(asc(t.sheetSyncJobs.target)),
    lead.possibleDuplicateOf && !lead.duplicateReviewed
      ? db.select({ id: t.leads.id, code: t.leads.leadCode, business: t.businesses.name, mergedInto: t.leads.mergedInto }).from(t.leads).innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId)).where(eq(t.leads.id, lead.possibleDuplicateOf)).then((r) => r[0])
      : Promise.resolve(null),
  ]);
  const openFollowUps = lead.activities.filter((a) => a.type === "follow_up" && !a.completedAt).sort((a, b) => (a.dueAt?.getTime() ?? 0) - (b.dueAt?.getTime() ?? 0));
  const timeline = lead.activities.filter((a) => !(a.type === "follow_up" && !a.completedAt));
  const c = lead.contact;
  const wa = whatsappLink(c?.whatsapp || c?.phone, `Namaste${c?.fullName ? ` ${c.fullName.split(" ")[0]}` : ""}, this is ${user.name.split(" ")[0]} from ByteCode Developers.`);
  const closed = lead.status.isWon || lead.status.isLost;

  return (
    <div>
      {sp.created && <><ClearLeadDraft /><p className="mb-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">Lead <strong>{lead.leadCode}</strong> saved.</p></>}
      {sp.merged && <p className="mb-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">Duplicate merged into this lead.</p>}

      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0">
          <Link href="/admin/leads" className="text-sm text-ink-muted hover:text-brand">← Leads</Link>
          <h1 className="mt-1 text-2xl font-extrabold sm:text-3xl">{lead.business.name}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-ink-muted">
            <span className="font-mono font-semibold text-navy">{lead.leadCode}</span>
            <Badge color={lead.status.color}>{lead.status.name}</Badge>
            {lead.priority && <span className={`badge ${lead.priority === "hot" ? "bg-red-100 text-red-700" : lead.priority === "warm" ? "bg-amber-100 text-amber-800" : "bg-slate-100 text-slate-600"}`}>{lead.priority}</span>}
            {!lead.isComplete && <span className="badge bg-slate-100 text-slate-600">Partial information</span>}
            <span>· {ENTRY_LABEL[lead.entryType]} · {formatDateTime(lead.createdAt)}{lead.creator ? ` by ${lead.creator.name}` : ""}</span>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2 sm:flex">
          {c?.phone && <a href={telLink(c.phone)!} className="btn-outline btn-sm"><Phone className="h-4 w-4" /> Call</a>}
          {wa && <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-outline btn-sm"><MessageCircle className="h-4 w-4" /> WhatsApp</a>}
          {c?.email && <a href={`mailto:${c.email}`} className="btn-outline btn-sm"><Mail className="h-4 w-4" /> Email</a>}
        </div>
      </div>

      {dupOf && (
        <div className="mb-6 rounded-2xl border border-amber-300 bg-amber-50 p-4">
          <p className="flex items-center gap-2 font-semibold text-amber-900"><AlertTriangle className="h-5 w-5" /> Possible duplicate of <Link href={`/admin/leads/${dupOf.id}`} className="underline">{dupOf.code} — {dupOf.business}</Link></p>
          <p className="mt-1 text-sm text-amber-800">Same phone, email or business name and location. Merge to combine the records, or dismiss if they are different businesses.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {can(user.role, "mergeLeads") && !dupOf.mergedInto && (
              <ActionForm action={mergeLeadAction} refresh={false}>
                <input type="hidden" name="duplicateId" value={lead.id} /><input type="hidden" name="primaryId" value={dupOf.id} />
                <SubmitButton className="btn-primary btn-sm" confirm={`Merge ${lead.leadCode} into ${dupOf.code}? This lead's notes, meetings and attachments will move to ${dupOf.code}.`}>Merge into {dupOf.code}</SubmitButton>
              </ActionForm>
            )}
            <ActionForm action={dismissDuplicate}><input type="hidden" name="id" value={lead.id} /><SubmitButton className="btn-outline btn-sm">Not a duplicate</SubmitButton></ActionForm>
          </div>
        </div>
      )}

      <div className="grid gap-5 xl:grid-cols-[1fr_380px]">
        <div className="min-w-0 space-y-5">
          {/* Status & assignment */}
          <Section title="Pipeline">
            <div className="grid gap-4 md:grid-cols-2">
              <ActionForm action={setStatus} className="space-y-2">
                <input type="hidden" name="id" value={lead.id} />
                <label className="label" htmlFor="statusId">Status</label>
                <select id="statusId" name="statusId" defaultValue={lead.statusId} className="input">{lk.statuses.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
                <input name="note" placeholder="Note (required when marking Lost)" className="input" />
                <SubmitButton className="btn-primary btn-sm">Update status</SubmitButton>
              </ActionForm>
              {can(user.role, "assignLeads") ? (
                <ActionForm action={assignLead} className="space-y-2">
                  <input type="hidden" name="id" value={lead.id} />
                  <label className="label" htmlFor="assignedTo">Assigned team member</label>
                  <select id="assignedTo" name="assignedTo" defaultValue={lead.assignedTo ?? ""} className="input"><option value="">Unassigned</option>{lk.users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select>
                  <SubmitButton className="btn-outline btn-sm">Assign</SubmitButton>
                </ActionForm>
              ) : (
                <div><p className="label">Assigned team member</p><p className="text-sm">{lead.assignee?.name ?? "Unassigned"}</p></div>
              )}
            </div>
            {lead.lostReason && <p className="mt-3 rounded-xl bg-red-50 px-3 py-2 text-sm text-red-800"><strong>Lost reason:</strong> {lead.lostReason}</p>}
          </Section>

          {/* Follow-ups */}
          <Section title="Follow-ups">
            {openFollowUps.length > 0 ? (
              <ul className="mb-4 space-y-2">
                {openFollowUps.map((a) => {
                  const overdue = a.dueAt && a.dueAt.getTime() < Date.now();
                  return (
                    <li key={a.id} className={`rounded-xl border p-3 ${overdue ? "border-red-200 bg-red-50" : "border-line"}`}>
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div><p className="font-semibold text-navy">{a.title}</p><p className={`text-xs ${overdue ? "font-semibold text-red-700" : "text-ink-muted"}`}>{formatDateTime(a.dueAt)} ({relativeDays(a.dueAt)}){a.assignee ? ` · ${a.assignee.name}` : ""}</p>{a.body && <p className="mt-1 text-sm text-ink-soft">{a.body}</p>}</div>
                      </div>
                      <ActionForm action={completeFollowUp} className="mt-2 flex flex-col gap-2 sm:flex-row">
                        <input type="hidden" name="activityId" value={a.id} />
                        <input name="outcome" placeholder="Outcome (optional)" className="input-sm flex-1" />
                        <SubmitButton className="btn-accent btn-sm"><CheckCircle2 className="h-4 w-4" /> Done</SubmitButton>
                      </ActionForm>
                    </li>
                  );
                })}
              </ul>
            ) : !closed ? <p className="mb-4 rounded-xl bg-amber-50 px-3 py-2 text-sm text-amber-800">No follow-up scheduled — set the next action below.</p> : null}
            <ActionForm action={scheduleFollowUp} resetOnSuccess className="grid gap-2 sm:grid-cols-[1fr_200px_auto]">
              <input type="hidden" name="id" value={lead.id} />
              <input name="title" placeholder="Next action, e.g. Send proposal" className="input-sm" required />
              <input type="datetime-local" name="dueAt" required defaultValue={toNepalInput(new Date(Date.now() + 2 * 86400000)).slice(0, 11) + "10:00"} className="input-sm" />
              <SubmitButton className="btn-primary btn-sm">Schedule</SubmitButton>
            </ActionForm>
          </Section>

          {/* Timeline */}
          <Section title="Activity & notes">
            <ActionForm action={addActivity} resetOnSuccess className="mb-5 space-y-2">
              <input type="hidden" name="id" value={lead.id} />
              <textarea name="body" rows={2} placeholder="Record a discussion, call outcome or internal note…" className="input" required />
              <div className="flex flex-wrap items-center gap-2">
                <select name="type" className="input-sm w-auto" defaultValue="note" aria-label="Type"><option value="note">Internal note</option><option value="call">Phone call</option><option value="whatsapp">WhatsApp</option><option value="email">Email</option></select>
                <SubmitButton className="btn-primary btn-sm">Add</SubmitButton>
              </div>
            </ActionForm>
            <ol className="relative space-y-4 border-l border-line pl-5">
              {timeline.map((a) => (
                <li key={a.id} className="relative">
                  <span className="absolute -left-[29px] grid h-6 w-6 place-items-center rounded-full bg-white text-xs ring-1 ring-line" aria-hidden>{ACTIVITY_ICON[a.type]}</span>
                  <p className="text-sm font-semibold text-navy">{a.title}{a.type === "follow_up" && a.completedAt && <span className="ml-2 badge bg-emerald-100 text-emerald-700">completed</span>}</p>
                  {a.body && <p className="mt-0.5 whitespace-pre-line text-sm text-ink-soft">{a.body}</p>}
                  <p className="mt-0.5 text-xs text-ink-muted">{formatDateTime(a.createdAt)}{a.creator ? ` · ${a.creator.name}` : ""}</p>
                </li>
              ))}
            </ol>
          </Section>

          {/* Meetings */}
          <Section title="Meetings">
            {lead.meetings.length > 0 && (
              <ul className="mb-4 space-y-2">
                {lead.meetings.map((m) => (
                  <li key={m.id} className="rounded-xl border border-line p-3 text-sm">
                    <p className="flex items-center gap-2 font-semibold text-navy"><Calendar className="h-4 w-4 text-brand" /> {formatDateTime(m.scheduledAt)} <span className="font-normal text-ink-muted">· {m.mode.replace("_", " ")}{m.location ? ` · ${m.location}` : ""}</span>{m.completed && <span className="badge bg-emerald-100 text-emerald-700">done</span>}</p>
                    {m.attendees && <p className="text-ink-soft">With: {m.attendees}</p>}
                    {m.agenda && <p className="mt-1 text-ink-soft">{m.agenda}</p>}
                    {m.outcome && <p className="mt-1 text-ink-soft"><strong>Outcome:</strong> {m.outcome}</p>}
                    {!m.completed && (
                      <ActionForm action={completeMeeting} className="mt-2 flex flex-col gap-2 sm:flex-row"><input type="hidden" name="meetingId" value={m.id} /><input name="outcome" placeholder="Meeting outcome" className="input-sm flex-1" /><SubmitButton className="btn-outline btn-sm">Mark completed</SubmitButton></ActionForm>
                    )}
                  </li>
                ))}
              </ul>
            )}
            <details>
              <summary className="cursor-pointer text-sm font-semibold text-brand">+ Add a meeting</summary>
              <ActionForm action={addMeeting} resetOnSuccess className="mt-3 grid gap-2 sm:grid-cols-2">
                <input type="hidden" name="id" value={lead.id} />
                <label className="text-xs text-ink-muted">Date & time<input type="datetime-local" name="scheduledAt" required className="input-sm mt-1" /></label>
                <label className="text-xs text-ink-muted">Type<select name="mode" className="input-sm mt-1"><option value="in_person">In person</option><option value="video">Video call</option><option value="phone">Phone</option></select></label>
                <input name="location" placeholder="Location" className="input-sm" />
                <input name="attendees" placeholder="Attendees" className="input-sm" />
                <textarea name="agenda" placeholder="Agenda / details" rows={2} className="input sm:col-span-2" />
                <label className="flex items-center gap-2 text-sm text-ink-soft sm:col-span-2"><input type="checkbox" name="advance" defaultChecked className="check" /> Move status to &ldquo;Meeting Scheduled&rdquo; if it is earlier in the pipeline</label>
                <div className="sm:col-span-2"><SubmitButton className="btn-primary btn-sm">Save meeting</SubmitButton></div>
              </ActionForm>
            </details>
          </Section>

          {/* Requirements */}
          <Section title="Requirements">
            {lead.requirements ? <p className="whitespace-pre-line text-sm text-ink-soft">{lead.requirements}</p> : <p className="text-sm text-ink-muted">No requirements recorded yet.</p>}
            {lead.initialInterest && <p className="mt-2 text-sm"><strong>Initial interest:</strong> {lead.initialInterest}</p>}
            {lead.answers.map((ans) => {
              const set = QUESTION_SETS.find((q) => q.key === ans.setKey);
              if (!set) return null;
              return (
                <div key={ans.id} className="mt-5">
                  <h3 className="text-sm font-bold uppercase tracking-wide text-ink-muted">{set.title}</h3>
                  <dl className="mt-2 grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
                    {set.questions.filter((q) => ans.answers[q.key]).map((q) => (
                      <div key={q.key}><dt className="text-ink-muted">{q.label}</dt><dd className="whitespace-pre-line text-navy">{ans.answers[q.key]}</dd></div>
                    ))}
                  </dl>
                </div>
              );
            })}
          </Section>

          {/* Edit */}
          <details className="card p-5 sm:p-6">
            <summary className="cursor-pointer text-lg font-bold">Edit lead details</summary>
            <div className="mt-5">
              <LeadForm
                action={updateLead}
                mode="edit"
                values={{
                  id: lead.id, businessName: lead.business.name, industryId: lead.business.industryId ?? "", location: lead.business.location ?? "", address: lead.business.address ?? "",
                  website: lead.business.website ?? "", facebook: lead.business.facebook ?? "", instagram: lead.business.instagram ?? "", socialOther: lead.business.otherLinks ?? "",
                  contactName: c?.fullName ?? "", designation: c?.designation ?? "", phone: c?.phone ?? "", whatsapp: c?.whatsapp ?? "", email: c?.email ?? "",
                  services: lead.services.map((s) => s.enquiryServiceId), requirements: lead.requirements ?? "", initialInterest: lead.initialInterest ?? "",
                  budgetRangeId: lead.budgetRangeId ?? "", budgetCustom: lead.budgetCustom ?? "", estimatedValue: lead.estimatedValueNpr ? String(Math.round(Number(lead.estimatedValueNpr))) : "",
                  timeline: lead.timeline ?? "", campaignId: lead.campaignId ?? "", sourceId: lead.sourceId ?? "", priority: lead.priority ?? "",
                  preferredContactMethod: lead.preferredContactMethod ?? "", meetingPreference: lead.meetingPreference ?? "", comments: lead.comments ?? "",
                }}
                lookups={{ industries: lk.industries, services: lk.services, budgets: lk.budgets.map((b) => ({ id: b.id, name: b.label })), campaigns: lk.campaigns, sources: lk.sources, users: lk.users }}
                canAssign={false}
                currentUserId={user.id}
              />
            </div>
          </details>
        </div>

        {/* Sidebar */}
        <aside className="space-y-5">
          <Section title="Summary">
            <dl className="space-y-2.5 text-sm">
              <Row k="Contact" v={c?.fullName ? `${c.fullName}${c.designation ? `, ${c.designation}` : ""}` : null} />
              <Row k="Phone" v={c?.phone} />
              <Row k="WhatsApp" v={c?.whatsapp} />
              <Row k="Email" v={c?.email} />
              <Row k="Industry" v={lead.business.industry?.name} />
              <Row k="Location" v={[lead.business.location, lead.business.address].filter(Boolean).join(" — ")} />
              <Row k="Services" v={lead.services.map((s) => s.enquiryService.label).join(", ")} />
              <Row k="Budget" v={lead.budgetRange?.label ?? lead.budgetCustom} />
              <Row k="Est. value" v={lead.estimatedValueNpr ? `${formatNpr(lead.estimatedValueNpr)} (estimate)` : null} />
              <Row k="Timeline" v={lead.timeline} />
              <Row k="Next action" v={lead.nextAction ? `${lead.nextAction} — ${formatDate(lead.nextFollowUpAt)}` : null} />
              <Row k="Campaign" v={lead.campaign?.name} />
              <Row k="Source" v={lead.source?.name} />
              <Row k="Prefers" v={[lead.preferredContactMethod, lead.meetingPreference].filter(Boolean).join(" · ")} />
              <Row k="Consent" v={lead.consentToContact ? `Yes — ${formatDate(lead.consentAt)}` : "Not recorded"} />
              {lead.utm && <Row k="Attribution" v={Object.entries(lead.utm).map(([k, v]) => `${k.replace("utm_", "")}: ${v}`).join(" · ")} />}
              {lead.landingPage && <Row k="Landing page" v={lead.landingPage} />}
            </dl>
            <div className="mt-4 flex flex-wrap gap-2">
              {lead.business.website && <a href={lead.business.website} target="_blank" rel="noopener noreferrer" className="chip hover:border-brand"><Globe className="h-3.5 w-3.5" /> Website</a>}
              {lead.business.facebook && <a href={lead.business.facebook.startsWith("http") ? lead.business.facebook : `https://facebook.com/${lead.business.facebook}`} target="_blank" rel="noopener noreferrer" className="chip hover:border-brand">Facebook</a>}
              {lead.business.instagram && <a href={lead.business.instagram.startsWith("http") ? lead.business.instagram : `https://instagram.com/${lead.business.instagram.replace("@", "")}`} target="_blank" rel="noopener noreferrer" className="chip hover:border-brand">Instagram</a>}
            </div>
            {lead.comments && <p className="mt-4 rounded-xl bg-surface p-3 text-sm text-ink-soft"><strong className="text-navy">Client comments:</strong> {lead.comments}</p>}
          </Section>

          <Section title="Attachments">
            {lead.attachments.length > 0 && (
              <ul className="mb-3 space-y-2">
                {lead.attachments.map((a) => (
                  <li key={a.id} className="flex items-center justify-between gap-2 rounded-xl border border-line p-2.5 text-sm">
                    <a href={`/api/files/${a.fileId}`} target="_blank" rel="noreferrer" className="flex min-w-0 items-center gap-2 text-navy hover:text-brand"><Paperclip className="h-4 w-4 shrink-0" /><span className="truncate">{a.caption || a.file.originalName}</span></a>
                    <ActionForm action={removeAttachment}><input type="hidden" name="attachmentId" value={a.id} /><SubmitButton className="btn-ghost btn-sm text-red-600" confirm="Delete this attachment?"><Trash2 className="h-4 w-4" /></SubmitButton></ActionForm>
                  </li>
                ))}
              </ul>
            )}
            <ActionForm action={addAttachment} resetOnSuccess className="space-y-2">
              <input type="hidden" name="id" value={lead.id} />
              <FileUpload name="fileId" purpose="any" help="Visiting card, photo, brief, etc. Private to the team." />
              <input name="caption" placeholder="Caption (optional)" className="input-sm" />
              <SubmitButton className="btn-outline btn-sm">Attach</SubmitButton>
            </ActionForm>
          </Section>

          <Section title="Google Sheets">
            {sync.length ? (
              <ul className="space-y-1.5 text-sm">
                {sync.map((j) => (
                  <li key={j.id} className="flex items-center justify-between gap-2">
                    <span className="capitalize text-ink-soft">{j.target === "campaign" ? "Campaign sheet" : "Central register"}</span>
                    <span className={`badge ${j.status === "success" ? "bg-emerald-100 text-emerald-700" : j.status === "failed" ? "bg-red-100 text-red-700" : "bg-slate-100 text-slate-600"}`} title={j.lastError ?? undefined}>{j.status}</span>
                  </li>
                ))}
              </ul>
            ) : <p className="text-sm text-ink-muted">Not queued.</p>}
            {sync.find((j) => j.lastError) && <p className="mt-2 text-xs text-ink-muted">{sync.find((j) => j.lastError)?.lastError}</p>}
            {can(user.role, "retrySync") && <ActionForm action={resyncLead} className="mt-3"><input type="hidden" name="id" value={lead.id} /><SubmitButton className="btn-outline btn-sm"><RefreshCcw className="h-4 w-4" /> Sync now</SubmitButton></ActionForm>}
          </Section>

          {can(user.role, "deleteLeads") && (
            <Section title="Danger zone">
              <p className="mb-3 text-sm text-ink-muted">Permanently delete this lead and its timeline. Use only for spam or test entries.</p>
              <ActionForm action={deleteLead} refresh={false}><input type="hidden" name="id" value={lead.id} /><SubmitButton className="btn-danger btn-sm" confirm={`Permanently delete ${lead.leadCode}? This cannot be undone.`}><Trash2 className="h-4 w-4" /> Delete lead</SubmitButton></ActionForm>
            </Section>
          )}
          <p className="px-1 text-xs text-ink-muted">Last updated {formatDateTime(lead.updatedAt)}</p>
          <Link href="/admin/present" className="flex items-center gap-2 px-1 text-sm font-semibold text-brand">Open presenter kit <ExternalLink className="h-4 w-4" /></Link>
        </aside>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v?: string | null }) {
  return <div className="grid grid-cols-[96px_1fr] gap-2"><dt className="text-ink-muted">{k}</dt><dd className="break-words text-navy">{v || <span className="text-ink-muted">—</span>}</dd></div>;
}

