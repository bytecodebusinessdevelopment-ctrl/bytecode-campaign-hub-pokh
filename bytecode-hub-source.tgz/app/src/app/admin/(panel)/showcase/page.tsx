import type { Metadata } from "next";
import Link from "next/link";
import { asc, desc } from "drizzle-orm";
import { Plus, ExternalLink } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Empty } from "@/components/admin/server-ui";
import { ClassificationBadge } from "@/components/public/cards";
import { DEMO_TYPE_LABELS } from "@/lib/enquiry-config";

export const metadata: Metadata = { title: "Demos & UI/UX" };

export default async function AdminDemos() {
  await requirePagePermission("manageContent");
  const rows = await db.query.demos.findMany({ with: { project: { columns: { title: true } } }, orderBy: [desc(t.demos.featured), asc(t.demos.sortOrder)] });
  return (
    <div>
      <PageHeader title="Demos & UI/UX" subtitle="Live websites, Vercel deployments, UI/UX previews and Figma prototypes — standalone or linked to a project." actions={<Link href="/admin/showcase/new" className="btn-primary btn-sm"><Plus className="h-4 w-4" /> Add demo</Link>} />
      {rows.length ? (
        <div className="table-wrap"><table className="table">
          <thead><tr><th>Demo</th><th>Type</th><th>Classification</th><th>Project</th><th>Visibility</th><th>Embed</th></tr></thead>
          <tbody>{rows.map((d) => (
            <tr key={d.id}>
              <td><Link href={`/admin/showcase/${d.id}`} className="font-semibold text-navy hover:text-brand">{d.title}</Link><a href={d.url} target="_blank" rel="noopener noreferrer" className="mt-0.5 flex items-center gap-1 text-xs text-ink-muted hover:text-brand"><span className="max-w-[260px] truncate">{d.url}</span><ExternalLink className="h-3 w-3" /></a></td>
              <td className="text-xs">{DEMO_TYPE_LABELS[d.demoType]}</td>
              <td><ClassificationBadge value={d.classification} /></td>
              <td className="text-xs text-ink-soft">{d.project?.title ?? "Standalone"}</td>
              <td><span className={`badge ${d.visibility === "public" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>{d.visibility === "public" ? "Public" : "Team only"}</span>{d.status !== "live" && <span className="badge ml-1 bg-amber-100 text-amber-800">{d.status}</span>}</td>
              <td className="text-xs">{d.embeddable ? "Yes" : "Link only"}</td>
            </tr>
          ))}</tbody>
        </table></div>
      ) : <Empty>No demos yet. Add your Vercel deployments and UI/UX prototypes here.</Empty>}
    </div>
  );
}
