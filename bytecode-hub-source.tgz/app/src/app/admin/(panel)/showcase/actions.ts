"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { safeAction } from "@/lib/action";
import { requirePermission } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { refreshFilePublicity } from "@/lib/storage";
import { bool, int, lines, safeUrl, str } from "@/lib/utils";

const TYPES = ["live_site", "vercel", "uiux_preview", "figma", "video", "other"] as const;
const CLASSES = ["client_project", "internal_demo", "uiux_concept", "prototype", "in_progress"] as const;

export const saveDemo = safeAction(async (fd) => {
  const user = await requirePermission("manageContent");
  const id = str(fd.get("id"));
  const title = str(fd.get("title"));
  const url = safeUrl(str(fd.get("url")));
  if (!title) throw new Error("Title is required.");
  if (!url) throw new Error("A valid URL (https://…) is required.");
  const demoType = String(fd.get("demoType")) as (typeof TYPES)[number];
  const classification = String(fd.get("classification")) as (typeof CLASSES)[number];
  if (!TYPES.includes(demoType) || !CLASSES.includes(classification)) throw new Error("Choose a type and classification.");
  const visibility = (["public", "private", "internal"].includes(String(fd.get("visibility"))) ? String(fd.get("visibility")) : "public") as "public" | "private" | "internal";
  const [existing] = id ? await db.select().from(t.demos).where(eq(t.demos.id, id)) : [];
  const values = {
    title, url, demoType, classification, visibility,
    description: str(fd.get("description")), projectId: str(fd.get("projectId")), industryId: str(fd.get("industryId")),
    previewFileId: str(fd.get("previewFileId")), status: (str(fd.get("status")) ?? "live") as "live" | "beta" | "archived",
    technologies: lines(fd.get("technologies")), embeddable: bool(fd.get("embeddable")), featured: bool(fd.get("featured")),
    sortOrder: int(fd.get("sortOrder")) ?? 0, updatedAt: new Date(),
  };
  let demoId = id;
  if (id) await db.update(t.demos).set(values).where(eq(t.demos.id, id));
  else demoId = (await db.insert(t.demos).values(values).returning({ id: t.demos.id }))[0].id;
  await refreshFilePublicity([values.previewFileId, existing?.previewFileId]);
  await audit(user.id, id ? "update" : "create", "demo", demoId, { title });
  revalidatePath("/showcase");
  revalidatePath("/", "layout");
  if (!id) redirect(`/admin/showcase/${demoId}?saved=1`);
  return { ok: true, message: "Saved." };
});

export const deleteDemo = safeAction(async (fd) => {
  const user = await requirePermission("manageContent");
  const id = String(fd.get("id"));
  await db.delete(t.demos).where(eq(t.demos.id, id));
  await audit(user.id, "delete", "demo", id);
  revalidatePath("/showcase");
  redirect("/admin/showcase");
});
