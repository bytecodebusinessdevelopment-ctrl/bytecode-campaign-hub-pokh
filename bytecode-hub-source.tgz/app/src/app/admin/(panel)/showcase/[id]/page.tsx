import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { ExternalLink, Trash2 } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { FileUpload } from "@/components/admin/file-upload";
import { CLASSIFICATION_LABELS, DEMO_TYPE_LABELS } from "@/lib/enquiry-config";
import { saveDemo, deleteDemo } from "../actions";

export const metadata: Metadata = { title: "Edit demo" };

export default async function EditDemo({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ project?: string; saved?: string }> }) {
  await requirePagePermission("manageContent");
  const { id } = await params;
  const sp = await searchParams;
  const isNew = id === "new";
  const d = isNew ? null : await db.query.demos.findFirst({ where: eq(t.demos.id, id), with: { preview: true } });
  if (!isNew && !d) notFound();
  const [projects, industries] = await Promise.all([
    db.select({ id: t.portfolioProjects.id, title: t.portfolioProjects.title }).from(t.portfolioProjects).orderBy(asc(t.portfolioProjects.title)),
    db.select().from(t.industries).orderBy(asc(t.industries.sortOrder)),
  ]);
  return (
    <div className="mx-auto max-w-3xl">
      {sp.saved && <p className="mb-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">Demo created.</p>}
      <PageHeader title={isNew ? "Add demo" : d!.title} back={{ href: "/admin/showcase", label: "Demos & UI/UX" }} actions={d && d.visibility === "public" ? <Link href={`/showcase/${d.id}`} target="_blank" className="btn-outline btn-sm">View on site <ExternalLink className="h-4 w-4" /></Link> : undefined} />
      <ActionForm action={saveDemo} className="space-y-5">
        {d && <input type="hidden" name="id" value={d.id} />}
        <Section title="Demo details">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Name *" className="sm:col-span-2"><input name="title" required defaultValue={d?.title} className="input" /></L>
            <L label="URL *" className="sm:col-span-2"><input name="url" required defaultValue={d?.url} placeholder="https://your-demo.vercel.app" className="input" /></L>
            <L label="Demo type"><select name="demoType" defaultValue={d?.demoType ?? "vercel"} className="input">{Object.entries(DEMO_TYPE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></L>
            <L label="Classification" hint="Be honest — concepts are labelled as concepts."><select name="classification" defaultValue={d?.classification ?? "internal_demo"} className="input">{Object.entries(CLASSIFICATION_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></L>
            <L label="Linked portfolio project"><select name="projectId" defaultValue={d?.projectId ?? sp.project ?? ""} className="input"><option value="">Standalone demo</option>{projects.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}</select></L>
            <L label="Category (industry)"><select name="industryId" defaultValue={d?.industryId ?? ""} className="input"><option value="">—</option>{industries.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</select></L>
            <L label="Description" className="sm:col-span-2"><textarea name="description" rows={3} defaultValue={d?.description ?? ""} className="input" /></L>
            <L label="Technologies" hint="One per line"><textarea name="technologies" rows={3} defaultValue={d?.technologies.join("\n")} className="input" /></L>
            <div><FileUpload name="previewFileId" purpose="image" label="Preview image" initial={d?.preview ? { id: d.preview.id, name: d.preview.originalName } : null} /></div>
          </div>
        </Section>
        <Section title="Display">
          <div className="grid gap-4 sm:grid-cols-3">
            <L label="Status"><select name="status" defaultValue={d?.status ?? "live"} className="input"><option value="live">Live</option><option value="beta">Beta</option><option value="archived">Archived (hidden)</option></select></L>
            <L label="Visibility"><select name="visibility" defaultValue={d?.visibility ?? "public"} className="input"><option value="public">Public</option><option value="internal">Team only (presenter kit)</option></select></L>
            <L label="Display order"><input name="sortOrder" defaultValue={d?.sortOrder ?? 0} className="input" /></L>
            <label className="flex items-start gap-3 text-sm sm:col-span-3"><input type="checkbox" name="embeddable" defaultChecked={d?.embeddable} className="check mt-0.5" /> <span>Show an embedded preview — tick only after checking the site opens inside a frame (many sites block this). An &ldquo;Open&rdquo; link is always shown.</span></label>
            <label className="flex items-center gap-3 text-sm sm:col-span-3"><input type="checkbox" name="featured" defaultChecked={d?.featured} className="check" /> Feature on the home page</label>
          </div>
        </Section>
        <div className="flex justify-end"><SubmitButton>Save demo</SubmitButton></div>
      </ActionForm>
      {d && <Section title="Delete" className="mt-5"><ActionForm action={deleteDemo} refresh={false}><input type="hidden" name="id" value={d.id} /><SubmitButton className="btn-danger btn-sm" confirm="Delete this demo?"><Trash2 className="h-4 w-4" /> Delete demo</SubmitButton></ActionForm></Section>}
    </div>
  );
}

function L({ label, hint, children, className }: { label: string; hint?: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className ?? ""}`}><span className="label">{label}</span>{children}{hint && <span className="hint block">{hint}</span>}</label>;
}
