import type { Metadata } from "next";
import Link from "next/link";
import { and, asc, desc, eq, gte, isNotNull, isNull, lt, or, sql } from "drizzle-orm";
import { CheckCircle2, Phone, MessageCircle } from "lucide-react";
import { db, t } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { PageHeader, Tabs, Empty } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { formatDateTime, relativeDays } from "@/lib/format";
import { telLink, whatsappLink } from "@/lib/utils";
import { completeFollowUp } from "../leads/actions";

export const metadata: Metadata = { title: "Follow-ups" };

type Tab = "upcoming" | "overdue" | "completed" | "meetings";

export default async function FollowUpsPage({ searchParams }: { searchParams: Promise<{ tab?: Tab; who?: string }> }) {
  const user = await requireUser();
  const sp = await searchParams;
  const tab: Tab = sp.tab ?? "upcoming";
  const viewAll = can(user.role, "viewAllLeads");
  const mineOnly = !viewAll || sp.who === "me";
  const owner = mineOnly ? or(eq(t.activities.assignedTo, user.id), and(isNull(t.activities.assignedTo), eq(t.leads.createdBy, user.id)), eq(t.leads.assignedTo, user.id)) : undefined;
  const base = and(eq(t.activities.type, "follow_up"), isNull(t.leads.mergedInto), owner);
  const now = new Date();

  const countWhere = async (w: ReturnType<typeof and>) => Number((await db.select({ n: sql<number>`count(*)::int` }).from(t.activities).innerJoin(t.leads, eq(t.leads.id, t.activities.leadId)).where(w))[0]?.n ?? 0);
  const counts = await Promise.all([
    countWhere(and(base, isNull(t.activities.completedAt), gte(t.activities.dueAt, now))),
    countWhere(and(base, isNull(t.activities.completedAt), lt(t.activities.dueAt, now))),
  ]);

  const where =
    tab === "overdue" ? and(base, isNull(t.activities.completedAt), lt(t.activities.dueAt, now))
    : tab === "completed" ? and(base, isNotNull(t.activities.completedAt))
    : and(base, isNull(t.activities.completedAt), gte(t.activities.dueAt, now));

  const items = tab === "meetings" ? [] : await db
    .select({
      id: t.activities.id, title: t.activities.title, body: t.activities.body, due: t.activities.dueAt, done: t.activities.completedAt,
      leadId: t.leads.id, code: t.leads.leadCode, business: t.businesses.name, assignee: t.users.name, phone: t.contacts.phone, whatsapp: t.contacts.whatsapp,
    })
    .from(t.activities)
    .innerJoin(t.leads, eq(t.leads.id, t.activities.leadId))
    .innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId))
    .leftJoin(t.users, eq(t.users.id, t.activities.assignedTo))
    .leftJoin(t.contacts, eq(t.contacts.id, t.leads.contactId))
    .where(where)
    .orderBy(tab === "completed" ? desc(t.activities.completedAt) : asc(t.activities.dueAt))
    .limit(200);

  const meetings = tab !== "meetings" ? [] : await db
    .select({ id: t.meetings.id, at: t.meetings.scheduledAt, location: t.meetings.location, mode: t.meetings.mode, agenda: t.meetings.agenda, leadId: t.leads.id, code: t.leads.leadCode, business: t.businesses.name })
    .from(t.meetings)
    .innerJoin(t.leads, eq(t.leads.id, t.meetings.leadId))
    .innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId))
    .where(and(gte(t.meetings.scheduledAt, new Date(Date.now() - 86400000)), eq(t.meetings.completed, false), mineOnly ? or(eq(t.leads.assignedTo, user.id), eq(t.meetings.createdBy, user.id)) : undefined))
    .orderBy(asc(t.meetings.scheduledAt));

  const q = (k: string) => `/admin/follow-ups?tab=${k}${sp.who ? `&who=${sp.who}` : ""}`;
  return (
    <div>
      <PageHeader title="Follow-ups" subtitle={mineOnly ? "Your follow-ups" : "All team follow-ups"} actions={viewAll ? <Link href={sp.who === "me" ? `/admin/follow-ups?tab=${tab}` : `/admin/follow-ups?tab=${tab}&who=me`} className="btn-outline btn-sm">{sp.who === "me" ? "Show whole team" : "Show only mine"}</Link> : undefined} />
      <Tabs current={tab} tabs={[
        { key: "upcoming", label: "Upcoming", href: q("upcoming"), count: counts[0] },
        { key: "overdue", label: "Overdue", href: q("overdue"), count: counts[1] },
        { key: "completed", label: "Completed", href: q("completed") },
        { key: "meetings", label: "Meetings", href: q("meetings") },
      ]} />
      {tab === "meetings" ? (
        meetings.length ? (
          <ul className="space-y-3">{meetings.map((m) => (
            <li key={m.id} className="card p-4"><Link href={`/admin/leads/${m.leadId}`} className="font-semibold text-navy hover:text-brand">{m.business}</Link><p className="text-sm text-ink-muted">{m.code} · {formatDateTime(m.at)} · {m.mode.replace("_", " ")}{m.location ? ` · ${m.location}` : ""}</p>{m.agenda && <p className="mt-1 text-sm text-ink-soft">{m.agenda}</p>}</li>
          ))}</ul>
        ) : <Empty>No upcoming meetings.</Empty>
      ) : items.length ? (
        <ul className="space-y-3">
          {items.map((i) => {
            const overdue = !i.done && i.due && i.due.getTime() < Date.now();
            return (
              <li key={i.id} className={`card p-4 ${overdue ? "border-red-200" : ""}`}>
                <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                  <div className="min-w-0">
                    <Link href={`/admin/leads/${i.leadId}`} className="font-semibold text-navy hover:text-brand">{i.business}</Link> <span className="text-xs text-ink-muted">{i.code}</span>
                    <p className="text-sm text-ink-soft">{i.title}</p>
                    {i.body && <p className="mt-1 whitespace-pre-line text-xs text-ink-muted">{i.body}</p>}
                    <p className={`mt-1 text-xs ${overdue ? "font-semibold text-red-600" : "text-ink-muted"}`}>{i.done ? `Completed ${formatDateTime(i.done)}` : `Due ${formatDateTime(i.due)} (${relativeDays(i.due)})`}{i.assignee && viewAll ? ` · ${i.assignee}` : ""}</p>
                  </div>
                  {!i.done && (
                    <div className="flex flex-col gap-2 md:w-80">
                      <div className="flex gap-2">
                        {i.phone && <a href={telLink(i.phone)!} className="btn-outline btn-sm flex-1"><Phone className="h-4 w-4" /> Call</a>}
                        {(i.whatsapp || i.phone) && <a href={whatsappLink(i.whatsapp || i.phone)!} target="_blank" rel="noopener noreferrer" className="btn-outline btn-sm flex-1"><MessageCircle className="h-4 w-4" /> WhatsApp</a>}
                      </div>
                      <ActionForm action={completeFollowUp} className="flex gap-2"><input type="hidden" name="activityId" value={i.id} /><input name="outcome" placeholder="Outcome" className="input-sm flex-1" /><SubmitButton className="btn-accent btn-sm"><CheckCircle2 className="h-4 w-4" /> Done</SubmitButton></ActionForm>
                    </div>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      ) : <Empty>{tab === "overdue" ? "Nothing overdue — well done." : tab === "completed" ? "No completed follow-ups yet." : "No upcoming follow-ups."}</Empty>}
    </div>
  );
}
