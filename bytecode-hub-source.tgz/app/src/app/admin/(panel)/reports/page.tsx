import type { Metadata } from "next";
import { desc } from "drizzle-orm";
import { Download, Info } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { dashboardStats, funnelStats, campaignComparison, teamPerformance, lostReasons, type ReportFilters } from "@/lib/stats";
import { PageHeader, Section, Stat } from "@/components/admin/server-ui";
import { HBarChart, FunnelChart, ColumnChart } from "@/components/admin/charts";
import { formatNpr, pct } from "@/lib/format";

export const metadata: Metadata = { title: "Reports" };

export default async function ReportsPage({ searchParams }: { searchParams: Promise<ReportFilters> }) {
  const user = await requirePagePermission("viewReports");
  const f = await searchParams;
  const [stats, funnel, campaigns, team, lost, allCampaigns, users] = await Promise.all([
    dashboardStats(user, f), funnelStats(user, f), campaignComparison(user), teamPerformance(user, f), lostReasons(user, f),
    db.select({ id: t.campaigns.id, name: t.campaigns.name }).from(t.campaigns).orderBy(desc(t.campaigns.isDefault)),
    db.select({ id: t.users.id, name: t.users.name }).from(t.users),
  ]);
  const total = stats.totals.total;
  const reached = (slug: string) => funnel.find((r) => r.name.toLowerCase().replace(/\s+/g, "-") === slug)?.reached ?? 0;
  const won = funnel.find((r) => r.is_won)?.current ?? 0;
  const lostN = funnel.find((r) => r.is_lost)?.current ?? 0;
  const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v) as [string, string][]).toString();

  return (
    <div>
      <PageHeader
        title="Campaign reports"
        subtitle="All figures are calculated from recorded leads. Monetary values are estimates entered by the team."
        actions={<a href={`/api/leads/export?format=xlsx&${qs}`} className="btn-outline btn-sm"><Download className="h-4 w-4" /> Export leads (Excel)</a>}
      />
      <form className="card mb-5 grid grid-cols-2 gap-3 p-4 md:grid-cols-5">
        <label className="text-xs font-medium text-ink-muted">Campaign<select name="campaign" defaultValue={f.campaign ?? ""} className="input-sm mt-1"><option value="">All campaigns</option>{allCampaigns.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
        <label className="text-xs font-medium text-ink-muted">Team member<select name="assigned" defaultValue={f.assigned ?? ""} className="input-sm mt-1"><option value="">Everyone</option>{users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select></label>
        <label className="text-xs font-medium text-ink-muted">From<input type="date" name="from" defaultValue={f.from} className="input-sm mt-1" /></label>
        <label className="text-xs font-medium text-ink-muted">To<input type="date" name="to" defaultValue={f.to} className="input-sm mt-1" /></label>
        <div className="flex items-end gap-2"><button className="btn-primary btn-sm">Apply</button><a href="/admin/reports" className="btn-ghost btn-sm">Reset</a></div>
      </form>

      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-muted">Recorded results</p>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <Stat label="Total prospects" value={total} />
        <Stat label="Meetings held / booked" value={reached("meeting-scheduled")} hint="Leads that reached this stage" />
        <Stat label="Qualified" value={reached("qualified")} hint={`${pct(reached("qualified"), total)} of prospects`} />
        <Stat label="Proposals sent" value={reached("proposal-sent")} hint={`${pct(reached("proposal-sent"), total)} of prospects`} />
        <Stat label="Won" value={won} tone="good" hint={`Conversion ${pct(won, total)}`} />
        <Stat label="Lost" value={lostN} tone={lostN ? "bad" : "default"} hint={`Win rate (closed) ${pct(won, won + lostN)}`} />
      </div>

      <p className="mb-2 mt-6 flex items-center gap-1 text-xs font-semibold uppercase tracking-wide text-ink-muted"><Info className="h-3.5 w-3.5" /> Estimates (manually entered by the team)</p>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Open pipeline (est.)" value={formatNpr(stats.totals.openValue)} />
        <Stat label="Won value (est.)" value={formatNpr(stats.totals.wonValue)} />
      </div>

      <div className="mt-6 grid gap-5 xl:grid-cols-2">
        <Section title="Pipeline funnel (furthest stage reached)"><FunnelChart rows={funnel} /><p className="mt-3 text-xs text-ink-muted">Percentages show conversion from the previous stage.</p></Section>
        <Section title="New prospects per week"><ColumnChart data={stats.weekly} /></Section>
        <Section title="Leads by campaign source"><HBarChart data={stats.bySource} /></Section>
        <Section title="Leads by industry"><HBarChart data={stats.byIndustry} /></Section>
        <Section title="Service interest"><HBarChart data={stats.byService} /></Section>
        <Section title="Reasons for lost deals"><HBarChart data={lost} empty="No lost deals recorded." /></Section>
      </div>

      <div className="mt-5 grid gap-5">
        <Section title="Campaign comparison">
          <div className="table-wrap border-0">
            <table className="table">
              <thead><tr><th>Campaign</th><th className="text-right">Leads</th><th className="text-right">Qualified</th><th className="text-right">Won</th><th className="text-right">Lost</th><th className="text-right">Conv.</th><th className="text-right">Est. value</th></tr></thead>
              <tbody>{campaigns.map((c) => (
                <tr key={c.id ?? "none"}><td className="font-medium">{c.name}</td><td className="text-right tabular-nums">{c.total}</td><td className="text-right tabular-nums">{c.qualified}</td><td className="text-right tabular-nums">{c.won}</td><td className="text-right tabular-nums">{c.lost}</td><td className="text-right tabular-nums">{pct(Number(c.won), Number(c.total))}</td><td className="text-right tabular-nums">{formatNpr(c.est_value ?? 0)}</td></tr>
              ))}</tbody>
            </table>
          </div>
        </Section>
        <Section title="Team performance">
          <div className="table-wrap border-0">
            <table className="table">
              <thead><tr><th>Team member</th><th className="text-right">Leads</th><th className="text-right">Won</th><th className="text-right">Overdue</th><th className="text-right">Activities (30d)</th></tr></thead>
              <tbody>{team.map((r) => <tr key={r.name}><td className="font-medium">{r.name}</td><td className="text-right tabular-nums">{r.total}</td><td className="text-right tabular-nums">{r.won}</td><td className={`text-right tabular-nums ${Number(r.overdue) ? "text-red-600" : ""}`}>{r.overdue}</td><td className="text-right tabular-nums">{r.activities}</td></tr>)}</tbody>
            </table>
          </div>
        </Section>
      </div>
    </div>
  );
}
