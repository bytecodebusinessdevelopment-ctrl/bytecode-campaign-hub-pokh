import type { Metadata } from "next";
import Link from "next/link";
import { asc, desc, eq, inArray, and } from "drizzle-orm";
import { ExternalLink, MessageCircle, Download, Globe, Rocket, Figma, Search } from "lucide-react";
import { db, t } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { getPublishedServices, getPublishedProjects } from "@/lib/public-data";
import { Section, PageHeader } from "@/components/admin/server-ui";
import { ClassificationBadge, fileTypeLabel } from "@/components/public/cards";
import { siteUrl } from "@/lib/request";
import { DEMO_TYPE_LABELS } from "@/lib/enquiry-config";

export const metadata: Metadata = { title: "Presenter kit" };

const share = (text: string, url: string) => `https://wa.me/?text=${encodeURIComponent(`${text}\n${url}`)}`;

/** Everything the BD team needs during a meeting: services, live work, demos and documents — one tap away. */
export default async function PresentPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  await requireUser();
  const { q } = await searchParams;
  const needle = q?.toLowerCase().trim();
  const match = (...s: (string | null | undefined)[]) => !needle || s.some((x) => x?.toLowerCase().includes(needle));
  const [services, projects, demos, resources] = await Promise.all([
    getPublishedServices(),
    getPublishedProjects(),
    db.query.demos.findMany({ where: inArray(t.demos.visibility, ["public", "private", "internal"]), with: { industry: true }, orderBy: [desc(t.demos.featured), asc(t.demos.sortOrder)] }),
    db.query.resources.findMany({ where: and(eq(t.resources.published, true), inArray(t.resources.visibility, ["public", "internal"])), with: { category: true, file: true }, orderBy: [desc(t.resources.featured), asc(t.resources.sortOrder)] }),
  ]);
  const P = projects.filter((p) => match(p.title, p.summary, p.industry?.name));
  const D = demos.filter((d) => match(d.title, d.description, d.industry?.name));
  const R = resources.filter((r) => match(r.title, r.description, r.category?.name));
  const S = services.filter((s) => match(s.name, s.summary));

  return (
    <div>
      <PageHeader title="Presenter kit" subtitle="Open live work and share documents with prospects during visits." />
      <form className="mb-5 flex gap-2"><label className="relative flex-1"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" /><input name="q" defaultValue={q} placeholder="Search e.g. travel, hotel, SEO…" className="input pl-9" /></label><button className="btn-primary">Search</button></form>

      <div className="space-y-5">
        <Section title={`Live demos & UI/UX (${D.length})`}>
          {D.length ? (
            <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {D.map((d) => {
                const I = d.demoType === "figma" ? Figma : d.demoType === "vercel" ? Rocket : Globe;
                return (
                  <li key={d.id} className="rounded-2xl border border-line p-4">
                    <div className="flex items-start gap-3"><I className="mt-0.5 h-5 w-5 shrink-0 text-brand" /><div className="min-w-0"><p className="font-semibold text-navy">{d.title}</p><p className="text-xs text-ink-muted">{DEMO_TYPE_LABELS[d.demoType]}{d.industry ? ` · ${d.industry.name}` : ""}{d.visibility !== "public" ? " · internal only" : ""}</p><ClassificationBadge value={d.classification} className="mt-1" /></div></div>
                    <div className="mt-3 flex gap-2">
                      <a href={d.url} target="_blank" rel="noopener noreferrer" className="btn-primary btn-sm flex-1">Open <ExternalLink className="h-3.5 w-3.5" /></a>
                      {d.visibility === "public" && <a href={share(d.title, d.url)} target="_blank" rel="noopener noreferrer" className="btn-outline btn-sm" aria-label="Share on WhatsApp"><MessageCircle className="h-4 w-4" /></a>}
                    </div>
                  </li>
                );
              })}
            </ul>
          ) : <p className="text-sm text-ink-muted">No demos added yet. Add them in Demos & UI/UX.</p>}
        </Section>

        <Section title={`Portfolio projects (${P.length})`}>
          {P.length ? (
            <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {P.map((p) => (
                <li key={p.id} className="rounded-2xl border border-line p-4">
                  <p className="font-semibold text-navy">{p.title}</p>
                  <p className="text-xs text-ink-muted">{[p.industry?.name, p.projectType?.name].filter(Boolean).join(" · ")}</p>
                  <div className="mt-3 flex gap-2">
                    {p.liveUrl && <a href={p.liveUrl} target="_blank" rel="noopener noreferrer" className="btn-primary btn-sm flex-1">Live site <ExternalLink className="h-3.5 w-3.5" /></a>}
                    <Link href={`/portfolio/${p.slug}`} target="_blank" className="btn-outline btn-sm flex-1">Case study</Link>
                    <a href={share(p.title, siteUrl(`/portfolio/${p.slug}`))} target="_blank" rel="noopener noreferrer" className="btn-outline btn-sm" aria-label="Share on WhatsApp"><MessageCircle className="h-4 w-4" /></a>
                  </div>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-ink-muted">No published projects yet. Draft projects imported from the current website are waiting for details in Portfolio.</p>}
        </Section>

        <Section title={`Documents & resources (${R.length})`}>
          {R.length ? (
            <ul className="divide-y divide-line">
              {R.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                  <div className="min-w-0"><p className="font-semibold text-navy">{r.title}</p><p className="text-xs text-ink-muted">{[r.category?.name, fileTypeLabel(r.file?.mimeType, r.kind)].filter(Boolean).join(" · ")}{r.visibility === "internal" ? " · Internal only — do not share" : ""}</p></div>
                  <div className="flex gap-2">
                    {r.fileId ? <a href={`/api/files/${r.fileId}`} target="_blank" rel="noreferrer" className="btn-outline btn-sm"><Download className="h-4 w-4" /> Open</a> : r.url ? <a href={r.url} target="_blank" rel="noopener noreferrer" className="btn-outline btn-sm">Open <ExternalLink className="h-3.5 w-3.5" /></a> : null}
                    {r.visibility === "public" && <a href={share(r.title, siteUrl(`/resources/${r.slug}`))} target="_blank" rel="noopener noreferrer" className="btn-outline btn-sm"><MessageCircle className="h-4 w-4" /> Share</a>}
                  </div>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-ink-muted">No published resources yet.</p>}
        </Section>

        <Section title="Services">
          <ul className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {S.map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-2 rounded-xl border border-line p-3">
                <Link href={`/services/${s.slug}`} target="_blank" className="text-sm font-semibold text-navy hover:text-brand">{s.name}</Link>
                <a href={share(s.name, siteUrl(`/services/${s.slug}`))} target="_blank" rel="noopener noreferrer" className="text-brand" aria-label={`Share ${s.name} on WhatsApp`}><MessageCircle className="h-4 w-4" /></a>
              </li>
            ))}
          </ul>
          <a href={share("Request a proposal from ByteCode Developers", siteUrl("/request-proposal"))} target="_blank" rel="noopener noreferrer" className="btn-accent btn-sm mt-4"><MessageCircle className="h-4 w-4" /> Send the enquiry form link</a>
        </Section>
      </div>
    </div>
  );
}
