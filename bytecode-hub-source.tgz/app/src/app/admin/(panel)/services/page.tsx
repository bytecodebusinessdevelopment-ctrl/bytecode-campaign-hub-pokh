import type { Metadata } from "next";
import Link from "next/link";
import { asc, sql } from "drizzle-orm";
import { Plus } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader } from "@/components/admin/server-ui";
import { Icon } from "@/components/icon";

export const metadata: Metadata = { title: "Services & packages" };

export default async function AdminServices() {
  await requirePagePermission("managePricing");
  const rows = await db.select({
    s: t.services,
    pkgs: sql<number>`(SELECT count(*)::int FROM packages p WHERE p.service_id = ${t.services.id})`,
    live: sql<number>`(SELECT count(*)::int FROM packages p WHERE p.service_id = ${t.services.id} AND p.published)`,
    placeholders: sql<number>`(SELECT count(*)::int FROM packages p WHERE p.service_id = ${t.services.id} AND p.is_placeholder)`,
  }).from(t.services).orderBy(asc(t.services.sortOrder));
  return (
    <div>
      <PageHeader title="Services & packages" subtitle="Each service has its own public page. Packages appear only when published and not marked as placeholders." actions={<Link href="/admin/services/new" className="btn-primary btn-sm"><Plus className="h-4 w-4" /> New service</Link>} />
      <div className="grid gap-4 md:grid-cols-2">
        {rows.map(({ s, pkgs, live, placeholders }) => (
          <Link key={s.id} href={`/admin/services/${s.id}`} className="card flex gap-4 p-5 hover:shadow-lift">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand"><Icon name={s.icon} className="h-5 w-5" /></span>
            <div className="min-w-0">
              <p className="font-bold text-navy">{s.name} {!s.published && <span className="badge ml-1 bg-slate-100 text-slate-600">Hidden</span>}</p>
              <p className="line-clamp-1 text-sm text-ink-muted">{s.summary}</p>
              <p className="mt-2 text-xs text-ink-soft">{pkgs} package{pkgs === 1 ? "" : "s"} · {live} published{Number(placeholders) ? <span className="text-amber-700"> · {placeholders} placeholder{Number(placeholders) > 1 ? "s" : ""} awaiting details</span> : null}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
