import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { Trash2 } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { savePackage, deletePackage } from "../../../actions";

export const metadata: Metadata = { title: "Edit package" };

export default async function EditPackage({ params, searchParams }: { params: Promise<{ id: string; pkgId: string }>; searchParams: Promise<{ saved?: string }> }) {
  await requirePagePermission("managePricing");
  const { id, pkgId } = await params;
  const sp = await searchParams;
  const [service] = await db.select().from(t.services).where(eq(t.services.id, id));
  if (!service) notFound();
  const isNew = pkgId === "new";
  const p = isNew ? null : (await db.select().from(t.packages).where(eq(t.packages.id, pkgId)))[0];
  if (!isNew && !p) notFound();
  return (
    <div className="mx-auto max-w-4xl">
      {sp.saved && <p className="mb-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">Package created.</p>}
      <PageHeader title={isNew ? "New package" : p!.name} subtitle={service.name} back={{ href: `/admin/services/${service.id}`, label: service.name }} />
      {p?.isPlaceholder && <p className="placeholder-note mb-5">This is a placeholder. Replace the description, price, deliverables and exclusions with ByteCode-approved content, untick &ldquo;placeholder&rdquo;, then publish.</p>}
      <ActionForm action={savePackage} className="space-y-5">
        {p && <input type="hidden" name="id" value={p.id} />}
        <input type="hidden" name="serviceId" value={service.id} />
        <Section title="Package">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Package name *"><input name="name" required defaultValue={p?.name} className="input" /></L>
            <L label="Target audience"><input name="targetAudience" defaultValue={p?.targetAudience ?? ""} className="input" /></L>
            <L label="Description" className="sm:col-span-2"><textarea name="description" rows={3} defaultValue={p?.description ?? ""} className="input" /></L>
            <L label="Price type"><select name="priceType" defaultValue={p?.priceType ?? "tbc"} className="input"><option value="fixed">Fixed price</option><option value="starting">Starting from</option><option value="monthly">Monthly</option><option value="custom">Custom quotation</option><option value="tbc">To be confirmed (shows &ldquo;Price on request&rdquo;)</option></select></L>
            <L label="Price (NPR)"><input name="priceNpr" inputMode="numeric" defaultValue={p?.priceNpr ?? ""} placeholder="e.g. 45000" className="input" /></L>
            <L label="Price note" hint="e.g. excl. VAT, billed quarterly"><input name="priceNote" defaultValue={p?.priceNote ?? ""} className="input" /></L>
            <L label="Estimated delivery period"><input name="deliveryPeriod" defaultValue={p?.deliveryPeriod ?? ""} placeholder="e.g. 3–4 weeks" className="input" /></L>
          </div>
        </Section>
        <Section title="Scope (one item per line)">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Deliverables"><textarea name="deliverables" rows={6} defaultValue={p?.deliverables.join("\n")} className="input" /></L>
            <L label="Features"><textarea name="features" rows={6} defaultValue={p?.features.join("\n")} className="input" /></L>
            <L label="Exclusions"><textarea name="exclusions" rows={5} defaultValue={p?.exclusions.join("\n")} className="input" /></L>
            <L label="Optional add-ons"><textarea name="addOns" rows={5} defaultValue={p?.addOns.join("\n")} className="input" /></L>
            <L label="Requirements (e.g. website requirements for SEO)" className="sm:col-span-2"><textarea name="requirements" rows={2} defaultValue={p?.requirements ?? ""} className="input" /></L>
          </div>
        </Section>
        <Section title="Publishing">
          <div className="grid gap-4 sm:grid-cols-4">
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="isPlaceholder" defaultChecked={p?.isPlaceholder ?? true} className="check" /> Placeholder</label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="published" defaultChecked={p?.published} className="check" /> Published</label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="featured" defaultChecked={p?.featured} className="check" /> Featured</label>
            <L label="Order"><input name="sortOrder" defaultValue={p?.sortOrder ?? 0} className="input" /></L>
          </div>
        </Section>
        <div className="flex justify-end"><SubmitButton>Save package</SubmitButton></div>
      </ActionForm>
      {p && <Section title="Delete" className="mt-5"><ActionForm action={deletePackage} refresh={false}><input type="hidden" name="id" value={p.id} /><input type="hidden" name="serviceId" value={service.id} /><SubmitButton className="btn-danger btn-sm" confirm="Delete this package?"><Trash2 className="h-4 w-4" /> Delete package</SubmitButton></ActionForm></Section>}
    </div>
  );
}

function L({ label, hint, children, className }: { label: string; hint?: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className ?? ""}`}><span className="label">{label}</span>{children}{hint && <span className="hint block">{hint}</span>}</label>;
}
