import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { ExternalLink, Plus } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { ICON_NAMES } from "@/components/icon";
import { priceLabel } from "@/components/public/home-view";
import { saveService } from "../actions";

export const metadata: Metadata = { title: "Edit service" };

export default async function EditService({ params }: { params: Promise<{ id: string }> }) {
  await requirePagePermission("managePricing");
  const { id } = await params;
  const isNew = id === "new";
  const s = isNew ? null : (await db.select().from(t.services).where(eq(t.services.id, id)))[0];
  if (!isNew && !s) notFound();
  const pkgs = s ? await db.select().from(t.packages).where(eq(t.packages.serviceId, s.id)).orderBy(asc(t.packages.sortOrder)) : [];
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title={isNew ? "New service" : s!.name} back={{ href: "/admin/services", label: "Services & packages" }} actions={s?.published ? <Link href={`/services/${s.slug}`} target="_blank" className="btn-outline btn-sm">View page <ExternalLink className="h-4 w-4" /></Link> : undefined} />
      {s && (
        <Section title="Packages" className="mb-5" actions={<Link href={`/admin/services/${s.id}/packages/new`} className="btn-primary btn-sm"><Plus className="h-4 w-4" /> Add package</Link>}>
          {pkgs.length ? (
            <ul className="divide-y divide-line">
              {pkgs.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 py-3">
                  <Link href={`/admin/services/${s.id}/packages/${p.id}`} className="font-semibold text-navy hover:text-brand">{p.name}</Link>
                  <span className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="text-ink-soft">{priceLabel(p)}</span>
                    {p.isPlaceholder && <span className="badge bg-amber-100 text-amber-800">Placeholder</span>}
                    {p.published ? <span className="badge bg-emerald-100 text-emerald-700">Published</span> : <span className="badge bg-slate-100 text-slate-600">Draft</span>}
                  </span>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-ink-muted">No packages — the page shows &ldquo;Custom quotation&rdquo; with the pricing note below.</p>}
        </Section>
      )}
      <ActionForm action={saveService} className="space-y-5">
        {s && <input type="hidden" name="id" value={s.id} />}
        <Section title="Service page">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Name *"><input name="name" required defaultValue={s?.name} className="input" /></L>
            <L label="URL slug"><input name="slug" defaultValue={s?.slug} className="input" /></L>
            <L label="Group"><select name="groupKey" defaultValue={s?.groupKey ?? "development"} className="input"><option value="development">Website & Software Development</option><option value="growth">SEO & Digital Growth</option><option value="creative">Content & Creative</option><option value="consulting">Automation & Consulting</option></select></L>
            <L label="Icon"><select name="icon" defaultValue={s?.icon ?? "sparkles"} className="input">{ICON_NAMES.map((n) => <option key={n}>{n}</option>)}</select></L>
            <L label="Tagline" className="sm:col-span-2"><input name="tagline" defaultValue={s?.tagline ?? ""} className="input" /></L>
            <L label="Card summary" className="sm:col-span-2"><textarea name="summary" rows={2} defaultValue={s?.summary ?? ""} className="input" /></L>
            <L label="Overview" className="sm:col-span-2"><textarea name="description" rows={5} defaultValue={s?.description ?? ""} className="input" /></L>
            <L label="What we offer" hint="One per line"><textarea name="offerings" rows={8} defaultValue={s?.offerings.join("\n")} className="input" /></L>
            <L label="Extra sections" hint="Start each with '## Title' on its own line"><textarea name="sections" rows={8} defaultValue={s?.sections.map((x) => `## ${x.title}\n${x.body}`).join("\n\n")} className="input" /></L>
            <L label="Pricing note (shown when no packages are published)" className="sm:col-span-2"><textarea name="pricingNote" rows={2} defaultValue={s?.pricingNote ?? ""} className="input" /></L>
          </div>
        </Section>
        <Section title="SEO & publishing">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="SEO title"><input name="seoTitle" defaultValue={s?.seoTitle ?? ""} className="input" /></L>
            <L label="Display order"><input name="sortOrder" defaultValue={s?.sortOrder ?? 0} className="input" /></L>
            <L label="SEO description" className="sm:col-span-2"><textarea name="seoDescription" rows={2} defaultValue={s?.seoDescription ?? ""} className="input" /></L>
            <label className="flex items-center gap-3 text-sm"><input type="checkbox" name="published" defaultChecked={s?.published ?? true} className="check" /> Published</label>
          </div>
        </Section>
        <div className="flex justify-end"><SubmitButton>Save service</SubmitButton></div>
      </ActionForm>
    </div>
  );
}

function L({ label, hint, children, className }: { label: string; hint?: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className ?? ""}`}><span className="label">{label}</span>{children}{hint && <span className="hint block">{hint}</span>}</label>;
}
