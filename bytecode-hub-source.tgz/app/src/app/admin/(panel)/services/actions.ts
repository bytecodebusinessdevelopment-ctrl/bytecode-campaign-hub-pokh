"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { and, eq, ne } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { safeAction } from "@/lib/action";
import { requirePermission } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { bool, int, lines, slugify, str } from "@/lib/utils";

function parseSections(raw: string | null) {
  // Format: "## Title" line followed by body text, repeated.
  if (!raw) return [];
  return raw.split(/^##\s+/m).map((b) => b.trim()).filter(Boolean).map((b) => {
    const [title, ...rest] = b.split("\n");
    return { title: title.trim(), body: rest.join("\n").trim() };
  });
}

export const saveService = safeAction(async (fd) => {
  const user = await requirePermission("managePricing");
  const id = str(fd.get("id"));
  const name = str(fd.get("name"));
  if (!name) throw new Error("Name is required.");
  const slug = slugify(str(fd.get("slug")) ?? name);
  const [clash] = await db.select({ id: t.services.id }).from(t.services).where(id ? and(eq(t.services.slug, slug), ne(t.services.id, id)) : eq(t.services.slug, slug));
  if (clash) throw new Error("Another service already uses that URL slug.");
  const values = {
    name, slug, groupKey: str(fd.get("groupKey")) ?? "development", icon: str(fd.get("icon")) ?? "sparkles", tagline: str(fd.get("tagline")),
    summary: str(fd.get("summary")), description: str(fd.get("description")), offerings: lines(fd.get("offerings")), sections: parseSections(str(fd.get("sections"))),
    pricingNote: str(fd.get("pricingNote")), sortOrder: int(fd.get("sortOrder")) ?? 0, published: bool(fd.get("published")),
    seoTitle: str(fd.get("seoTitle")), seoDescription: str(fd.get("seoDescription")), updatedAt: new Date(),
  };
  let sid = id;
  if (id) await db.update(t.services).set(values).where(eq(t.services.id, id));
  else sid = (await db.insert(t.services).values(values).returning({ id: t.services.id }))[0].id;
  await audit(user.id, id ? "update" : "create", "service", sid, { name });
  revalidatePath("/", "layout");
  if (!id) redirect(`/admin/services/${sid}`);
  return { ok: true, message: "Service saved." };
});

export const savePackage = safeAction(async (fd) => {
  const user = await requirePermission("managePricing");
  const id = str(fd.get("id"));
  const serviceId = String(fd.get("serviceId"));
  const name = str(fd.get("name"));
  if (!name) throw new Error("Name is required.");
  const priceType = String(fd.get("priceType")) as "fixed" | "starting" | "monthly" | "custom" | "tbc";
  const priceNpr = int(fd.get("priceNpr"));
  const published = bool(fd.get("published"));
  const isPlaceholder = bool(fd.get("isPlaceholder"));
  if (["fixed", "starting", "monthly"].includes(priceType) && !priceNpr) throw new Error("Enter the price in NPR, or choose 'Custom quotation' / 'To be confirmed'.");
  if (published && isPlaceholder) throw new Error("This package is marked as a placeholder. Untick 'placeholder' once ByteCode has approved the content, then publish.");
  const values = {
    serviceId, name, slug: slugify(str(fd.get("slug")) ?? name), description: str(fd.get("description")), targetAudience: str(fd.get("targetAudience")),
    priceType, priceNpr, priceNote: str(fd.get("priceNote")), deliverables: lines(fd.get("deliverables")), features: lines(fd.get("features")),
    exclusions: lines(fd.get("exclusions")), addOns: lines(fd.get("addOns")), deliveryPeriod: str(fd.get("deliveryPeriod")), requirements: str(fd.get("requirements")),
    featured: bool(fd.get("featured")), isPlaceholder, published, sortOrder: int(fd.get("sortOrder")) ?? 0, updatedAt: new Date(),
  };
  let pid = id;
  if (id) await db.update(t.packages).set(values).where(eq(t.packages.id, id));
  else pid = (await db.insert(t.packages).values(values).returning({ id: t.packages.id }))[0].id;
  await audit(user.id, id ? "update" : "create", "package", pid, { name, priceType, priceNpr, published });
  revalidatePath("/packages");
  revalidatePath("/", "layout");
  if (!id) redirect(`/admin/services/${serviceId}/packages/${pid}?saved=1`);
  return { ok: true, message: "Package saved." };
});

export const deletePackage = safeAction(async (fd) => {
  const user = await requirePermission("managePricing");
  const id = String(fd.get("id"));
  const serviceId = String(fd.get("serviceId"));
  await db.delete(t.packages).where(eq(t.packages.id, id));
  await audit(user.id, "delete", "package", id);
  revalidatePath("/packages");
  redirect(`/admin/services/${serviceId}`);
});
