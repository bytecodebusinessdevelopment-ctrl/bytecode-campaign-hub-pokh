"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { and, eq, ne } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { safeAction } from "@/lib/action";
import { requirePermission } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { bool, slugify, str } from "@/lib/utils";

export const saveCampaign = safeAction(async (fd) => {
  const user = await requirePermission("manageCampaigns");
  const id = str(fd.get("id"));
  const name = str(fd.get("name"));
  if (!name) throw new Error("Campaign name is required.");
  const slug = slugify(str(fd.get("slug")) ?? name);
  const [clash] = await db.select({ id: t.campaigns.id }).from(t.campaigns).where(id ? and(eq(t.campaigns.slug, slug), ne(t.campaigns.id, id)) : eq(t.campaigns.slug, slug));
  if (clash) throw new Error("Another campaign already uses that URL slug.");
  const prefix = (str(fd.get("leadIdPrefix")) ?? "BC").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);
  if (!prefix) throw new Error("Lead ID prefix must contain letters or numbers.");
  const sheetRaw = str(fd.get("sheetId"));
  // Accept either the spreadsheet ID or its full URL.
  const sheetId = sheetRaw ? (/\/d\/([a-zA-Z0-9-_]+)/.exec(sheetRaw)?.[1] ?? sheetRaw) : null;
  const isDefault = bool(fd.get("isDefault"));
  const values = {
    name, slug, location: str(fd.get("location")), leadIdPrefix: prefix, startDate: str(fd.get("startDate")), endDate: str(fd.get("endDate")),
    status: (str(fd.get("status")) ?? "draft") as "draft" | "active" | "completed" | "archived", isDefault,
    heroTitle: str(fd.get("heroTitle")), heroSubtitle: str(fd.get("heroSubtitle")), landingIntro: str(fd.get("landingIntro")),
    sheetId, sheetTab: str(fd.get("sheetTab")) ?? "Leads", updatedAt: new Date(),
  };
  let cid = id;
  await db.transaction(async (tx) => {
    if (isDefault) await tx.update(t.campaigns).set({ isDefault: false });
    if (id) await tx.update(t.campaigns).set(values).where(eq(t.campaigns.id, id));
    else cid = (await tx.insert(t.campaigns).values(values).returning({ id: t.campaigns.id }))[0].id;
  });
  await audit(user.id, id ? "update" : "create", "campaign", cid, { name, status: values.status });
  revalidatePath("/", "layout");
  if (!id) redirect(`/admin/campaigns/${cid}?saved=1`);
  return { ok: true, message: "Campaign saved." };
});
