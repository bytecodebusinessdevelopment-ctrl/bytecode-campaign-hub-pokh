import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { saveCampaign } from "../actions";

export const metadata: Metadata = { title: "Edit campaign" };

export default async function EditCampaign({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ saved?: string }> }) {
  await requirePagePermission("manageCampaigns");
  const { id } = await params;
  const sp = await searchParams;
  const isNew = id === "new";
  const c = isNew ? null : (await db.select().from(t.campaigns).where(eq(t.campaigns.id, id)))[0];
  if (!isNew && !c) notFound();
  const sources = c ? await db.select().from(t.leadSources).where(eq(t.leadSources.campaignId, c.id)) : [];
  return (
    <div className="mx-auto max-w-4xl">
      {sp.saved && <p className="mb-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">Campaign created. Add a campaign-specific lead source (e.g. &ldquo;Kathmandu physical visit&rdquo;) in Lists & options.</p>}
      <PageHeader title={isNew ? "New campaign" : c!.name} back={{ href: "/admin/campaigns", label: "Campaigns" }} />
      <ActionForm action={saveCampaign} className="space-y-5">
        {c && <input type="hidden" name="id" value={c.id} />}
        <Section title="Campaign">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Campaign name *"><input name="name" required defaultValue={c?.name} className="input" /></L>
            <L label="Location"><input name="location" defaultValue={c?.location ?? ""} placeholder="e.g. Chitwan, Bagmati Province" className="input" /></L>
            <L label="Landing page slug" hint="Landing page at /c/<slug>"><input name="slug" defaultValue={c?.slug} className="input" /></L>
            <L label="Lead ID prefix" hint="e.g. POK → POK-2026-0001"><input name="leadIdPrefix" defaultValue={c?.leadIdPrefix ?? ""} maxLength={6} className="input uppercase" /></L>
            <L label="Start date"><input type="date" name="startDate" defaultValue={c?.startDate ?? ""} className="input" /></L>
            <L label="End date"><input type="date" name="endDate" defaultValue={c?.endDate ?? ""} className="input" /></L>
            <L label="Status"><select name="status" defaultValue={c?.status ?? "draft"} className="input"><option value="draft">Draft</option><option value="active">Active</option><option value="completed">Completed</option><option value="archived">Archived</option></select></L>
            <label className="flex items-center gap-3 self-end pb-3 text-sm"><input type="checkbox" name="isDefault" defaultChecked={c?.isDefault} className="check" /> Default campaign for new leads</label>
          </div>
        </Section>
        <Section title="Landing page content">
          <div className="grid gap-4">
            <L label="Hero headline"><input name="heroTitle" defaultValue={c?.heroTitle ?? ""} className="input" /></L>
            <L label="Hero supporting text"><textarea name="heroSubtitle" rows={2} defaultValue={c?.heroSubtitle ?? ""} className="input" /></L>
            <L label="Campaign introduction"><textarea name="landingIntro" rows={3} defaultValue={c?.landingIntro ?? ""} className="input" /></L>
          </div>
          <p className="mt-3 text-sm text-ink-muted">Add documents to this campaign&apos;s resource collection from each resource&apos;s editor.{c && <> Preview: <Link href={`/c/${c.slug}`} target="_blank" className="text-brand underline">/c/{c.slug}</Link></>}</p>
        </Section>
        <Section title="Google Sheets">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Campaign lead sheet (URL or ID)" hint="Share the sheet with the service-account email as Editor"><input name="sheetId" defaultValue={c?.sheetId ?? ""} className="input" /></L>
            <L label="Tab name"><input name="sheetTab" defaultValue={c?.sheetTab ?? "Leads"} className="input" /></L>
          </div>
        </Section>
        {c && (
          <Section title="Campaign-specific lead sources">
            {sources.length ? <ul className="text-sm">{sources.map((s) => <li key={s.id}>• {s.name}</li>)}</ul> : <p className="text-sm text-ink-muted">None — add one in Lists & options → Lead sources.</p>}
          </Section>
        )}
        <div className="flex justify-end"><SubmitButton>Save campaign</SubmitButton></div>
      </ActionForm>
    </div>
  );
}

function L({ label, hint, children, className }: { label: string; hint?: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className ?? ""}`}><span className="label">{label}</span>{children}{hint && <span className="hint block">{hint}</span>}</label>;
}
