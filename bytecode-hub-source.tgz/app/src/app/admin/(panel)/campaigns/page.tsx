import type { Metadata } from "next";
import Link from "next/link";
import { desc, sql } from "drizzle-orm";
import { Plus, ExternalLink } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader } from "@/components/admin/server-ui";
import { formatDate } from "@/lib/format";

export const metadata: Metadata = { title: "Campaigns" };

export default async function CampaignsPage() {
  await requirePagePermission("manageCampaigns");
  const rows = await db.select({ c: t.campaigns, leads: sql<number>`(SELECT count(*)::int FROM leads l WHERE l.campaign_id = ${t.campaigns.id} AND l.merged_into IS NULL)` }).from(t.campaigns).orderBy(desc(t.campaigns.isDefault), desc(t.campaigns.createdAt));
  return (
    <div>
      <PageHeader title="Campaigns" subtitle="Reuse the platform for Pokhara, Kathmandu, Chitwan or any future campaign — each with its own landing page, Lead ID prefix, sources, sheet and reports." actions={<Link href="/admin/campaigns/new" className="btn-primary btn-sm"><Plus className="h-4 w-4" /> New campaign</Link>} />
      <div className="grid gap-4 md:grid-cols-2">
        {rows.map(({ c, leads }) => (
          <div key={c.id} className="card p-5">
            <div className="flex items-start justify-between gap-3">
              <div><Link href={`/admin/campaigns/${c.id}`} className="text-lg font-bold text-navy hover:text-brand">{c.name}</Link><p className="text-sm text-ink-muted">{c.location ?? "—"} · Prefix {c.leadIdPrefix}</p></div>
              <div className="flex flex-col items-end gap-1"><span className={`badge ${c.status === "active" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>{c.status}</span>{c.isDefault && <span className="badge bg-brand/10 text-brand">Default</span>}</div>
            </div>
            <p className="mt-3 text-sm text-ink-soft">{leads} lead{leads === 1 ? "" : "s"} · {c.startDate ? `${formatDate(c.startDate)} – ${c.endDate ? formatDate(c.endDate) : "ongoing"}` : "Dates not set"} · {c.sheetId ? "Google Sheet linked" : "No sheet linked"}</p>
            <div className="mt-4 flex gap-2"><Link href={`/admin/reports?campaign=${c.id}`} className="btn-outline btn-sm">Report</Link><Link href={`/c/${c.slug}`} target="_blank" className="btn-outline btn-sm">Landing page <ExternalLink className="h-3.5 w-3.5" /></Link></div>
          </div>
        ))}
      </div>
    </div>
  );
}
