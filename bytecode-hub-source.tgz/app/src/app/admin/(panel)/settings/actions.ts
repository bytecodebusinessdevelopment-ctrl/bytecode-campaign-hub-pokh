"use server";
import { revalidatePath } from "next/cache";
import { safeAction } from "@/lib/action";
import { requirePermission } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { saveSettings, getSettings, type SiteSettings } from "@/lib/settings";
import { refreshFilePublicity } from "@/lib/storage";
import { int, lines, safeUrl, str } from "@/lib/utils";

const hex = (v: FormDataEntryValue | null, fallback: string) => (/^#[0-9a-f]{6}$/i.test(String(v)) ? String(v).toUpperCase() : fallback);

export const saveSiteSettings = safeAction(async (fd) => {
  const user = await requirePermission("manageSettings");
  const cur = await getSettings();
  const why = lines(fd.get("whyChoose")).map((l) => { const [title, ...rest] = l.split("|"); return { title: title.trim(), body: rest.join("|").trim() }; }).filter((w) => w.title);
  const emails = lines(String(fd.get("notificationEmails") ?? "").replace(/,/g, "\n")).filter((e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e));
  const patch: Partial<SiteSettings> = {
    companyName: str(fd.get("companyName")) ?? cur.companyName,
    shortName: str(fd.get("shortName")) ?? cur.shortName,
    tagline: str(fd.get("tagline")) ?? "",
    heroTitle: str(fd.get("heroTitle")) ?? cur.heroTitle,
    heroSubtitle: str(fd.get("heroSubtitle")) ?? "",
    aboutIntro: str(fd.get("aboutIntro")) ?? "",
    aboutBody: str(fd.get("aboutBody")) ?? "",
    whyChoose: why.length ? why : cur.whyChoose,
    technologies: lines(fd.get("technologies")),
    phone: str(fd.get("phone")) ?? "",
    whatsapp: str(fd.get("whatsapp")) ?? "",
    email: str(fd.get("email")) ?? "",
    address: str(fd.get("address")) ?? "",
    officeHours: str(fd.get("officeHours")) ?? "",
    mapUrl: safeUrl(str(fd.get("mapUrl"))) ?? "",
    social: {
      facebook: safeUrl(str(fd.get("facebook"))) ?? "", instagram: safeUrl(str(fd.get("instagram"))) ?? "", linkedin: safeUrl(str(fd.get("linkedin"))) ?? "",
      x: safeUrl(str(fd.get("x"))) ?? "", youtube: safeUrl(str(fd.get("youtube"))) ?? "", tiktok: safeUrl(str(fd.get("tiktok"))) ?? "",
    },
    existingWebsiteUrl: safeUrl(str(fd.get("existingWebsiteUrl"))) ?? "",
    externalPortfolioUrl: safeUrl(str(fd.get("externalPortfolioUrl"))) ?? "",
    logoFileId: str(fd.get("logoFileId")),
    logoDarkFileId: str(fd.get("logoDarkFileId")),
    colors: { navy: hex(fd.get("colorNavy"), cur.colors.navy), blue: hex(fd.get("colorBlue"), cur.colors.blue), teal: hex(fd.get("colorTeal"), cur.colors.teal) },
    notificationEmails: emails,
    analytics: { ga4Id: (str(fd.get("ga4Id")) ?? "").replace(/[^A-Z0-9-]/gi, ""), metaPixelId: (str(fd.get("metaPixelId")) ?? "").replace(/\D/g, "") },
    uploadLimitsMb: {
      document: Math.min(200, Math.max(1, int(fd.get("limitDocument")) ?? cur.uploadLimitsMb.document)),
      image: Math.min(50, Math.max(1, int(fd.get("limitImage")) ?? cur.uploadLimitsMb.image)),
      video: Math.min(1000, Math.max(1, int(fd.get("limitVideo")) ?? cur.uploadLimitsMb.video)),
    },
    publicResourcesLabel: str(fd.get("publicResourcesLabel")) ?? cur.publicResourcesLabel,
    seoTitle: str(fd.get("seoTitle")) ?? cur.seoTitle,
    seoDescription: str(fd.get("seoDescription")) ?? cur.seoDescription,
    privacyPolicy: str(fd.get("privacyPolicy")) ?? "",
    termsOfUse: str(fd.get("termsOfUse")) ?? "",
    leadRetentionMonths: Math.max(1, int(fd.get("leadRetentionMonths")) ?? cur.leadRetentionMonths),
  };
  await saveSettings(patch);
  await refreshFilePublicity([patch.logoFileId, patch.logoDarkFileId, cur.logoFileId, cur.logoDarkFileId]);
  await audit(user.id, "update", "settings", null, { keys: Object.keys(patch) });
  revalidatePath("/", "layout");
  return { ok: true, message: "Settings saved." };
});
