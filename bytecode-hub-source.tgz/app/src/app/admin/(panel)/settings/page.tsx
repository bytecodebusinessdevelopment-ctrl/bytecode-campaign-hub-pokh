import type { Metadata } from "next";
import { requirePagePermission } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { getFiles } from "@/lib/storage";
import { PageHeader, Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { FileUpload } from "@/components/admin/file-upload";
import { defaultPrivacyPolicy, defaultTerms } from "@/lib/legal-defaults";
import { saveSiteSettings } from "./actions";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage() {
  await requirePagePermission("manageSettings");
  const s = await getSettings();
  const files = await getFiles([s.logoFileId, s.logoDarkFileId]);
  const f = (id: string | null) => { const x = files.find((y) => y.id === id); return x ? { id: x.id, name: x.originalName } : null; };
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Settings" subtitle="Company details, brand, website copy, analytics and legal pages — no code changes needed." />
      <ActionForm action={saveSiteSettings} className="space-y-5">
        <Section title="Company & contact">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Company name"><input name="companyName" defaultValue={s.companyName} className="input" /></L>
            <L label="Short name"><input name="shortName" defaultValue={s.shortName} className="input" /></L>
            <L label="Phone"><input name="phone" defaultValue={s.phone} className="input" /></L>
            <L label="WhatsApp number" hint="Enables the WhatsApp button across the site"><input name="whatsapp" defaultValue={s.whatsapp} placeholder="+977 98XXXXXXXX" className="input" /></L>
            <L label="Email"><input name="email" type="email" defaultValue={s.email} className="input" /></L>
            <L label="Office hours"><input name="officeHours" defaultValue={s.officeHours} placeholder="Sun–Fri, 10:00–18:00" className="input" /></L>
            <L label="Address" className="sm:col-span-2"><input name="address" defaultValue={s.address} className="input" /></L>
            <L label="Google Maps link"><input name="mapUrl" defaultValue={s.mapUrl} className="input" /></L>
            <L label="Existing website"><input name="existingWebsiteUrl" defaultValue={s.existingWebsiteUrl} className="input" /></L>
            <L label="External portfolio link (shown while portfolio is empty)" className="sm:col-span-2"><input name="externalPortfolioUrl" defaultValue={s.externalPortfolioUrl} className="input" /></L>
          </div>
        </Section>
        <Section title="Social media">
          <div className="grid gap-4 sm:grid-cols-2">
            {(["facebook", "instagram", "linkedin", "youtube", "x", "tiktok"] as const).map((k) => <L key={k} label={k[0].toUpperCase() + k.slice(1)}><input name={k} defaultValue={s.social[k]} className="input" /></L>)}
          </div>
        </Section>
        <Section title="Brand">
          <div className="grid gap-4 sm:grid-cols-3">
            <L label="Navy (primary dark)"><input type="color" name="colorNavy" defaultValue={s.colors.navy} className="h-11 w-full rounded-xl border border-line" /></L>
            <L label="Blue (primary)"><input type="color" name="colorBlue" defaultValue={s.colors.blue} className="h-11 w-full rounded-xl border border-line" /></L>
            <L label="Teal (accent)"><input type="color" name="colorTeal" defaultValue={s.colors.teal} className="h-11 w-full rounded-xl border border-line" /></L>
            <div className="sm:col-span-3 grid gap-4 sm:grid-cols-2">
              <FileUpload name="logoFileId" purpose="image" label="Logo (for light backgrounds)" initial={f(s.logoFileId)} help="PNG or WebP with transparent background" />
              <FileUpload name="logoDarkFileId" purpose="image" label="Logo (for dark backgrounds)" initial={f(s.logoDarkFileId)} />
            </div>
          </div>
          <p className="mt-3 text-xs text-ink-muted">Defaults come from ByteCode&apos;s brief. Check them against the official logo files before launch.</p>
        </Section>
        <Section title="Website copy">
          <div className="grid gap-4">
            <L label="Tagline"><input name="tagline" defaultValue={s.tagline} className="input" /></L>
            <L label="Home hero headline" hint="Text after the first full stop is highlighted"><input name="heroTitle" defaultValue={s.heroTitle} className="input" /></L>
            <L label="Home hero supporting text"><textarea name="heroSubtitle" rows={2} defaultValue={s.heroSubtitle} className="input" /></L>
            <L label="About — introduction"><textarea name="aboutIntro" rows={2} defaultValue={s.aboutIntro} className="input" /></L>
            <L label="About — full text" hint="Blank lines separate paragraphs"><textarea name="aboutBody" rows={5} defaultValue={s.aboutBody} className="input" /></L>
            <L label="Why choose us" hint="One per line: Title | short description"><textarea name="whyChoose" rows={5} defaultValue={s.whyChoose.map((w) => `${w.title} | ${w.body}`).join("\n")} className="input" /></L>
            <L label="Technologies (chips on home page)" hint="One per line. Leave empty to hide. Only list technologies ByteCode actually uses."><textarea name="technologies" rows={4} defaultValue={s.technologies.join("\n")} className="input" /></L>
            <L label="Resources section title"><input name="publicResourcesLabel" defaultValue={s.publicResourcesLabel} className="input" /></L>
          </div>
        </Section>
        <Section title="SEO">
          <div className="grid gap-4">
            <L label="Default page title"><input name="seoTitle" defaultValue={s.seoTitle} className="input" /></L>
            <L label="Default meta description"><textarea name="seoDescription" rows={2} defaultValue={s.seoDescription} className="input" /></L>
          </div>
        </Section>
        <Section title="Analytics & notifications">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Google Analytics 4 measurement ID" hint="e.g. G-XXXXXXXXXX — loads only after cookie consent"><input name="ga4Id" defaultValue={s.analytics.ga4Id} className="input" /></L>
            <L label="Meta Pixel ID"><input name="metaPixelId" defaultValue={s.analytics.metaPixelId} className="input" /></L>
            <L label="Extra emails notified of new enquiries" hint="Admins & managers are always notified" className="sm:col-span-2"><textarea name="notificationEmails" rows={2} defaultValue={s.notificationEmails.join("\n")} className="input" /></L>
          </div>
        </Section>
        <Section title="Uploads & data retention">
          <div className="grid gap-4 sm:grid-cols-4">
            <L label="Document limit (MB)"><input name="limitDocument" defaultValue={s.uploadLimitsMb.document} className="input" /></L>
            <L label="Image limit (MB)"><input name="limitImage" defaultValue={s.uploadLimitsMb.image} className="input" /></L>
            <L label="Video limit (MB)"><input name="limitVideo" defaultValue={s.uploadLimitsMb.video} className="input" /></L>
            <L label="Lead retention (months)"><input name="leadRetentionMonths" defaultValue={s.leadRetentionMonths} className="input" /></L>
          </div>
          <p className="mt-2 text-xs text-ink-muted">On Vercel, uploads go directly to storage, so large files are fine; very large videos are better hosted on YouTube/Vimeo and added as links.</p>
        </Section>
        <Section title="Legal pages">
          <p className="mb-3 placeholder-note">The default text describes how this platform handles data. Have it reviewed by ByteCode&apos;s legal advisor before launch. Leave blank to use the default; use &ldquo;## &rdquo; for headings.</p>
          <L label="Privacy Policy"><textarea name="privacyPolicy" rows={10} defaultValue={s.privacyPolicy} placeholder={defaultPrivacyPolicy(s.companyName, s.email, s.address, s.leadRetentionMonths).slice(0, 400) + "…"} className="input font-mono text-xs" /></L>
          <L label="Terms of Use" className="mt-4"><textarea name="termsOfUse" rows={8} defaultValue={s.termsOfUse} placeholder={defaultTerms(s.companyName, s.email).slice(0, 300) + "…"} className="input font-mono text-xs" /></L>
        </Section>
        <div className="sticky bottom-20 z-10 flex justify-end lg:bottom-4"><SubmitButton className="btn-primary shadow-lift">Save settings</SubmitButton></div>
      </ActionForm>
    </div>
  );
}

function L({ label, hint, children, className }: { label: string; hint?: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className ?? ""}`}><span className="label">{label}</span>{children}{hint && <span className="hint block">{hint}</span>}</label>;
}
