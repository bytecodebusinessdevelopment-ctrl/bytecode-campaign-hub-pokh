"use server";
import { safeAction } from "@/lib/action";
import { requirePermission } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { processSyncJobs, retryAllFailed, retryJobs } from "@/lib/sheets";
import { db } from "@/lib/db";
import { sql } from "drizzle-orm";
import { enqueueLeadSync } from "@/lib/sheets";
import { sendMail, emailLayout } from "@/lib/mail";

export const retrySync = safeAction(async (fd) => {
  const user = await requirePermission("retrySync");
  const ids = fd.getAll("jobId").map(String).filter(Boolean);
  if (fd.get("intent") === "all") await retryAllFailed();
  else await retryJobs(ids);
  const r = await processSyncJobs({ limit: 50 });
  await audit(user.id, "retry_sync", "sheet_sync_jobs", null, { ids: ids.length, all: fd.get("intent") === "all" });
  return { ok: true, message: "skipped" in r ? `Queued. ${r.skipped}.` : `Processed ${r.processed}: ${r.ok} synced, ${r.failed} failed.` };
});

export const resyncAll = safeAction(async () => {
  const user = await requirePermission("manageIntegrations");
  const leads = await db.execute<{ id: string }>(sql`SELECT id FROM leads`);
  for (const l of leads) await enqueueLeadSync(l.id);
  const r = await processSyncJobs({ limit: 50 });
  await audit(user.id, "resync_all", "sheet_sync_jobs", null, { leads: leads.length });
  return { ok: true, message: `Queued ${leads.length} leads for a full re-sync. ${"skipped" in r ? r.skipped : `First batch: ${r.ok} synced, ${r.failed} failed`} — the rest continue in the background.` };
});

export const testEmail = safeAction(async () => {
  const user = await requirePermission("manageIntegrations");
  const r = await sendMail({ to: user.email, subject: "Campaign Hub test email", html: emailLayout("It works!", ["Email notifications are configured correctly."]) });
  return r.sent ? { ok: true, message: `Test email sent to ${user.email}.` } : { error: `Email not sent: ${r.reason}` };
});
