import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq, inArray } from "drizzle-orm";
import { CheckCircle2, XCircle } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { sheetsConfigured, syncSummary, SHEET_HEADERS } from "@/lib/sheets";
import { mailConfigured } from "@/lib/mail";
import { driver } from "@/lib/storage";
import { PageHeader, Section, Stat } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { formatDateTime } from "@/lib/format";
import { retrySync, resyncAll, testEmail } from "./actions";

export const metadata: Metadata = { title: "Google Sheets sync" };

export default async function IntegrationsPage() {
  const user = await requirePagePermission("retrySync");
  const [summary, problems, logs, campaigns] = await Promise.all([
    syncSummary(),
    db.select({ job: t.sheetSyncJobs, code: t.leads.leadCode, leadId: t.leads.id }).from(t.sheetSyncJobs).innerJoin(t.leads, eq(t.leads.id, t.sheetSyncJobs.leadId)).where(inArray(t.sheetSyncJobs.status, ["failed", "pending", "running"])).orderBy(desc(t.sheetSyncJobs.updatedAt)).limit(100),
    db.select().from(t.syncLogs).orderBy(desc(t.syncLogs.createdAt)).limit(30),
    db.select({ name: t.campaigns.name, sheetId: t.campaigns.sheetId, sheetTab: t.campaigns.sheetTab }).from(t.campaigns),
  ]);
  const configured = sheetsConfigured();
  const Check = ({ ok, label }: { ok: boolean; label: string }) => <li className="flex items-center gap-2 text-sm">{ok ? <CheckCircle2 className="h-4 w-4 text-emerald-600" /> : <XCircle className="h-4 w-4 text-red-500" />}{label}</li>;
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Google Sheets sync & integrations" subtitle="Leads are always saved to the database first; the sheets are an operational copy. Retries update the existing row (matched by Lead ID), so duplicates are never created." />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Synced" value={summary.success} tone="good" />
        <Stat label="Pending" value={summary.pending + summary.running} />
        <Stat label="Failed" value={summary.failed} tone={summary.failed ? "bad" : "default"} />
        <Stat label="Storage" value={driver === "s3" ? "S3" : "Local"} hint={driver === "local" ? "Use S3/Supabase on Vercel" : undefined} />
      </div>

      <div className="mt-5 grid gap-5 md:grid-cols-2">
        <Section title="Configuration">
          <ul className="space-y-2">
            <Check ok={configured} label="Service-account credentials (GOOGLE_SERVICE_ACCOUNT_EMAIL / GOOGLE_PRIVATE_KEY)" />
            <Check ok={Boolean(process.env.GOOGLE_SHEETS_CENTRAL_ID)} label="Central company lead register (GOOGLE_SHEETS_CENTRAL_ID)" />
            {campaigns.map((c) => <Check key={c.name} ok={Boolean(c.sheetId)} label={`${c.name} sheet${c.sheetId ? ` → tab "${c.sheetTab}"` : " (set in Campaigns)"}`} />)}
            <Check ok={mailConfigured()} label="Email (SMTP) for notifications" />
            <Check ok={Boolean(process.env.CRON_SECRET)} label="Scheduled jobs secret (CRON_SECRET)" />
          </ul>
          {!configured && <p className="mt-3 text-sm text-amber-700">Until credentials are added, sync jobs wait safely in the queue and run automatically once configured.</p>}
          {process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL && <p className="mt-3 text-xs text-ink-muted">Share each sheet with <span className="font-mono">{process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL}</span> (Editor).</p>}
        </Section>
        <Section title="Actions">
          <div className="flex flex-col gap-2">
            <ActionForm action={retrySync}><input type="hidden" name="intent" value="all" /><SubmitButton className="btn-primary btn-sm w-full">Retry all failed & process queue</SubmitButton></ActionForm>
            {can(user.role, "manageIntegrations") && <ActionForm action={resyncAll}><SubmitButton className="btn-outline btn-sm w-full" confirm="Re-sync every lead to Google Sheets? Existing rows are updated in place.">Full re-sync of all leads</SubmitButton></ActionForm>}
            {can(user.role, "manageIntegrations") && <ActionForm action={testEmail}><SubmitButton className="btn-outline btn-sm w-full">Send test email to me</SubmitButton></ActionForm>}
          </div>
          <p className="mt-4 text-xs text-ink-muted">Sheet columns: {SHEET_HEADERS.join(" · ")}. Detailed requirements stay in the database — the &ldquo;Lead record&rdquo; column links to them.</p>
        </Section>
      </div>

      <Section title="Pending & failed jobs" className="mt-5">
        {problems.length ? (
          <ActionForm action={retrySync}>
            <div className="table-wrap"><table className="table">
              <thead><tr><th></th><th>Lead</th><th>Target</th><th>Status</th><th>Attempts</th><th>Last error</th><th>Next attempt</th></tr></thead>
              <tbody>{problems.map(({ job, code, leadId }) => (
                <tr key={job.id}>
                  <td><input type="checkbox" name="jobId" value={job.id} className="check" aria-label={`Select ${code}`} /></td>
                  <td><Link href={`/admin/leads/${leadId}`} className="font-mono text-brand">{code}</Link></td>
                  <td className="text-xs">{job.target}</td>
                  <td><span className={`badge ${job.status === "failed" ? "bg-red-100 text-red-700" : "bg-slate-100 text-slate-600"}`}>{job.status}</span></td>
                  <td className="text-xs tabular-nums">{job.attempts}</td>
                  <td className="max-w-[320px] text-xs text-ink-soft">{job.lastError ?? "—"}</td>
                  <td className="text-xs text-ink-muted">{formatDateTime(job.nextAttemptAt)}</td>
                </tr>
              ))}</tbody>
            </table></div>
            <SubmitButton className="btn-primary btn-sm mt-3">Retry selected</SubmitButton>
          </ActionForm>
        ) : <p className="text-sm text-ink-muted">Nothing pending — all good.</p>}
      </Section>

      <Section title="Recent sync log" className="mt-5">
        <ul className="space-y-1.5 text-xs">{logs.map((l) => <li key={l.id} className="flex gap-2"><span className={l.ok ? "text-emerald-600" : "text-red-600"}>{l.ok ? "✓" : "✕"}</span><span className="text-ink-muted">{formatDateTime(l.createdAt)}</span><span className="text-ink-soft">{l.message}</span></li>)}</ul>
        {!logs.length && <p className="text-sm text-ink-muted">No sync activity yet.</p>}
      </Section>
    </div>
  );
}
