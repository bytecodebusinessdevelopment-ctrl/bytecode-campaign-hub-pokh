"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { and, eq, ne } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { safeAction } from "@/lib/action";
import { requirePermission } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { refreshFilePublicity, deleteFile } from "@/lib/storage";
import { bool, int, lines, safeUrl, slugify, str } from "@/lib/utils";

const CLASSES = ["client_project", "internal_demo", "uiux_concept", "prototype", "in_progress"] as const;

async function uniqueSlug(base: string, excludeId?: string) {
  let slug = slugify(base);
  for (let i = 2; ; i++) {
    const [hit] = await db.select({ id: t.portfolioProjects.id }).from(t.portfolioProjects).where(excludeId ? and(eq(t.portfolioProjects.slug, slug), ne(t.portfolioProjects.id, excludeId)) : eq(t.portfolioProjects.slug, slug));
    if (!hit) return slug;
    slug = `${slugify(base)}-${i}`;
  }
}

export const saveProject = safeAction(async (fd) => {
  const user = await requirePermission("manageContent");
  const id = str(fd.get("id"));
  const title = str(fd.get("title"));
  if (!title) throw new Error("Title is required.");
  const classification = String(fd.get("classification")) as (typeof CLASSES)[number];
  if (!CLASSES.includes(classification)) throw new Error("Choose a classification.");
  const status = fd.get("status") === "published" ? "published" : "draft";
  const clientNamePublic = bool(fd.get("clientNamePublic"));
  if (status === "published" && !str(fd.get("summary")) && !str(fd.get("description"))) throw new Error("Add a summary or description before publishing.");
  const [existing] = id ? await db.select().from(t.portfolioProjects).where(eq(t.portfolioProjects.id, id)) : [];
  const values = {
    title,
    slug: await uniqueSlug(str(fd.get("slug")) ?? title, id ?? undefined),
    clientName: str(fd.get("clientName")), clientNamePublic,
    industryId: str(fd.get("industryId")), projectTypeId: str(fd.get("projectTypeId")), classification,
    summary: str(fd.get("summary")), description: str(fd.get("description")), objectives: str(fd.get("objectives")), problems: str(fd.get("problems")), solution: str(fd.get("solution")),
    features: lines(fd.get("features")), technologies: lines(fd.get("technologies")),
    coverFileId: str(fd.get("coverFileId")), liveUrl: safeUrl(str(fd.get("liveUrl"))), videoUrl: safeUrl(str(fd.get("videoUrl"))),
    year: int(fd.get("year")), featured: bool(fd.get("featured")), status: status as "draft" | "published",
    internalNote: str(fd.get("internalNote")), sortOrder: int(fd.get("sortOrder")) ?? 0,
    publishedAt: status === "published" ? existing?.publishedAt ?? new Date() : existing?.publishedAt ?? null,
    updatedAt: new Date(),
  };
  let projectId = id;
  if (id) await db.update(t.portfolioProjects).set(values).where(eq(t.portfolioProjects.id, id));
  else projectId = (await db.insert(t.portfolioProjects).values(values).returning({ id: t.portfolioProjects.id }))[0].id;

  const services = fd.getAll("services").map(String).filter(Boolean);
  await db.delete(t.projectServices).where(eq(t.projectServices.projectId, projectId!));
  if (services.length) await db.insert(t.projectServices).values(services.map((serviceId) => ({ projectId: projectId!, serviceId })));

  const newMedia = fd.getAll("newMedia").map(String).filter(Boolean);
  const kind = (String(fd.get("newMediaKind") || "gallery")) as "desktop" | "mobile" | "gallery";
  if (newMedia.length) await db.insert(t.projectMedia).values(newMedia.map((fileId, i) => ({ projectId: projectId!, fileId, kind, sortOrder: 100 + i })));

  const media = await db.select({ fileId: t.projectMedia.fileId }).from(t.projectMedia).where(eq(t.projectMedia.projectId, projectId!));
  await refreshFilePublicity([values.coverFileId, existing?.coverFileId, ...media.map((m) => m.fileId)]);
  await audit(user.id, id ? "update" : "create", "portfolio_project", projectId, { title, status });
  revalidatePath("/portfolio");
  revalidatePath(`/portfolio/${values.slug}`);
  revalidatePath("/", "layout");
  if (!id) redirect(`/admin/portfolio/${projectId}?saved=1`);
  return { ok: true, message: status === "published" ? "Saved and published." : "Saved as draft." };
});

export const updateMedia = safeAction(async (fd) => {
  const user = await requirePermission("manageContent");
  const mediaId = String(fd.get("mediaId"));
  const [m] = await db.select().from(t.projectMedia).where(eq(t.projectMedia.id, mediaId));
  if (!m) return { ok: true };
  if (fd.get("intent") === "delete") {
    await db.delete(t.projectMedia).where(eq(t.projectMedia.id, mediaId));
    await deleteFile(m.fileId);
    await audit(user.id, "delete", "project_media", mediaId);
    revalidatePath("/portfolio");
    return { ok: true, message: "Image removed." };
  }
  await db.update(t.projectMedia).set({ caption: str(fd.get("caption")), kind: String(fd.get("kind")) as "desktop" | "mobile" | "gallery", sortOrder: int(fd.get("sortOrder")) ?? m.sortOrder }).where(eq(t.projectMedia.id, mediaId));
  revalidatePath("/portfolio");
  return { ok: true, message: "Image updated." };
});

export const deleteProject = safeAction(async (fd) => {
  const user = await requirePermission("manageContent");
  const id = String(fd.get("id"));
  const [p] = await db.select().from(t.portfolioProjects).where(eq(t.portfolioProjects.id, id));
  if (!p) redirect("/admin/portfolio");
  const media = await db.select({ fileId: t.projectMedia.fileId }).from(t.projectMedia).where(eq(t.projectMedia.projectId, id));
  await db.delete(t.portfolioProjects).where(eq(t.portfolioProjects.id, id));
  for (const m of media) await deleteFile(m.fileId);
  if (p.coverFileId) await deleteFile(p.coverFileId);
  await audit(user.id, "delete", "portfolio_project", id, { title: p.title });
  revalidatePath("/portfolio");
  redirect("/admin/portfolio?deleted=1");
});
