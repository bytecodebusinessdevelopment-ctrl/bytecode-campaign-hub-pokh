import type { Metadata } from "next";
import Link from "next/link";
import { asc, desc, eq } from "drizzle-orm";
import { Plus, AlertCircle, Star } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Tabs, Empty } from "@/components/admin/server-ui";
import { ClassificationBadge } from "@/components/public/cards";
import { formatDate } from "@/lib/format";

export const metadata: Metadata = { title: "Portfolio" };

export default async function AdminPortfolio({ searchParams }: { searchParams: Promise<{ status?: string; deleted?: string }> }) {
  await requirePagePermission("manageContent");
  const sp = await searchParams;
  const status = sp.status === "draft" || sp.status === "published" ? sp.status : undefined;
  const rows = await db.query.portfolioProjects.findMany({
    where: status ? eq(t.portfolioProjects.status, status) : undefined,
    with: { industry: true, projectType: true },
    orderBy: [desc(t.portfolioProjects.featured), asc(t.portfolioProjects.sortOrder), desc(t.portfolioProjects.updatedAt)],
  });
  const all = await db.select({ status: t.portfolioProjects.status }).from(t.portfolioProjects);
  return (
    <div>
      {sp.deleted && <p className="mb-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">Project deleted.</p>}
      <PageHeader title="Portfolio" subtitle="Only published projects appear on the website. Never publish a project that isn't supported by real project information." actions={<Link href="/admin/portfolio/new" className="btn-primary btn-sm"><Plus className="h-4 w-4" /> New project</Link>} />
      <Tabs current={status ?? "all"} tabs={[
        { key: "all", label: "All", href: "/admin/portfolio", count: all.length },
        { key: "published", label: "Published", href: "/admin/portfolio?status=published", count: all.filter((a) => a.status === "published").length },
        { key: "draft", label: "Drafts", href: "/admin/portfolio?status=draft", count: all.filter((a) => a.status === "draft").length },
      ]} />
      {rows.length ? (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Project</th><th>Classification</th><th>Industry / type</th><th>Status</th><th>Updated</th></tr></thead>
            <tbody>
              {rows.map((p) => (
                <tr key={p.id} className="hover:bg-surface/60">
                  <td className="min-w-[260px]">
                    <Link href={`/admin/portfolio/${p.id}`} className="font-semibold text-navy hover:text-brand">{p.featured && <Star className="mr-1 inline h-3.5 w-3.5 fill-amber-400 text-amber-400" />}{p.title}</Link>
                    {p.internalNote && p.status === "draft" && <p className="mt-0.5 flex items-start gap-1 text-xs text-amber-700"><AlertCircle className="mt-0.5 h-3 w-3 shrink-0" /><span className="line-clamp-1">{p.internalNote}</span></p>}
                  </td>
                  <td><ClassificationBadge value={p.classification} /></td>
                  <td className="text-xs text-ink-soft">{p.industry?.name ?? "—"}<br />{p.projectType?.name ?? ""}</td>
                  <td>{p.status === "published" ? <span className="badge bg-emerald-100 text-emerald-700">Published</span> : <span className="badge bg-slate-100 text-slate-600">Draft</span>}</td>
                  <td className="text-xs text-ink-muted">{formatDate(p.updatedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <Empty>No projects yet.</Empty>}
    </div>
  );
}
