import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { ExternalLink, Trash2 } from "lucide-react";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { FileUpload, MultiImageUpload } from "@/components/admin/file-upload";
import { CLASSIFICATION_LABELS, DEMO_TYPE_LABELS } from "@/lib/enquiry-config";
import { saveProject, updateMedia, deleteProject } from "../actions";

export const metadata: Metadata = { title: "Edit project" };

export default async function EditProject({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ saved?: string }> }) {
  await requirePagePermission("manageContent");
  const { id } = await params;
  const sp = await searchParams;
  const isNew = id === "new";
  const p = isNew ? null : await db.query.portfolioProjects.findFirst({
    where: eq(t.portfolioProjects.id, id),
    with: { cover: true, media: { with: { file: true }, orderBy: asc(t.projectMedia.sortOrder) }, services: true, demos: true, resources: { with: { resource: true } } },
  });
  if (!isNew && !p) notFound();
  const [industries, types, services] = await Promise.all([
    db.select().from(t.industries).orderBy(asc(t.industries.sortOrder)),
    db.select().from(t.projectTypes).orderBy(asc(t.projectTypes.sortOrder)),
    db.select().from(t.services).orderBy(asc(t.services.sortOrder)),
  ]);
  const svcIds = new Set(p?.services.map((s) => s.serviceId));

  return (
    <div className="mx-auto max-w-5xl">
      {sp.saved && <p className="mb-4 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">Project created.</p>}
      <PageHeader
        title={isNew ? "New portfolio project" : p!.title}
        back={{ href: "/admin/portfolio", label: "Portfolio" }}
        actions={p?.status === "published" ? <Link href={`/portfolio/${p.slug}`} target="_blank" className="btn-outline btn-sm">View on site <ExternalLink className="h-4 w-4" /></Link> : undefined}
      />
      {p?.internalNote && <p className="placeholder-note mb-5"><strong>Internal note:</strong> {p.internalNote}</p>}

      <ActionForm action={saveProject} className="space-y-5">
        {p && <input type="hidden" name="id" value={p.id} />}
        <Section title="Basics">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Project title *" className="sm:col-span-2"><input name="title" required defaultValue={p?.title} className="input" /></L>
            <L label="Classification *" hint="Never present a demo or concept as a completed client project."><select name="classification" defaultValue={p?.classification ?? "client_project"} className="input">{Object.entries(CLASSIFICATION_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></L>
            <L label="URL slug" hint="Leave blank to generate from the title"><input name="slug" defaultValue={p?.slug} className="input" /></L>
            <L label="Industry"><select name="industryId" defaultValue={p?.industryId ?? ""} className="input"><option value="">—</option>{industries.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</select></L>
            <L label="Project type"><select name="projectTypeId" defaultValue={p?.projectTypeId ?? ""} className="input"><option value="">—</option>{types.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</select></L>
            <L label="Client name"><input name="clientName" defaultValue={p?.clientName ?? ""} className="input" /></L>
            <L label="Year"><input name="year" inputMode="numeric" defaultValue={p?.year ?? ""} className="input" /></L>
            <label className="flex items-start gap-3 text-sm text-ink-soft sm:col-span-2"><input type="checkbox" name="clientNamePublic" defaultChecked={p?.clientNamePublic} className="check mt-0.5" /> The client has authorised us to show their name publicly</label>
            <L label="Short summary" className="sm:col-span-2"><textarea name="summary" rows={2} defaultValue={p?.summary ?? ""} className="input" /></L>
            <L label="Project description" className="sm:col-span-2"><textarea name="description" rows={5} defaultValue={p?.description ?? ""} className="input" /></L>
          </div>
        </Section>

        <Section title="Case study">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Business objectives"><textarea name="objectives" rows={4} defaultValue={p?.objectives ?? ""} className="input" /></L>
            <L label="Problems addressed"><textarea name="problems" rows={4} defaultValue={p?.problems ?? ""} className="input" /></L>
            <L label="Solution delivered" className="sm:col-span-2"><textarea name="solution" rows={4} defaultValue={p?.solution ?? ""} className="input" /></L>
            <L label="Features & functionality" hint="One per line"><textarea name="features" rows={5} defaultValue={p?.features.join("\n")} className="input" /></L>
            <L label="Technologies used" hint="One per line"><textarea name="technologies" rows={5} defaultValue={p?.technologies.join("\n")} className="input" /></L>
          </div>
        </Section>

        <Section title="Links & media">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Live website URL"><input name="liveUrl" defaultValue={p?.liveUrl ?? ""} className="input" /></L>
            <L label="Video walkthrough URL" hint="YouTube, Vimeo or Google Drive"><input name="videoUrl" defaultValue={p?.videoUrl ?? ""} className="input" /></L>
            <div className="sm:col-span-2"><FileUpload name="coverFileId" purpose="image" label="Cover image" initial={p?.cover ? { id: p.cover.id, name: p.cover.originalName } : null} help="Desktop screenshot works well (16:10)." /></div>
            <div className="sm:col-span-2">
              <span className="label">Add screenshots</span>
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start">
                <select name="newMediaKind" className="input-sm sm:w-48" defaultValue="desktop" aria-label="Screenshot type"><option value="desktop">Desktop screenshots</option><option value="mobile">Mobile screenshots</option><option value="gallery">Gallery images</option></select>
                <MultiImageUpload name="newMedia" />
              </div>
              <p className="hint">New images are added when you save.</p>
            </div>
          </div>
          <p className="mt-4 text-sm text-ink-muted">Vercel deployments, UI/UX previews and Figma links are managed in <Link href={`/admin/showcase${p ? `?project=${p.id}` : ""}`} className="text-brand underline">Demos & UI/UX</Link> and linked to this project.</p>
        </Section>

        <Section title="Related services">
          <div className="flex flex-wrap gap-2">
            {services.map((s) => <label key={s.id} className="flex min-h-[40px] items-center gap-2 rounded-xl border border-line px-3 text-sm has-[:checked]:border-brand has-[:checked]:bg-brand/5"><input type="checkbox" name="services" value={s.id} defaultChecked={svcIds.has(s.id)} className="check" /> {s.name}</label>)}
          </div>
        </Section>

        <Section title="Publishing">
          <div className="grid gap-4 sm:grid-cols-3">
            <L label="Status"><select name="status" defaultValue={p?.status ?? "draft"} className="input"><option value="draft">Draft (hidden)</option><option value="published">Published</option></select></L>
            <L label="Display order"><input name="sortOrder" inputMode="numeric" defaultValue={p?.sortOrder ?? 0} className="input" /></L>
            <label className="flex items-center gap-3 self-end pb-3 text-sm"><input type="checkbox" name="featured" defaultChecked={p?.featured} className="check" /> Featured on home page</label>
            <L label="Internal note (never shown publicly)" className="sm:col-span-3"><textarea name="internalNote" rows={2} defaultValue={p?.internalNote ?? ""} className="input" /></L>
          </div>
        </Section>
        <div className="sticky bottom-20 z-10 flex justify-end lg:bottom-4"><SubmitButton className="btn-primary shadow-lift">Save project</SubmitButton></div>
      </ActionForm>

      {p && p.media.length > 0 && (
        <Section title={`Screenshots & images (${p.media.length})`} className="mt-5">
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {p.media.map((m) => (
              <li key={m.id} className="rounded-2xl border border-line p-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={`/api/files/${m.fileId}`} alt="" className="aspect-video w-full rounded-lg border border-line object-cover object-top" />
                <ActionForm action={updateMedia} className="mt-2 space-y-2">
                  <input type="hidden" name="mediaId" value={m.id} />
                  <input name="caption" defaultValue={m.caption ?? ""} placeholder="Caption" className="input-sm" />
                  <div className="flex gap-2">
                    <select name="kind" defaultValue={m.kind} className="input-sm" aria-label="Type"><option value="desktop">Desktop</option><option value="mobile">Mobile</option><option value="gallery">Gallery</option></select>
                    <input name="sortOrder" defaultValue={m.sortOrder} className="input-sm w-20" aria-label="Order" />
                  </div>
                  <div className="flex gap-2"><SubmitButton className="btn-outline btn-sm flex-1">Update</SubmitButton><SubmitButton className="btn-ghost btn-sm text-red-600" name="intent" value="delete" confirm="Delete this image?"><Trash2 className="h-4 w-4" /></SubmitButton></div>
                </ActionForm>
              </li>
            ))}
          </ul>
        </Section>
      )}

      {p && (
        <div className="mt-5 grid gap-5 md:grid-cols-2">
          <Section title="Linked demos">
            {p.demos.length ? <ul className="space-y-2 text-sm">{p.demos.map((d) => <li key={d.id}><Link href={`/admin/showcase/${d.id}`} className="text-brand hover:underline">{d.title}</Link> <span className="text-ink-muted">· {DEMO_TYPE_LABELS[d.demoType]}</span></li>)}</ul> : <p className="text-sm text-ink-muted">None yet.</p>}
            <Link href={`/admin/showcase/new?project=${p.id}`} className="btn-outline btn-sm mt-3">+ Add demo link</Link>
          </Section>
          <Section title="Linked documents">
            {p.resources.length ? <ul className="space-y-2 text-sm">{p.resources.map(({ resource: r }) => <li key={r.id}><Link href={`/admin/resources/${r.id}`} className="text-brand hover:underline">{r.title}</Link></li>)}</ul> : <p className="text-sm text-ink-muted">None yet — link documents to this project from the Resources editor.</p>}
          </Section>
        </div>
      )}

      {p && (
        <Section title="Delete project" className="mt-5">
          <ActionForm action={deleteProject} refresh={false}><input type="hidden" name="id" value={p.id} /><SubmitButton className="btn-danger btn-sm" confirm="Delete this project and its images permanently?"><Trash2 className="h-4 w-4" /> Delete project</SubmitButton></ActionForm>
        </Section>
      )}
    </div>
  );
}

function L({ label, hint, children, className }: { label: string; hint?: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className ?? ""}`}><span className="label">{label}</span>{children}{hint && <span className="hint block">{hint}</span>}</label>;
}
