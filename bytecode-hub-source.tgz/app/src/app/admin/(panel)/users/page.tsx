import type { Metadata } from "next";
import { asc } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { ROLE_LABELS } from "@/lib/permissions";
import { PageHeader, Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { formatDateTime } from "@/lib/format";
import { createUser, updateUser } from "./actions";

export const metadata: Metadata = { title: "Users" };

export default async function UsersPage() {
  const me = await requirePagePermission("manageUsers");
  const users = await db.select().from(t.users).orderBy(asc(t.users.name));
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Users" subtitle="Individual accounts for every team member — never share a login." />
      <Section title="Roles" className="mb-5">
        <ul className="grid gap-3 text-sm sm:grid-cols-3">
          <li><strong className="text-navy">Administrator</strong><p className="text-ink-muted">Full access: users, settings, integrations, services & pricing, campaigns, all leads.</p></li>
          <li><strong className="text-navy">Manager</strong><p className="text-ink-muted">All leads, assign, reports, export, merge duplicates; manage portfolio & resources.</p></li>
          <li><strong className="text-navy">BD Team Member</strong><p className="text-ink-muted">Add leads; view & update leads they created or are assigned; meetings, notes and follow-ups; presenter kit.</p></li>
        </ul>
      </Section>
      <Section title="Add user" className="mb-5">
        <ActionForm action={createUser} resetOnSuccess className="grid gap-3 sm:grid-cols-5">
          <input name="name" placeholder="Full name" required className="input-sm sm:col-span-2" />
          <input name="email" type="email" placeholder="Email" required className="input-sm sm:col-span-2" />
          <select name="role" defaultValue="bd" className="input-sm"><option value="bd">BD Team Member</option><option value="manager">Manager</option><option value="admin">Administrator</option></select>
          <input name="phone" placeholder="Phone (optional)" className="input-sm sm:col-span-2" />
          <input name="password" placeholder="Password (blank = generate)" className="input-sm sm:col-span-2" autoComplete="new-password" />
          <SubmitButton className="btn-primary btn-sm">Create</SubmitButton>
        </ActionForm>
      </Section>
      <div className="space-y-2">
        {users.map((u) => (
          <ActionForm key={u.id} action={updateUser} className={`card grid items-center gap-2 p-3 md:grid-cols-[1.4fr_1fr_160px_auto_auto] ${u.active ? "" : "opacity-60"}`}>
            <input type="hidden" name="id" value={u.id} />
            <div className="min-w-0"><input name="name" defaultValue={u.name} className="input-sm" aria-label="Name" /><p className="mt-1 truncate text-xs text-ink-muted">{u.email}{u.id === me.id ? " (you)" : ""} · last sign-in {u.lastLoginAt ? formatDateTime(u.lastLoginAt) : "never"}</p></div>
            <input name="phone" defaultValue={u.phone ?? ""} placeholder="Phone" className="input-sm" aria-label="Phone" />
            <select name="role" defaultValue={u.role} className="input-sm" aria-label="Role">{Object.entries(ROLE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
            <label className="flex items-center gap-1 text-xs"><input type="checkbox" name="active" defaultChecked={u.active} className="check" /> Active</label>
            <div className="flex gap-1"><SubmitButton className="btn-primary btn-sm">Save</SubmitButton><SubmitButton className="btn-ghost btn-sm" name="intent" value="reset" confirm={`Reset ${u.name}'s password?`}>Reset password</SubmitButton></div>
          </ActionForm>
        ))}
      </div>
    </div>
  );
}
