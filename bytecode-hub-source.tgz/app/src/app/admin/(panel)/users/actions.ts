"use server";
import { randomBytes } from "crypto";
import { and, eq, ne, sql } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { safeAction } from "@/lib/action";
import { requirePermission, hashPassword, passwordProblems } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { sendMail, emailLayout } from "@/lib/mail";
import { siteUrl } from "@/lib/request";
import { bool, str } from "@/lib/utils";

const ROLES = ["admin", "manager", "bd"] as const;

function tempPassword() {
  return randomBytes(9).toString("base64url").replace(/[-_]/g, "x") + "7";
}

export const createUser = safeAction(async (fd) => {
  const admin = await requirePermission("manageUsers");
  const name = str(fd.get("name"));
  const email = str(fd.get("email"))?.toLowerCase();
  const role = String(fd.get("role")) as (typeof ROLES)[number];
  if (!name || !email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Enter a name and valid email.");
  if (!ROLES.includes(role)) throw new Error("Choose a role.");
  const [exists] = await db.select({ id: t.users.id }).from(t.users).where(sql`lower(${t.users.email}) = ${email}`);
  if (exists) throw new Error("A user with that email already exists.");
  const password = str(fd.get("password")) ?? tempPassword();
  const problem = passwordProblems(password);
  if (problem) throw new Error(problem);
  const [u] = await db.insert(t.users).values({ name, email, role, phone: str(fd.get("phone")), passwordHash: await hashPassword(password), mustChangePassword: true }).returning({ id: t.users.id });
  await audit(admin.id, "create", "user", u.id, { email, role });
  await sendMail({ to: email, subject: "Your ByteCode Campaign Hub account", html: emailLayout(`Welcome, ${name.split(" ")[0]}`, [`An account has been created for you on the ByteCode Campaign Hub.`, `Email: ${email}\nTemporary password: ${password}`, "You'll be asked to change your password after signing in."], { label: "Sign in", url: siteUrl("/admin/login") }) });
  return { ok: true, message: `User created. Temporary password: ${password} — share it securely (also emailed if SMTP is configured).` };
});

export const updateUser = safeAction(async (fd) => {
  const admin = await requirePermission("manageUsers");
  const id = String(fd.get("id"));
  const role = String(fd.get("role")) as (typeof ROLES)[number];
  const active = bool(fd.get("active"));
  if (!ROLES.includes(role)) throw new Error("Choose a role.");
  if (id === admin.id && (role !== "admin" || !active)) throw new Error("You cannot remove your own administrator access.");
  if (role !== "admin" || !active) {
    const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(t.users).where(and(eq(t.users.role, "admin"), eq(t.users.active, true), ne(t.users.id, id)));
    if (!Number(n)) throw new Error("At least one active administrator is required.");
  }
  await db.update(t.users).set({ name: str(fd.get("name")) ?? undefined, phone: str(fd.get("phone")), role, active, updatedAt: new Date() }).where(eq(t.users.id, id));
  if (!active) await db.delete(t.sessions).where(eq(t.sessions.userId, id));
  if (fd.get("intent") === "reset") {
    const password = tempPassword();
    await db.update(t.users).set({ passwordHash: await hashPassword(password), mustChangePassword: true }).where(eq(t.users.id, id));
    await db.delete(t.sessions).where(eq(t.sessions.userId, id));
    await audit(admin.id, "reset_password", "user", id);
    return { ok: true, message: `Password reset. Temporary password: ${password}` };
  }
  await audit(admin.id, "update", "user", id, { role, active });
  return { ok: true, message: active ? "User updated." : "User deactivated and signed out." };
});
