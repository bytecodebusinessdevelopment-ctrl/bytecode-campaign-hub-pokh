import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { ROLE_LABELS } from "@/lib/permissions";
import { PageHeader, Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { changePassword } from "../../actions-auth";

export const metadata: Metadata = { title: "My account" };

export default async function AccountPage({ searchParams }: { searchParams: Promise<{ first?: string }> }) {
  const user = await requireUser();
  const { first } = await searchParams;
  return (
    <div className="mx-auto max-w-xl">
      <PageHeader title="My account" subtitle={`${user.name} · ${user.email} · ${ROLE_LABELS[user.role]}`} />
      {(first || user.mustChangePassword) && <p className="placeholder-note mb-5">Please choose a new password to replace the temporary one.</p>}
      <Section title="Change password">
        <ActionForm action={changePassword} resetOnSuccess className="space-y-3">
          <label className="block"><span className="label">Current password</span><input type="password" name="current" required autoComplete="current-password" className="input" /></label>
          <label className="block"><span className="label">New password</span><input type="password" name="next" required minLength={10} autoComplete="new-password" className="input" /><span className="hint block">At least 10 characters, with letters and numbers.</span></label>
          <label className="block"><span className="label">Confirm new password</span><input type="password" name="confirm" required autoComplete="new-password" className="input" /></label>
          <SubmitButton>Update password</SubmitButton>
        </ActionForm>
      </Section>
    </div>
  );
}
