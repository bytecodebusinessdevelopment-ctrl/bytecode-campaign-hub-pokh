import type { Metadata } from "next";
import { asc } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Section } from "@/components/admin/server-ui";
import { ActionForm, SubmitButton } from "@/components/admin/ui";
import { saveTestimonial } from "./actions";

export const metadata: Metadata = { title: "Testimonials" };

export default async function TestimonialsPage() {
  await requirePagePermission("manageContent");
  const rows = await db.select().from(t.testimonials).orderBy(asc(t.testimonials.sortOrder));
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Testimonials" subtitle="Only real client feedback, published with the client's documented permission. The home page section stays hidden until at least one is published." />
      <div className="space-y-4">
        {[...rows, null].map((r) => (
          <Section key={r?.id ?? "new"} title={r ? r.personName : "Add a testimonial"}>
            <ActionForm action={saveTestimonial} resetOnSuccess={!r} className="grid gap-3 sm:grid-cols-3">
              {r && <input type="hidden" name="id" value={r.id} />}
              <input name="personName" defaultValue={r?.personName} placeholder="Client name *" className="input" required />
              <input name="designation" defaultValue={r?.designation ?? ""} placeholder="Designation" className="input" />
              <input name="company" defaultValue={r?.company ?? ""} placeholder="Company" className="input" />
              <textarea name="quote" defaultValue={r?.quote} placeholder="Exact words from the client *" rows={3} className="input sm:col-span-3" required />
              <input name="consentNote" defaultValue={r?.consentNote ?? ""} placeholder="Where consent is recorded (e.g. email 12 Nov 2026)" className="input sm:col-span-2" />
              <input name="sortOrder" defaultValue={r?.sortOrder ?? 0} className="input" aria-label="Order" />
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="consentConfirmed" defaultChecked={r?.consentConfirmed} className="check" /> Client consent confirmed</label>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="published" defaultChecked={r?.published} className="check" /> Published</label>
              <div className="flex gap-2 sm:col-span-3"><SubmitButton className="btn-primary btn-sm">Save</SubmitButton>{r && <SubmitButton className="btn-ghost btn-sm text-red-600" name="intent" value="delete" confirm="Delete this testimonial?">Delete</SubmitButton>}</div>
            </ActionForm>
          </Section>
        ))}
      </div>
    </div>
  );
}
