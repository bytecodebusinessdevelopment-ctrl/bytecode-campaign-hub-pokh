"use server";
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { safeAction } from "@/lib/action";
import { requirePermission } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { bool, int, str } from "@/lib/utils";

export const saveTestimonial = safeAction(async (fd) => {
  const user = await requirePermission("manageContent");
  const id = str(fd.get("id"));
  if (fd.get("intent") === "delete" && id) {
    await db.delete(t.testimonials).where(eq(t.testimonials.id, id));
    await audit(user.id, "delete", "testimonial", id);
    revalidatePath("/");
    return { ok: true, message: "Deleted." };
  }
  const personName = str(fd.get("personName"));
  const quote = str(fd.get("quote"));
  if (!personName || !quote) throw new Error("Name and quote are required.");
  const consentConfirmed = bool(fd.get("consentConfirmed"));
  const consentNote = str(fd.get("consentNote"));
  const published = bool(fd.get("published"));
  if (published && (!consentConfirmed || !consentNote)) throw new Error("A testimonial can only be published with confirmed client consent and a note of where that consent is recorded.");
  const values = { personName, quote, designation: str(fd.get("designation")), company: str(fd.get("company")), consentConfirmed, consentNote, published, sortOrder: int(fd.get("sortOrder")) ?? 0 };
  if (id) await db.update(t.testimonials).set(values).where(eq(t.testimonials.id, id));
  else await db.insert(t.testimonials).values(values);
  await audit(user.id, id ? "update" : "create", "testimonial", id, { personName, published });
  revalidatePath("/");
  return { ok: true, message: "Saved." };
});
