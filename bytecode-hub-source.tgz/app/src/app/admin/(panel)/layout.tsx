import type { Metadata } from "next";
import Link from "next/link";
import { Bell } from "lucide-react";
import { requireUser } from "@/lib/auth";
import { unreadCount } from "@/lib/notify";
import { AdminNav, RegisterSW } from "@/components/admin/nav";
import { logout } from "../actions-auth";

export const metadata: Metadata = { title: { default: "Campaign Hub", template: "%s · Campaign Hub" }, robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const unread = await unreadCount(user.id);
  return (
    <div className="min-h-dvh bg-surface">
      <AdminNav user={{ name: user.name, role: user.role }} unread={unread} logoutAction={logout} />
      <RegisterSW />
      <div className="lg:pl-64">
        <div className="hidden h-16 items-center justify-end gap-3 border-b border-line bg-white px-8 lg:flex">
          <Link href="/" target="_blank" className="text-sm text-ink-muted hover:text-brand">View website ↗</Link>
          <Link href="/admin/notifications" className="btn-ghost relative px-2.5" aria-label="Notifications">
            <Bell className="h-5 w-5" />
            {unread > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white">{unread > 99 ? "99+" : unread}</span>}
          </Link>
          <Link href="/admin/leads/quick" className="btn-accent btn-sm">+ Quick capture</Link>
        </div>
        <main className="mx-auto max-w-[1400px] px-4 pb-28 pt-6 sm:px-6 lg:px-8 lg:pb-12">{children}</main>
      </div>
    </div>
  );
}
