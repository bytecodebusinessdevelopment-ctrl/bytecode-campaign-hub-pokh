import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { PageHeader, Pagination } from "@/components/admin/server-ui";
import { formatDateTime } from "@/lib/format";

export const metadata: Metadata = { title: "Audit log" };

export default async function AuditPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  await requirePagePermission("viewAudit");
  const page = Math.max(1, Number((await searchParams).page ?? 1) || 1);
  const rows = await db.select({ a: t.auditLogs, user: t.users.name }).from(t.auditLogs).leftJoin(t.users, eq(t.users.id, t.auditLogs.userId)).orderBy(desc(t.auditLogs.createdAt)).limit(50).offset((page - 1) * 50);
  return (
    <div>
      <PageHeader title="Audit log" subtitle="Sign-ins, exports, deletions, permission and content changes." />
      <div className="table-wrap"><table className="table">
        <thead><tr><th>When</th><th>User</th><th>Action</th><th>Entity</th><th>Details</th></tr></thead>
        <tbody>{rows.map(({ a, user }) => (
          <tr key={a.id}><td className="whitespace-nowrap text-xs text-ink-muted">{formatDateTime(a.createdAt)}</td><td className="text-xs">{user ?? "—"}</td><td className="text-xs font-semibold">{a.action}</td><td className="text-xs">{a.entity}{a.entityId ? <span className="block font-mono text-[10px] text-ink-muted">{a.entityId}</span> : null}</td><td className="max-w-[420px] break-words font-mono text-[11px] text-ink-soft">{a.details ? JSON.stringify(a.details) : ""}</td></tr>
        ))}</tbody>
      </table></div>
      <Pagination page={page} pages={rows.length === 50 ? page + 1 : page} params={{}} basePath="/admin/audit" />
    </div>
  );
}
