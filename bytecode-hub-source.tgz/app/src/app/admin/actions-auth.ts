"use server";
import { redirect } from "next/navigation";
import { and, eq, ne, sql } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { createSession, destroySession, getCurrentUser, hashPassword, passwordProblems, verifyPassword } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { clientIpHash } from "@/lib/request";
import { audit } from "@/lib/audit";
import type { ActionState } from "@/lib/action";

export async function login(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const email = String(fd.get("email") ?? "").toLowerCase().trim();
  const password = String(fd.get("password") ?? "");
  const next = String(fd.get("next") ?? "");
  if (!email || !password) return { error: "Enter your email and password." };
  const ipHash = await clientIpHash();
  const allowed = (await rateLimit(`login:ip:${ipHash}`, 20, 900)) && (await rateLimit(`login:email:${email}`, 8, 900));
  if (!allowed) return { error: "Too many sign-in attempts. Please wait 15 minutes and try again." };
  const [user] = await db.select().from(t.users).where(sql`lower(${t.users.email}) = ${email}`).limit(1);
  // Always run bcrypt to keep timing similar whether or not the account exists.
  const ok = await verifyPassword(password, user?.passwordHash ?? "$2b$12$g36kz1luHu96lz9nZPDTKeCRDzgAGc19xG2xJNi9okwz1qCdGSthu");
  if (!user || !ok || !user.active) {
    await audit(user?.id ?? null, "login_failed", "user", user?.id, { email });
    return { error: "Incorrect email or password." };
  }
  await createSession(user.id);
  await db.update(t.users).set({ lastLoginAt: new Date() }).where(eq(t.users.id, user.id));
  await audit(user.id, "login", "user", user.id);
  redirect(next.startsWith("/admin") ? next : user.mustChangePassword ? "/admin/account?first=1" : "/admin");
}

export async function logout() {
  const user = await getCurrentUser();
  if (user) await audit(user.id, "logout", "user", user.id);
  await destroySession();
  redirect("/admin/login");
}

export async function changePassword(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const user = await getCurrentUser();
  if (!user) return { error: "Please sign in again." };
  const current = String(fd.get("current") ?? "");
  const next = String(fd.get("next") ?? "");
  const confirm = String(fd.get("confirm") ?? "");
  const [row] = await db.select().from(t.users).where(eq(t.users.id, user.id));
  if (!(await verifyPassword(current, row.passwordHash))) return { error: "Your current password is incorrect." };
  const problem = passwordProblems(next);
  if (problem) return { error: problem };
  if (next !== confirm) return { error: "The new passwords do not match." };
  await db.update(t.users).set({ passwordHash: await hashPassword(next), mustChangePassword: false, updatedAt: new Date() }).where(eq(t.users.id, user.id));
  // Sign out other devices.
  const token = (await import("next/headers")).cookies;
  const raw = (await token()).get("bc_session")?.value;
  if (raw) {
    const { createHash } = await import("crypto");
    await db.delete(t.sessions).where(and(eq(t.sessions.userId, user.id), ne(t.sessions.id, createHash("sha256").update(raw).digest("hex"))));
  }
  await audit(user.id, "change_password", "user", user.id);
  return { ok: true, message: "Password updated. Other devices have been signed out." };
}
