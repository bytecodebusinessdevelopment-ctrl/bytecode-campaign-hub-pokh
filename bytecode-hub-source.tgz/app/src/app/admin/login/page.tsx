import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { Logo } from "@/components/logo";
import { LoginForm } from "./login-form";

export const metadata: Metadata = { title: "Team sign in", robots: { index: false } };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  if (await getCurrentUser()) redirect("/admin");
  const { next } = await searchParams;
  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-navy p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="grid-bg absolute inset-0 opacity-60" aria-hidden />
        <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-teal/30 blur-3xl" aria-hidden />
        <Link href="/" className="relative"><Logo dark /></Link>
        <div className="relative">
          <h1 className="text-4xl font-extrabold text-white">Campaign Hub</h1>
          <p className="mt-4 max-w-md text-white/70">Capture leads during visits, follow up on time, and present our work — from your phone.</p>
        </div>
        <p className="relative text-xs text-white/50">Authorised ByteCode team members only. Activity is logged.</p>
      </div>
      <div className="flex items-center justify-center bg-surface px-5 py-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 lg:hidden"><Logo /></div>
          <h2 className="text-2xl font-extrabold">Sign in</h2>
          <p className="mt-1 text-sm text-ink-muted">Use your individual ByteCode team account.</p>
          <LoginForm next={next ?? ""} />
          <p className="mt-6 text-center text-xs text-ink-muted">Forgot your password? Ask an administrator to reset it.</p>
        </div>
      </div>
    </div>
  );
}
