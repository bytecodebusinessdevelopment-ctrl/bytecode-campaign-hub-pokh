import { NextResponse } from "next/server";
import { and, eq, or, sql } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { assertLeadAccess, getCurrentUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { openFile } from "@/lib/storage";

/** Serves files. Public files (attached to published, public content) are open; everything else requires sign-in. */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return new NextResponse("Not found", { status: 404 });
  const [file] = await db.select().from(t.files).where(eq(t.files.id, id)).limit(1);
  if (!file || file.status !== "ready") return new NextResponse("Not found", { status: 404 });
  if (!file.isPublic) {
    const user = await getCurrentUser();
    if (!user) return new NextResponse("Not found", { status: 404 }); // don't reveal that a private file exists
    // Lead attachments: only people who can see that lead.
    const [att] = await db.select({ leadId: t.leadAttachments.leadId }).from(t.leadAttachments).where(eq(t.leadAttachments.fileId, id)).limit(1);
    if (att) {
      try { await assertLeadAccess(user, att.leadId); } catch { return new NextResponse("Not found", { status: 404 }); }
    }
    // Resources marked "Private": content managers only.
    const [priv] = await db.select({ id: t.resources.id }).from(t.resources).where(and(eq(t.resources.visibility, "private"), or(eq(t.resources.fileId, id), eq(t.resources.previewFileId, id)))).limit(1);
    if (priv && !can(user.role, "manageContent")) return new NextResponse("Not found", { status: 404 });
  }
  const url = new URL(req.url);
  const download = url.searchParams.get("download") === "1";
  const resourceSlug = url.searchParams.get("r");
  if (download && resourceSlug) {
    await db.execute(sql`UPDATE resources SET download_count = download_count + 1 WHERE slug = ${resourceSlug} AND file_id = ${id}`).catch(() => {});
  }
  const out = await openFile(file, download);
  const cache = file.isPublic ? "public, max-age=300, stale-while-revalidate=86400" : "private, no-store";
  if (out.redirect) return NextResponse.redirect(out.redirect, { status: 302, headers: { "Cache-Control": "private, max-age=60" } });
  return new NextResponse(out.stream!, {
    headers: {
      "Content-Type": file.mimeType,
      "Content-Length": String(file.sizeBytes),
      "Content-Disposition": out.disposition,
      "Cache-Control": cache,
      "X-Content-Type-Options": "nosniff",
    },
  });
}
