import { NextResponse, after } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { createLead } from "@/lib/leads";
import { processSyncJobs } from "@/lib/sheets";
import { quickCaptureSchema, flattenErrors } from "@/lib/validation";
import { audit } from "@/lib/audit";
import { safeUrl } from "@/lib/utils";
import { db, t } from "@/lib/db";
import { and, eq } from "drizzle-orm";

/**
 * Quick prospect capture endpoint (JSON). Used by the mobile quick-capture screen, including submissions
 * queued while offline. Idempotent: the client sends a clientRef so retries never create duplicates.
 */
export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Your session has expired. Please sign in again." }, { status: 401 });
  if (!can(user.role, "createLeads")) return NextResponse.json({ error: "Not allowed." }, { status: 403 });
  const body = await req.json().catch(() => null);
  const parsed = quickCaptureSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Please check the form.", fieldErrors: flattenErrors(parsed.error) }, { status: 400 });
  const d = parsed.data;
  const campaignId = typeof body?.campaignId === "string" && /^[0-9a-f-]{36}$/i.test(body.campaignId) ? body.campaignId : null;
  // Prefer the campaign's own source (e.g. "Pokhara physical visit"); otherwise fall back to the requested slug, then "other".
  const [campaignSource] = campaignId ? await db.select({ id: t.leadSources.id }).from(t.leadSources).where(and(eq(t.leadSources.campaignId, campaignId), eq(t.leadSources.active, true))).limit(1) : [];
  const [slugSource] = campaignSource ? [] : await db.select({ id: t.leadSources.id }).from(t.leadSources).where(eq(t.leadSources.slug, typeof body?.sourceSlug === "string" ? body.sourceSlug : "other")).limit(1);
  const visitSource = campaignSource ?? slugSource;
  const lead = await createLead({
    entryType: "quick_capture",
    business: { name: d.businessName, industryId: d.industryId, location: d.location, website: safeUrl(d.website) },
    contact: { fullName: d.contactName, phone: d.phone, whatsapp: d.phone },
    enquiryServiceIds: d.serviceIds,
    initialInterest: d.initialInterest,
    discussionNotes: d.notes,
    priority: d.priority ?? null,
    campaignId,
    sourceId: visitSource?.id ?? null,
    createdBy: user.id,
    assignedTo: user.id,
    clientRef: `quick-${d.clientRef}`,
  });
  if (!lead.existing) {
    await audit(user.id, "create", "lead", lead.id, { via: "quick_capture", leadCode: lead.leadCode });
    after(() => processSyncJobs({ leadIds: [lead.id] }).catch((e) => console.error(e)));
  }
  return NextResponse.json({ ok: true, id: lead.id, leadCode: lead.leadCode, duplicateOf: lead.duplicateOf, existing: lead.existing });
}
