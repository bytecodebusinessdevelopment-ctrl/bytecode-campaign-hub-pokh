import { NextResponse } from "next/server";
import ExcelJS from "exceljs";
import { getCurrentUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { listLeads, type LeadFilters } from "@/lib/lead-queries";
import { audit } from "@/lib/audit";
import { formatDate, nepalToday } from "@/lib/format";
import { siteUrl } from "@/lib/request";

export const dynamic = "force-dynamic";

const COLUMNS = [
  ["Lead ID", "leadCode"], ["Created", "created"], ["Business", "businessName"], ["Industry", "industry"], ["Location", "location"],
  ["Contact person", "contactName"], ["Phone", "phone"], ["WhatsApp", "whatsapp"], ["Email", "email"], ["Website", "website"],
  ["Services", "services"], ["Budget", "budget"], ["Timeline", "timeline"], ["Source", "sourceName"], ["Campaign", "campaignName"],
  ["Status", "statusName"], ["Priority", "priority"], ["Assigned to", "assigneeName"], ["Next action", "nextAction"],
  ["Follow-up date", "followUp"], ["Estimated value (NPR, estimate)", "estimatedValueNpr"], ["Entry type", "entryType"], ["Lead record", "link"],
] as const;

/** Prevent spreadsheet formula injection when values are opened in Excel / Google Sheets. */
const safe = (v: unknown) => {
  const s = v == null ? "" : String(v);
  return /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
};

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Please sign in." }, { status: 401 });
  if (!can(user.role, "exportLeads")) return NextResponse.json({ error: "You do not have permission to export leads." }, { status: 403 });
  const url = new URL(req.url);
  const f = Object.fromEntries(url.searchParams.entries()) as LeadFilters & { format?: string };
  const { rows } = await listLeads(user, f, { all: true });
  const data = rows.map((r) => ({
    ...r,
    created: formatDate(r.createdAt, true),
    followUp: r.nextFollowUpAt ? formatDate(r.nextFollowUpAt, true) : "",
    budget: r.budgetLabel ?? r.budgetCustom ?? "",
    estimatedValueNpr: r.estimatedValueNpr ? Number(r.estimatedValueNpr) : "",
    link: siteUrl(`/admin/leads/${r.id}`),
  })) as Record<string, unknown>[];
  await audit(user.id, "export", "leads", null, { count: rows.length, format: f.format ?? "csv", filters: f });
  const filename = `bytecode-leads-${nepalToday()}`;

  if (f.format === "xlsx") {
    const wb = new ExcelJS.Workbook();
    wb.creator = "ByteCode Campaign Hub";
    const ws = wb.addWorksheet("Leads", { views: [{ state: "frozen", ySplit: 1 }] });
    ws.columns = COLUMNS.map(([header, key]) => ({ header, key, width: Math.max(12, header.length + 4) }));
    data.forEach((d) => ws.addRow(Object.fromEntries(COLUMNS.map(([, k]) => [k, typeof d[k] === "number" ? d[k] : safe(d[k])]))));
    ws.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
    ws.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF17324D" } };
    ws.autoFilter = { from: "A1", to: { row: 1, column: COLUMNS.length } };
    const buf = await wb.xlsx.writeBuffer();
    return new NextResponse(buf as ArrayBuffer, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${filename}.xlsx"`,
        "Cache-Control": "no-store",
      },
    });
  }
  const esc = (v: unknown) => `"${safe(v).replace(/"/g, '""')}"`;
  const csv = [COLUMNS.map(([h]) => esc(h)).join(","), ...data.map((d) => COLUMNS.map(([, k]) => esc(d[k])).join(","))].join("\r\n");
  return new NextResponse(`﻿${csv}`, {
    headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="${filename}.csv"`, "Cache-Control": "no-store" },
  });
}
