import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { initUpload } from "@/lib/storage";
import { rateLimit } from "@/lib/rate-limit";

const schema = z.object({ name: z.string().min(1).max(250), size: z.number().int().positive(), purpose: z.enum(["document", "image", "video", "any"]) });

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Please sign in." }, { status: 401 });
  // Content managers upload content; every team member may attach files (e.g. visiting-card photos) to leads.
  if (!can(user.role, "manageContent") && !can(user.role, "createLeads")) return NextResponse.json({ error: "Not allowed." }, { status: 403 });
  if (!(await rateLimit(`upload:${user.id}`, 120, 3600))) return NextResponse.json({ error: "Too many uploads. Try again later." }, { status: 429 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  try {
    const out = await initUpload({ ...parsed.data, userId: user.id });
    return NextResponse.json(out);
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Upload failed." }, { status: 400 });
  }
}
