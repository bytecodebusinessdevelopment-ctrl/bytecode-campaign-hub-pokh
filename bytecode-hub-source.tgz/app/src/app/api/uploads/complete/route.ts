import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { completeUpload } from "@/lib/storage";

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Please sign in." }, { status: 401 });
  const body = (await req.json().catch(() => null)) as { fileId?: string } | null;
  if (!body?.fileId || !/^[0-9a-f-]{36}$/i.test(body.fileId)) return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  const [file] = await db.select({ uploadedBy: t.files.uploadedBy }).from(t.files).where(eq(t.files.id, body.fileId)).limit(1);
  if (!file || file.uploadedBy !== user.id) return NextResponse.json({ error: "Upload not found." }, { status: 404 });
  try {
    const f = await completeUpload(body.fileId);
    return NextResponse.json({ id: f.id, name: f.originalName, mimeType: f.mimeType, size: f.sizeBytes });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Upload failed." }, { status: 400 });
  }
}
