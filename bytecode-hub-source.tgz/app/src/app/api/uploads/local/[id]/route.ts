import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { FILE_TYPES, extOf, limitBytesFor, verifyUploadToken, writeLocal, driver } from "@/lib/storage";

/** Receives the raw bytes for the "local" storage driver (development / single-server hosting). */
export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (driver === "s3") return NextResponse.json({ error: "Not available" }, { status: 404 });
  const { id } = await params;
  const token = new URL(req.url).searchParams.get("token") ?? "";
  const user = await getCurrentUser();
  if (!user || !verifyUploadToken(id, token)) return NextResponse.json({ error: "Not allowed." }, { status: 403 });
  const [file] = await db.select().from(t.files).where(eq(t.files.id, id)).limit(1);
  if (!file || file.status !== "pending" || file.uploadedBy !== user.id) return NextResponse.json({ error: "Upload not found." }, { status: 404 });
  if (!req.body) return NextResponse.json({ error: "Empty body." }, { status: 400 });
  const info = FILE_TYPES[extOf(file.storageKey)];
  try {
    await writeLocal(file.storageKey, req.body, await limitBytesFor(info.group));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Upload failed." }, { status: 400 });
  }
}
