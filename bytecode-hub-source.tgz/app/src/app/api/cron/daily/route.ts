import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/lib/db";
import { cronAuthorized } from "@/lib/cron";
import { sendDailyFollowUpDigest } from "@/lib/notify";
import { cleanupExpiredSessions } from "@/lib/auth";
import { deleteStoredFile } from "@/lib/storage";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Daily housekeeping: follow-up digest emails, expired sessions, stale rate-limit rows and abandoned uploads. */
export async function GET(req: Request) {
  if (!cronAuthorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const digest = await sendDailyFollowUpDigest();
  await cleanupExpiredSessions();
  await db.execute(sql`DELETE FROM rate_limits WHERE window_start < now() - interval '2 days'`);
  const stale = await db.execute<{ id: string; storage_key: string; driver: string }>(sql`DELETE FROM files WHERE status = 'pending' AND created_at < now() - interval '1 day' RETURNING id, storage_key, driver`);
  for (const f of stale) await deleteStoredFile(f.storage_key, f.driver).catch(() => {});
  return NextResponse.json({ digest, staleUploadsRemoved: stale.length });
}
