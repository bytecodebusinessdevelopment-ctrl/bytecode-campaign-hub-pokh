import { NextResponse } from "next/server";
import { cronAuthorized } from "@/lib/cron";
import { processSyncJobs } from "@/lib/sheets";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Retries pending Google Sheets sync jobs (backstop — new leads are synced immediately after creation). */
export async function GET(req: Request) {
  if (!cronAuthorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const result = await processSyncJobs({ limit: 50 });
  return NextResponse.json(result);
}
