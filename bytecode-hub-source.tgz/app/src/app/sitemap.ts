import type { MetadataRoute } from "next";
import { getPublishedServices, getPublishedProjects, getPublicResources, getPublicDemos } from "@/lib/public-data";
import { db, t } from "@/lib/db";
import { eq } from "drizzle-orm";
import { siteUrl } from "@/lib/request";

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const u = (p: string) => siteUrl(p);
  const statics = ["/", "/services", "/packages", "/portfolio", "/showcase", "/resources", "/about", "/contact", "/request-proposal", "/privacy", "/terms"];
  try {
    const [services, projects, resources, demos, campaigns] = await Promise.all([
      getPublishedServices(), getPublishedProjects(), getPublicResources(), getPublicDemos(),
      db.select({ slug: t.campaigns.slug }).from(t.campaigns).where(eq(t.campaigns.status, "active")),
    ]);
    return [
      ...statics.map((p) => ({ url: u(p), changeFrequency: "weekly" as const, priority: p === "/" ? 1 : 0.7 })),
      ...services.map((s) => ({ url: u(`/services/${s.slug}`), lastModified: s.updatedAt, priority: 0.8 })),
      ...projects.map((p) => ({ url: u(`/portfolio/${p.slug}`), lastModified: p.updatedAt, priority: 0.6 })),
      ...resources.map((r) => ({ url: u(`/resources/${r.slug}`), lastModified: r.updatedAt, priority: 0.4 })),
      ...demos.map((d) => ({ url: u(`/showcase/${d.id}`), lastModified: d.updatedAt, priority: 0.4 })),
      ...campaigns.map((c) => ({ url: u(`/c/${c.slug}`), priority: 0.6 })),
    ];
  } catch {
    return statics.map((p) => ({ url: u(p) }));
  }
}
