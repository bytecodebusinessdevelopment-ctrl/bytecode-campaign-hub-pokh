import Link from "next/link";
import "./globals.css";

export default function NotFound() {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center bg-white px-6 text-center">
      <p className="font-display text-7xl font-extrabold text-brand/20">404</p>
      <h1 className="mt-2 text-3xl font-extrabold text-navy">Page not found</h1>
      <p className="mt-3 max-w-md text-ink-soft">The page you&apos;re looking for doesn&apos;t exist or has moved.</p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Link href="/" className="btn-primary">Go to home</Link>
        <Link href="/services" className="btn-outline">Our services</Link>
        <Link href="/contact" className="btn-outline">Contact</Link>
      </div>
    </div>
  );
}
