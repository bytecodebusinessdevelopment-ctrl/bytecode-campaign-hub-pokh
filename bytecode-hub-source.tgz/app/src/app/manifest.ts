import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "ByteCode Campaign Hub",
    short_name: "ByteCode",
    description: "ByteCode Developers — services, portfolio, resources and field lead capture.",
    start_url: "/admin/leads/quick",
    scope: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#17324D",
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
      { src: "/icons/icon-512-maskable.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
    shortcuts: [
      { name: "Quick capture", url: "/admin/leads/quick" },
      { name: "Follow-ups", url: "/admin/follow-ups" },
    ],
  };
}
