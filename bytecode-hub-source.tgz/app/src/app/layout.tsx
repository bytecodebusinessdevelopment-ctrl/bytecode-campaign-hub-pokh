import type { Metadata, Viewport } from "next";
import "./globals.css";
import { getSettings, hexToRgbChannels } from "@/lib/settings";
import { siteUrl } from "@/lib/request";

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  return {
    metadataBase: new URL(siteUrl()),
    title: { default: s.seoTitle, template: `%s | ${s.companyName}` },
    description: s.seoDescription,
    applicationName: `${s.shortName} Campaign Hub`,
    openGraph: { type: "website", siteName: s.companyName, title: s.seoTitle, description: s.seoDescription, locale: "en_NP", images: ["/og-image.png"] },
    twitter: { card: "summary_large_image", title: s.seoTitle, description: s.seoDescription, images: ["/og-image.png"] },
    icons: { icon: "/icon.svg", apple: "/icons/apple-touch-icon.png" },
    manifest: "/manifest.webmanifest",
  };
}

export const viewport: Viewport = { themeColor: "#17324D", width: "device-width", initialScale: 1 };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const s = await getSettings();
  const vars = [
    ["--brand-navy", hexToRgbChannels(s.colors.navy)],
    ["--brand-blue", hexToRgbChannels(s.colors.blue)],
    ["--brand-teal", hexToRgbChannels(s.colors.teal)],
  ].filter(([, v]) => v).map(([k, v]) => `${k}:${v}`).join(";");
  return (
    <html lang="en">
      <head>{vars && <style>{`:root{${vars}}`}</style>}</head>
      <body>{children}</body>
    </html>
  );
}
