import "server-only";
import { createHmac, randomUUID, timingSafeEqual } from "crypto";
import { promises as fs, createReadStream } from "fs";
import path from "path";
import { Readable } from "stream";
import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand, HeadObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { inArray, sql } from "drizzle-orm";
import { db, t } from "@/lib/db";

export type UploadPurpose = "document" | "image" | "video" | "any";

type TypeInfo = { mime: string; group: "document" | "image" | "video"; magic: (b: Buffer) => boolean };

const isZip = (b: Buffer) => b.length >= 4 && b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04;
const isOle = (b: Buffer) => b.length >= 4 && b[0] === 0xd0 && b[1] === 0xcf && b[2] === 0x11 && b[3] === 0xe0;
const isFtyp = (b: Buffer) => b.length >= 8 && b.subarray(4, 8).toString("latin1") === "ftyp";

/** Allow-list of file types. Anything else is rejected. SVG/HTML are deliberately excluded (script injection risk). */
export const FILE_TYPES: Record<string, TypeInfo> = {
  pdf: { mime: "application/pdf", group: "document", magic: (b) => b.subarray(0, 4).toString("latin1") === "%PDF" },
  doc: { mime: "application/msword", group: "document", magic: isOle },
  docx: { mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", group: "document", magic: isZip },
  ppt: { mime: "application/vnd.ms-powerpoint", group: "document", magic: isOle },
  pptx: { mime: "application/vnd.openxmlformats-officedocument.presentationml.presentation", group: "document", magic: isZip },
  xls: { mime: "application/vnd.ms-excel", group: "document", magic: isOle },
  xlsx: { mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", group: "document", magic: isZip },
  jpg: { mime: "image/jpeg", group: "image", magic: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  jpeg: { mime: "image/jpeg", group: "image", magic: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  png: { mime: "image/png", group: "image", magic: (b) => b[0] === 0x89 && b.subarray(1, 4).toString("latin1") === "PNG" },
  webp: { mime: "image/webp", group: "image", magic: (b) => b.subarray(0, 4).toString("latin1") === "RIFF" && b.subarray(8, 12).toString("latin1") === "WEBP" },
  mp4: { mime: "video/mp4", group: "video", magic: isFtyp },
  mov: { mime: "video/quicktime", group: "video", magic: isFtyp },
  webm: { mime: "video/webm", group: "video", magic: (b) => b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3 },
};

export function extOf(name: string) {
  return path.extname(name).replace(".", "").toLowerCase();
}

export function acceptFor(purpose: UploadPurpose) {
  return Object.entries(FILE_TYPES)
    .filter(([, v]) => purpose === "any" || v.group === purpose)
    .map(([k]) => `.${k}`)
    .join(",");
}

export function safeFileName(name: string) {
  const ext = extOf(name);
  const base = path.basename(name, path.extname(name)).replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/-+/g, "-").slice(0, 80) || "file";
  return ext ? `${base}.${ext}` : base;
}

/* ───────── drivers ───────── */
/**
 * "local" — files on disk (development / single VPS)
 * "s3"    — S3-compatible bucket (Supabase Storage, R2, AWS) — recommended at scale
 * "db"    — file bytes stored in Postgres (`file_blobs`); zero extra setup, ideal for a first launch on
 *           hosts with temporary disks (Render/Vercel). Upload size is capped at DB_STORAGE_MAX_MB (default 20).
 */
export const driver = (process.env.STORAGE_DRIVER ?? "local") as "local" | "s3" | "db";
const localDir = path.resolve(process.env.STORAGE_LOCAL_DIR ?? "./storage");

let _s3: S3Client | null = null;
function s3() {
  if (!_s3) {
    _s3 = new S3Client({
      region: process.env.S3_REGION ?? "auto",
      endpoint: process.env.S3_ENDPOINT || undefined,
      forcePathStyle: process.env.S3_FORCE_PATH_STYLE !== "false",
      credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID ?? "", secretAccessKey: process.env.S3_SECRET_ACCESS_KEY ?? "" },
    });
  }
  return _s3;
}
const bucket = () => process.env.S3_BUCKET ?? "";

function localPath(key: string) {
  const p = path.resolve(localDir, key);
  if (!p.startsWith(localDir + path.sep)) throw new Error("Invalid storage key");
  return p;
}

export function uploadToken(fileId: string) {
  return createHmac("sha256", process.env.APP_SECRET ?? "dev").update(`upload:${fileId}`).digest("base64url");
}
export function verifyUploadToken(fileId: string, token: string) {
  const a = Buffer.from(uploadToken(fileId));
  const b = Buffer.from(token);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function limitBytesFor(group: TypeInfo["group"]) {
  const { getSettings } = await import("@/lib/settings");
  const s = await getSettings();
  const mb = driver === "db" ? Math.min(s.uploadLimitsMb[group], Number(process.env.DB_STORAGE_MAX_MB ?? 20)) : s.uploadLimitsMb[group];
  return mb * 1024 * 1024;
}

/** Step 1: validate metadata and reserve a file record; returns where the browser should send the bytes. */
export async function initUpload(opts: { name: string; size: number; purpose: UploadPurpose; userId: string }) {
  const ext = extOf(opts.name);
  const info = FILE_TYPES[ext];
  if (!info) throw new Error(`File type .${ext || "?"} is not allowed.`);
  if (opts.purpose !== "any" && info.group !== opts.purpose) throw new Error(`Please upload a ${opts.purpose} file.`);
  const limit = await limitBytesFor(info.group);
  if (opts.size <= 0) throw new Error("The file is empty.");
  if (opts.size > limit) throw new Error(`File is too large. The limit for ${info.group}s is ${Math.round(limit / 1048576)} MB.`);

  const now = new Date();
  const key = `${now.getUTCFullYear()}/${String(now.getUTCMonth() + 1).padStart(2, "0")}/${randomUUID()}-${safeFileName(opts.name)}`;
  const [row] = await db
    .insert(t.files)
    .values({ storageKey: key, driver, originalName: opts.name.slice(0, 200), mimeType: info.mime, sizeBytes: opts.size, uploadedBy: opts.userId })
    .returning({ id: t.files.id });

  if (driver === "s3") {
    const url = await getSignedUrl(s3(), new PutObjectCommand({ Bucket: bucket(), Key: key, ContentType: info.mime }), { expiresIn: 900 });
    return { fileId: row.id, uploadUrl: url, method: "PUT" as const, headers: { "Content-Type": info.mime } };
  }
  return {
    fileId: row.id,
    uploadUrl: `/api/uploads/local/${row.id}?token=${uploadToken(row.id)}`,
    method: "PUT" as const,
    headers: { "Content-Type": info.mime },
  };
}

/** Local driver: write the uploaded body to disk, enforcing the size limit while streaming. */
export async function writeLocal(key: string, body: ReadableStream<Uint8Array>, maxBytes: number) {
  if (driver === "db") {
    const chunks: Uint8Array[] = [];
    let size = 0;
    const reader = body.getReader();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) throw new Error("File exceeds the upload limit.");
      chunks.push(value);
    }
    const data = Buffer.concat(chunks);
    await db.insert(t.fileBlobs).values({ storageKey: key, data }).onConflictDoUpdate({ target: t.fileBlobs.storageKey, set: { data } });
    return size;
  }
  const p = localPath(key);
  await fs.mkdir(path.dirname(p), { recursive: true });
  const handle = await fs.open(p, "w");
  let total = 0;
  try {
    const reader = body.getReader();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) throw new Error("File exceeds the upload limit.");
      await handle.write(value);
    }
  } catch (e) {
    await handle.close();
    await fs.rm(p, { force: true });
    throw e;
  }
  await handle.close();
  return total;
}

async function readHead(key: string, fileDriver: string): Promise<{ head: Buffer; size: number } | null> {
  if (fileDriver === "s3") {
    try {
      const h = await s3().send(new HeadObjectCommand({ Bucket: bucket(), Key: key }));
      const obj = await s3().send(new GetObjectCommand({ Bucket: bucket(), Key: key, Range: "bytes=0-31" }));
      const bytes = Buffer.from(await obj.Body!.transformToByteArray());
      return { head: bytes, size: Number(h.ContentLength ?? 0) };
    } catch {
      return null;
    }
  }
  if (fileDriver === "db") {
    const rows = await db.execute<{ head: Buffer; size: number }>(sql`SELECT substring(data from 1 for 32) AS head, octet_length(data) AS size FROM file_blobs WHERE storage_key = ${key}`);
    return rows[0] ? { head: Buffer.from(rows[0].head), size: Number(rows[0].size) } : null;
  }
  try {
    const p = localPath(key);
    const stat = await fs.stat(p);
    const fh = await fs.open(p, "r");
    const buf = Buffer.alloc(32);
    await fh.read(buf, 0, 32, 0);
    await fh.close();
    return { head: buf, size: stat.size };
  } catch {
    return null;
  }
}

/** Step 2: verify the uploaded bytes really are the declared type and within limits, then mark ready. */
export async function completeUpload(fileId: string) {
  const [file] = await db.select().from(t.files).where(sql`${t.files.id} = ${fileId}`).limit(1);
  if (!file) throw new Error("Upload not found.");
  if (file.status === "ready") return file;
  const info = FILE_TYPES[extOf(file.storageKey)];
  const head = await readHead(file.storageKey, file.driver);
  const limit = info ? await limitBytesFor(info.group) : 0;
  if (!info || !head || head.size === 0 || head.size > limit || !info.magic(head.head)) {
    await deleteStoredFile(file.storageKey, file.driver).catch(() => {});
    await db.delete(t.files).where(sql`${t.files.id} = ${fileId}`);
    throw new Error("The uploaded file failed validation (wrong type, empty or too large).");
  }
  const [updated] = await db
    .update(t.files)
    .set({ status: "ready", sizeBytes: head.size })
    .where(sql`${t.files.id} = ${fileId}`)
    .returning();
  return updated;
}

export async function deleteStoredFile(key: string, fileDriver: string) {
  if (fileDriver === "s3") await s3().send(new DeleteObjectCommand({ Bucket: bucket(), Key: key }));
  else if (fileDriver === "db") await db.delete(t.fileBlobs).where(sql`${t.fileBlobs.storageKey} = ${key}`);
  else await fs.rm(localPath(key), { force: true });
}

export async function deleteFile(fileId: string) {
  const [file] = await db.select().from(t.files).where(sql`${t.files.id} = ${fileId}`).limit(1);
  if (!file) return;
  await deleteStoredFile(file.storageKey, file.driver).catch((e) => console.error("[storage] delete failed", e));
  await db.delete(t.files).where(sql`${t.files.id} = ${fileId}`);
}

/** Returns either a redirect URL (S3, short-lived signed URL) or a Node stream (local). */
export async function openFile(file: typeof t.files.$inferSelect, download: boolean) {
  const disposition = `${download ? "attachment" : "inline"}; filename="${safeFileName(file.originalName)}"`;
  if (file.driver === "s3") {
    const url = await getSignedUrl(
      s3(),
      new GetObjectCommand({ Bucket: bucket(), Key: file.storageKey, ResponseContentDisposition: disposition, ResponseContentType: file.mimeType }),
      { expiresIn: 600 },
    );
    return { redirect: url, stream: null, disposition } as const;
  }
  if (file.driver === "db") {
    const [blob] = await db.select({ data: t.fileBlobs.data }).from(t.fileBlobs).where(sql`${t.fileBlobs.storageKey} = ${file.storageKey}`).limit(1);
    if (!blob) throw new Error("File content missing");
    const buf = Buffer.from(blob.data);
    const stream = new ReadableStream<Uint8Array>({ start(c) { c.enqueue(new Uint8Array(buf)); c.close(); } });
    return { redirect: null, stream, disposition } as const;
  }
  const p = localPath(file.storageKey);
  const stream = Readable.toWeb(createReadStream(p)) as ReadableStream;
  return { redirect: null, stream, disposition } as const;
}

/**
 * Recompute whether files may be served publicly. A file is public only if it belongs to
 * published+public content (resource, project cover/media, demo preview, site logo).
 */
export async function refreshFilePublicity(fileIds: (string | null | undefined)[]) {
  const ids = [...new Set(fileIds.filter(Boolean))] as string[];
  if (!ids.length) return;
  await db.execute(sql`
    UPDATE files f SET is_public = (
      EXISTS (SELECT 1 FROM resources r WHERE (r.file_id = f.id OR r.preview_file_id = f.id) AND r.published AND r.visibility = 'public')
      OR EXISTS (SELECT 1 FROM portfolio_projects p WHERE p.cover_file_id = f.id AND p.status = 'published')
      OR EXISTS (SELECT 1 FROM project_media m JOIN portfolio_projects p ON p.id = m.project_id WHERE m.file_id = f.id AND p.status = 'published')
      OR EXISTS (SELECT 1 FROM demos d WHERE d.preview_file_id = f.id AND d.visibility = 'public')
      OR EXISTS (SELECT 1 FROM settings s WHERE s.key IN ('logoFileId','logoDarkFileId') AND s.value #>> '{}' = f.id::text)
    )
    WHERE f.id IN ${sql.raw(`(${ids.map((i) => `'${i.replace(/[^0-9a-f-]/gi, "")}'`).join(",")})`)}`);
}

export async function getFiles(ids: (string | null | undefined)[]) {
  const list = ids.filter(Boolean) as string[];
  if (!list.length) return [];
  return db.select().from(t.files).where(inArray(t.files.id, list));
}

export function fileUrl(fileId: string | null | undefined, download = false) {
  if (!fileId) return null;
  return `/api/files/${fileId}${download ? "?download=1" : ""}`;
}
