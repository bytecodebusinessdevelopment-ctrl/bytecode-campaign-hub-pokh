import "server-only";
import { cache } from "react";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { createHash, randomBytes } from "crypto";
import bcrypt from "bcryptjs";
import { and, eq, gt, or, sql, type SQL } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { can, type Permission, type Role } from "@/lib/permissions";

export const SESSION_COOKIE = "bc_session";
const SESSION_DAYS = 30;

export type SessionUser = { id: string; name: string; email: string; role: Role; mustChangePassword: boolean };

const sha256 = (s: string) => createHash("sha256").update(s).digest("hex");

export async function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

export function passwordProblems(password: string): string | null {
  if (password.length < 10) return "Password must be at least 10 characters.";
  if (!/[a-z]/i.test(password) || !/\d/.test(password)) return "Password must contain letters and numbers.";
  return null;
}

export async function createSession(userId: string) {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400000);
  const ua = (await headers()).get("user-agent")?.slice(0, 250) ?? null;
  await db.insert(t.sessions).values({ id: sha256(token), userId, expiresAt, userAgent: ua });
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await db.delete(t.sessions).where(eq(t.sessions.id, sha256(token)));
  jar.delete(SESSION_COOKIE);
}

export const getCurrentUser = cache(async (): Promise<SessionUser | null> => {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({
      id: t.users.id, name: t.users.name, email: t.users.email, role: t.users.role,
      active: t.users.active, mustChangePassword: t.users.mustChangePassword, expiresAt: t.sessions.expiresAt,
    })
    .from(t.sessions)
    .innerJoin(t.users, eq(t.users.id, t.sessions.userId))
    .where(and(eq(t.sessions.id, sha256(token)), gt(t.sessions.expiresAt, new Date())))
    .limit(1);
  const row = rows[0];
  if (!row || !row.active) return null;
  // Sliding expiry: extend sessions that are more than halfway through their lifetime.
  if (row.expiresAt.getTime() - Date.now() < (SESSION_DAYS / 2) * 86400000) {
    await db.update(t.sessions).set({ expiresAt: new Date(Date.now() + SESSION_DAYS * 86400000) }).where(eq(t.sessions.id, sha256(token)));
  }
  return { id: row.id, name: row.name, email: row.email, role: row.role, mustChangePassword: row.mustChangePassword };
});

export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/admin/login");
  return user;
}

export class ForbiddenError extends Error {
  constructor(message = "You do not have permission to do that.") {
    super(message);
  }
}

/** For server actions & route handlers: throws if the user lacks the permission. */
export async function requirePermission(permission: Permission): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) throw new ForbiddenError("Please sign in again.");
  if (!can(user.role, permission)) throw new ForbiddenError();
  return user;
}

/** For pages: redirects to the dashboard if the user lacks the permission. */
export async function requirePagePermission(permission: Permission): Promise<SessionUser> {
  const user = await requireUser();
  if (!can(user.role, permission)) redirect("/admin?denied=1");
  return user;
}

/** SQL condition restricting which leads a user can see / edit. */
export function leadScope(user: SessionUser): SQL | undefined {
  if (can(user.role, "viewAllLeads")) return undefined;
  return or(eq(t.leads.assignedTo, user.id), eq(t.leads.createdBy, user.id));
}

export async function assertLeadAccess(user: SessionUser, leadId: string) {
  const scope = leadScope(user);
  const rows = await db
    .select({ id: t.leads.id })
    .from(t.leads)
    .where(scope ? and(eq(t.leads.id, leadId), scope) : eq(t.leads.id, leadId))
    .limit(1);
  if (!rows[0]) throw new ForbiddenError("Lead not found or you do not have access to it.");
}

export async function cleanupExpiredSessions() {
  await db.delete(t.sessions).where(sql`${t.sessions.expiresAt} < now()`);
}
