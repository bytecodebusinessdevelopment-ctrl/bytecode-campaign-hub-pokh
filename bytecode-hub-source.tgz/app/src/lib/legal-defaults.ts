/** Default legal text. Editable in Admin → Settings → Legal pages. MUST be reviewed by ByteCode's legal advisor before launch. */
export function defaultPrivacyPolicy(company: string, email: string, address: string, retentionMonths: number) {
  return `${company} ("we", "us") respects your privacy. This policy explains what personal information this website collects, why, and how it is protected, in line with Nepal's Privacy Act, 2075 (2018).

## Information we collect
When you submit an enquiry, request a proposal or contact us, we collect the details you provide: your name, designation, business name and details, phone, WhatsApp, email, website and social media links, your requirements, budget range, timeline and preferences.
We also record basic technical information to protect the website from spam and abuse (a one-way hashed version of your IP address — never the address itself) and, if you arrived from an advertisement or link, the campaign it came from.
If you accept analytics cookies, Google Analytics and/or Meta (Facebook) Pixel may collect anonymous usage data. If you decline, these tools are not loaded.

## Why we use it
• To respond to your enquiry and prepare proposals and quotations.
• To follow up with you about the services you asked about, using the contact method you prefer.
• To understand which of our campaigns and services are of interest (aggregated reporting).
We do not sell or rent your personal information.

## Where it is stored
Enquiries are stored in our secure database and summarised in an internal lead register (Google Sheets) that only authorised ${company} staff can access. Access is restricted by role and every important change is logged.

## How long we keep it
We keep enquiry records for up to ${retentionMonths} months after our last contact with you, unless we enter into a contract with you, in which case records are kept as required for that relationship and by law.

## Your rights
You may ask us to access, correct or delete the personal information we hold about you, or to stop contacting you, at any time. Email ${email || "us"}${address ? ` or write to us at ${address}` : ""}.

## Changes
We may update this policy. The latest version is always available on this page.`;
}

export function defaultTerms(company: string, email: string) {
  return `By using this website you agree to these terms.

## Use of the website
The content on this website is provided for general information about ${company} and our services. Package descriptions, timelines and prices shown are indicative; the scope, price and delivery period of any project are confirmed in a written proposal or agreement.

## Intellectual property
Unless stated otherwise, the content, design and materials on this website belong to ${company} or are used with permission. Client names, logos and project materials are shown with the client's permission and remain the property of their owners. Downloadable documents may be used to evaluate our services but may not be republished without permission.

## External links and demonstrations
This website links to and embeds live websites, demonstrations and prototypes, some hosted by third parties. We are not responsible for the content or availability of third-party websites.

## Enquiries
Submitting an enquiry does not create a contract. We will respond to enquiries as soon as reasonably possible.

## Liability
We work to keep this website accurate and available, but it is provided "as is". To the extent permitted by law, ${company} is not liable for losses arising from the use of this website.

## Contact
Questions about these terms: ${email || "contact us via the Contact page"}.

These terms are governed by the laws of Nepal.`;
}
