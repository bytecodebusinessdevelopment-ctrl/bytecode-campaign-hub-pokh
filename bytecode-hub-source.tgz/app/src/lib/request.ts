import "server-only";
import { headers } from "next/headers";
import { createHash } from "crypto";

export async function clientIp() {
  const h = await headers();
  return (h.get("x-forwarded-for")?.split(",")[0] ?? h.get("x-real-ip") ?? "0.0.0.0").trim();
}

/** One-way hash of the IP address — we never store raw IPs (privacy by design). */
export function hashIp(ip: string) {
  return createHash("sha256").update(`${process.env.APP_SECRET ?? ""}:${ip}`).digest("hex").slice(0, 32);
}

export async function clientIpHash() {
  return hashIp(await clientIp());
}

export function siteUrl(path = "") {
  const base = (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, "");
  return `${base}${path}`;
}
