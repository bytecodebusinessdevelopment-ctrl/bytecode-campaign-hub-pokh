import "server-only";
import { cache } from "react";
import { and, asc, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { db, t } from "@/lib/db";

/** Data access for the public website. Only published + public content is ever returned here. */

export const getPublishedServices = cache(async () =>
  db.select().from(t.services).where(eq(t.services.published, true)).orderBy(asc(t.services.sortOrder)),
);

export async function getServiceBySlug(slug: string) {
  return db.query.services.findFirst({
    where: and(eq(t.services.slug, slug), eq(t.services.published, true)),
    with: { packages: { where: eq(t.packages.published, true), orderBy: asc(t.packages.sortOrder) } },
  });
}

export async function getPublishedPackages() {
  return db
    .select({ pkg: t.packages, service: { name: t.services.name, slug: t.services.slug } })
    .from(t.packages)
    .innerJoin(t.services, eq(t.services.id, t.packages.serviceId))
    .where(and(eq(t.packages.published, true), eq(t.services.published, true)))
    .orderBy(asc(t.services.sortOrder), asc(t.packages.sortOrder));
}

export const getIndustries = cache(async () => db.select().from(t.industries).where(eq(t.industries.active, true)).orderBy(asc(t.industries.sortOrder)));
export const getProjectTypes = cache(async () => db.select().from(t.projectTypes).where(eq(t.projectTypes.active, true)).orderBy(asc(t.projectTypes.sortOrder)));
export const getResourceCategories = cache(async () => db.select().from(t.resourceCategories).where(eq(t.resourceCategories.active, true)).orderBy(asc(t.resourceCategories.sortOrder)));

export async function getPublishedProjects(f: { industry?: string; type?: string; service?: string; featured?: boolean; limit?: number } = {}) {
  const conds = [eq(t.portfolioProjects.status, "published")];
  if (f.featured) conds.push(eq(t.portfolioProjects.featured, true));
  if (f.industry) conds.push(sql`${t.portfolioProjects.industryId} = (SELECT id FROM industries WHERE slug = ${f.industry})`);
  if (f.type) conds.push(sql`${t.portfolioProjects.projectTypeId} = (SELECT id FROM project_types WHERE slug = ${f.type})`);
  if (f.service) conds.push(sql`${t.portfolioProjects.id} IN (SELECT ps.project_id FROM project_services ps JOIN services s ON s.id = ps.service_id WHERE s.slug = ${f.service})`);
  return db.query.portfolioProjects.findMany({
    where: and(...conds),
    with: { industry: true, projectType: true },
    orderBy: [desc(t.portfolioProjects.featured), asc(t.portfolioProjects.sortOrder), desc(t.portfolioProjects.publishedAt)],
    limit: f.limit,
  });
}

export async function getProjectBySlug(slug: string) {
  return db.query.portfolioProjects.findFirst({
    where: and(eq(t.portfolioProjects.slug, slug), eq(t.portfolioProjects.status, "published")),
    with: {
      industry: true,
      projectType: true,
      media: { orderBy: asc(t.projectMedia.sortOrder) },
      services: { with: { service: true } },
      demos: { where: eq(t.demos.visibility, "public"), orderBy: asc(t.demos.sortOrder) },
      resources: { with: { resource: { with: { category: true, file: true } } } },
    },
  });
}

export async function getPublicDemos(f: { standaloneOnly?: boolean; featured?: boolean; limit?: number } = {}) {
  const conds = [eq(t.demos.visibility, "public"), sql`${t.demos.status} <> 'archived'`];
  if (f.featured) conds.push(eq(t.demos.featured, true));
  return db.query.demos.findMany({
    where: and(...conds),
    with: { industry: true, project: { columns: { slug: true, title: true, status: true } } },
    orderBy: [desc(t.demos.featured), asc(t.demos.sortOrder)],
    limit: f.limit,
  });
}

export async function getDemo(id: string) {
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null;
  return db.query.demos.findFirst({ where: and(eq(t.demos.id, id), eq(t.demos.visibility, "public")), with: { industry: true, project: true } });
}

export async function getPublicResources(f: { q?: string; category?: string; industry?: string; service?: string; type?: string; featured?: boolean; limit?: number; campaignId?: string; includeInternal?: boolean } = {}) {
  const conds = [eq(t.resources.published, true)];
  conds.push(f.includeInternal ? inArray(t.resources.visibility, ["public", "internal"]) : eq(t.resources.visibility, "public"));
  if (f.featured) conds.push(eq(t.resources.featured, true));
  if (f.q) conds.push(or(ilike(t.resources.title, `%${f.q}%`), ilike(t.resources.description, `%${f.q}%`))!);
  if (f.category) conds.push(sql`${t.resources.categoryId} = (SELECT id FROM resource_categories WHERE slug = ${f.category})`);
  if (f.industry) conds.push(sql`${t.resources.industryId} = (SELECT id FROM industries WHERE slug = ${f.industry})`);
  if (f.service) conds.push(sql`${t.resources.id} IN (SELECT rs.resource_id FROM resource_services rs JOIN services s ON s.id = rs.service_id WHERE s.slug = ${f.service})`);
  if (f.campaignId) conds.push(sql`${t.resources.id} IN (SELECT resource_id FROM campaign_resources WHERE campaign_id = ${f.campaignId})`);
  if (f.type) {
    const map: Record<string, string> = {
      pdf: "application/pdf", word: "%wordprocessing%|application/msword", powerpoint: "%presentation%|application/vnd.ms-powerpoint",
      excel: "%spreadsheet%|application/vnd.ms-excel", image: "image/%",
    };
    if (f.type === "video") {
      conds.push(or(eq(t.resources.kind, "video_link"), sql`${t.resources.fileId} IN (SELECT id FROM files WHERE mime_type LIKE 'video/%')`)!);
    } else if (map[f.type]) {
      const likes = map[f.type].split("|");
      conds.push(sql`${t.resources.fileId} IN (SELECT id FROM files WHERE ${sql.join(likes.map((l) => sql`mime_type LIKE ${l}`), sql` OR `)})`);
    } else if (f.type === "link") {
      conds.push(inArray(t.resources.kind, ["link", "website", "vercel", "figma"]));
    }
  }
  return db.query.resources.findMany({
    where: and(...conds),
    with: { category: true, industry: true, file: true, services: { with: { service: { columns: { name: true, slug: true } } } } },
    orderBy: [desc(t.resources.featured), asc(t.resources.sortOrder), desc(t.resources.createdAt)],
    limit: f.limit,
  });
}

export async function getResourceBySlug(slug: string, includeInternal = false) {
  return db.query.resources.findFirst({
    where: and(
      eq(t.resources.slug, slug),
      eq(t.resources.published, true),
      includeInternal ? inArray(t.resources.visibility, ["public", "internal"]) : eq(t.resources.visibility, "public"),
    ),
    with: {
      category: true, industry: true, file: true,
      services: { with: { service: true } },
      projects: { with: { project: { columns: { slug: true, title: true, status: true } } } },
    },
  });
}

export async function getPublishedTestimonials(limit = 6) {
  return db.select().from(t.testimonials).where(and(eq(t.testimonials.published, true), eq(t.testimonials.consentConfirmed, true))).orderBy(asc(t.testimonials.sortOrder)).limit(limit);
}

export async function getCampaignBySlug(slug: string) {
  const rows = await db.select().from(t.campaigns).where(and(eq(t.campaigns.slug, slug), inArray(t.campaigns.status, ["active", "draft", "completed"]))).limit(1);
  return rows[0] ?? null;
}

export async function getEnquiryOptions() {
  const [services, industries, budgets] = await Promise.all([
    db.select({ id: t.enquiryServices.id, key: t.enquiryServices.key, label: t.enquiryServices.label }).from(t.enquiryServices).where(eq(t.enquiryServices.active, true)).orderBy(asc(t.enquiryServices.sortOrder)),
    getIndustries(),
    db.select({ id: t.budgetRanges.id, label: t.budgetRanges.label }).from(t.budgetRanges).where(eq(t.budgetRanges.active, true)).orderBy(asc(t.budgetRanges.sortOrder)),
  ]);
  return { services, industries: industries.map((i) => ({ id: i.id, name: i.name })), budgets };
}

export function resourceExt(r: { file?: { storageKey: string } | null }) {
  const m = /\.([a-z0-9]+)$/i.exec(r.file?.storageKey ?? "");
  return m ? m[1].toLowerCase() : null;
}
