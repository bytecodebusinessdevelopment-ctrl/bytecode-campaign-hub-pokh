import "server-only";
import nodemailer, { type Transporter } from "nodemailer";

let transporter: Transporter | null = null;

export function mailConfigured() {
  return Boolean(process.env.SMTP_HOST);
}

function getTransport() {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT ?? 587),
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD } : undefined,
    });
  }
  return transporter;
}

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

export function emailLayout(title: string, paragraphs: string[], cta?: { label: string; url: string }) {
  return `<!doctype html><html><body style="margin:0;background:#f4f7fa;font-family:Arial,Helvetica,sans-serif;color:#17324D">
  <table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px">
  <table width="560" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:12px;overflow:hidden">
  <tr><td style="background:#17324D;color:#fff;padding:18px 24px;font-weight:bold;font-size:16px">ByteCode Developers</td></tr>
  <tr><td style="padding:24px"><h1 style="font-size:20px;margin:0 0 12px">${esc(title)}</h1>
  ${paragraphs.map((p) => `<p style="font-size:14px;line-height:1.6;margin:0 0 10px;white-space:pre-line">${esc(p)}</p>`).join("")}
  ${cta ? `<p style="margin:20px 0 0"><a href="${esc(cta.url)}" style="background:#2878A8;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none;font-size:14px">${esc(cta.label)}</a></p>` : ""}
  </td></tr></table></td></tr></table></body></html>`;
}

export async function sendMail(opts: { to: string | string[]; subject: string; html: string; text?: string; replyTo?: string }) {
  const to = Array.isArray(opts.to) ? opts.to.filter(Boolean) : [opts.to];
  if (!to.length) return { sent: false, reason: "no recipients" };
  if (!mailConfigured()) {
    console.info(`[mail] SMTP not configured — would send "${opts.subject}" to ${to.join(", ")}`);
    return { sent: false, reason: "smtp not configured" };
  }
  try {
    await getTransport().sendMail({ from: process.env.SMTP_FROM, to, subject: opts.subject, html: opts.html, text: opts.text, replyTo: opts.replyTo });
    return { sent: true };
  } catch (e) {
    console.error("[mail] send failed", e);
    return { sent: false, reason: e instanceof Error ? e.message : "error" };
  }
}
