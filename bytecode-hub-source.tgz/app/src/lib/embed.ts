/** Convert YouTube / Vimeo / Google Drive / Figma URLs into embeddable URLs. Returns null if unknown. */
export function videoEmbedUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "");
    if (host === "youtu.be") return `https://www.youtube-nocookie.com/embed/${u.pathname.slice(1)}`;
    if (host.endsWith("youtube.com")) {
      if (u.pathname.startsWith("/shorts/")) return `https://www.youtube-nocookie.com/embed/${u.pathname.split("/")[2]}`;
      if (u.pathname.startsWith("/embed/")) return url;
      const v = u.searchParams.get("v");
      return v ? `https://www.youtube-nocookie.com/embed/${v}` : null;
    }
    if (host === "vimeo.com") {
      const id = u.pathname.split("/").filter(Boolean)[0];
      return /^\d+$/.test(id ?? "") ? `https://player.vimeo.com/video/${id}` : null;
    }
    if (host === "player.vimeo.com") return url;
    if (host === "drive.google.com") {
      const m = /\/file\/d\/([^/]+)/.exec(u.pathname);
      return m ? `https://drive.google.com/file/d/${m[1]}/preview` : null;
    }
    if (host.endsWith("facebook.com") && /\/videos?\//.test(u.pathname)) {
      return `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(url)}&show_text=false`;
    }
  } catch {
    return null;
  }
  return null;
}

export function figmaEmbedUrl(url: string | null | undefined) {
  if (!url) return null;
  try {
    const u = new URL(url);
    if (!u.hostname.endsWith("figma.com")) return null;
    return `https://www.figma.com/embed?embed_host=bytecode&url=${encodeURIComponent(url)}`;
  } catch {
    return null;
  }
}

/** Microsoft's free Office viewer — only works for files reachable from the public internet. */
export function officeViewerUrl(absoluteFileUrl: string) {
  return `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(absoluteFileUrl)}`;
}
