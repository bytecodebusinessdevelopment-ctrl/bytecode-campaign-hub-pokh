import "server-only";
import { SignJWT, importPKCS8 } from "jose";
import { and, eq, inArray, lte, sql } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { siteUrl } from "@/lib/request";
import { formatDate, formatNpr } from "@/lib/format";

/**
 * Google Sheets synchronisation.
 *
 * - The database is the source of truth. Sheets are an operational register only.
 * - Each lead has one sync job per target (campaign sheet, central register) — enforced by a unique index.
 * - Jobs are claimed with FOR UPDATE SKIP LOCKED so two workers never process the same lead at once.
 * - Rows are matched by Lead ID (column A): an existing row is updated in place, otherwise a row is appended.
 *   Retrying a job therefore never creates a duplicate row.
 */

export const SHEET_HEADERS = [
  "Lead ID", "Date", "Business name", "Contact person", "Phone", "WhatsApp", "Email", "Industry", "Location",
  "Lead source", "Campaign", "Interested services", "Budget", "Timeline", "Assigned to", "Status",
  "Follow-up date", "Estimated value (NPR)", "Priority", "Lead record", "Last updated",
];

const MAX_AUTO_ATTEMPTS = 6;
// Overridable only so the automated test-suite can point at a local mock of the Google APIs.
const SHEETS_API = process.env.GOOGLE_SHEETS_API_BASE || "https://sheets.googleapis.com/v4/spreadsheets";
const TOKEN_URL = process.env.GOOGLE_OAUTH_TOKEN_URL || "https://oauth2.googleapis.com/token";

export function sheetsConfigured() {
  return Boolean(process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL && process.env.GOOGLE_PRIVATE_KEY);
}

let tokenCache: { token: string; exp: number } | null = null;

async function accessToken() {
  if (tokenCache && tokenCache.exp > Date.now() + 60_000) return tokenCache.token;
  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL!;
  const pem = process.env.GOOGLE_PRIVATE_KEY!.replace(/\\n/g, "\n");
  const key = await importPKCS8(pem, "RS256");
  const now = Math.floor(Date.now() / 1000);
  const assertion = await new SignJWT({ scope: "https://www.googleapis.com/auth/spreadsheets" })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(email)
    .setAudience("https://oauth2.googleapis.com/token")
    .setIssuedAt(now)
    .setExpirationTime(now + 3600)
    .sign(key);
  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion }),
  });
  if (!res.ok) throw new Error(`Google auth failed (${res.status}): ${(await res.text()).slice(0, 200)}`);
  const json = (await res.json()) as { access_token: string; expires_in: number };
  tokenCache = { token: json.access_token, exp: Date.now() + json.expires_in * 1000 };
  return json.access_token;
}

async function gapi(method: string, url: string, body?: unknown) {
  const res = await fetch(`${SHEETS_API}/${url}`, {
    method,
    headers: { Authorization: `Bearer ${await accessToken()}`, "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(20_000),
  });
  if (!res.ok) throw new Error(`Sheets API ${res.status}: ${(await res.text()).slice(0, 300)}`);
  return res.json();
}

const q = (tab: string) => `'${tab.replace(/'/g, "''")}'`;

async function ensureTab(sheetId: string, tab: string) {
  const meta = (await gapi("GET", `${sheetId}?fields=sheets.properties.title`)) as { sheets: { properties: { title: string } }[] };
  if (!meta.sheets.some((s) => s.properties.title === tab)) {
    await gapi("POST", `${sheetId}:batchUpdate`, { requests: [{ addSheet: { properties: { title: tab } } }] });
  }
  const head = (await gapi("GET", `${sheetId}/values/${encodeURIComponent(`${q(tab)}!A1:U1`)}`)) as { values?: string[][] };
  if (!head.values?.[0]?.length) {
    await gapi("PUT", `${sheetId}/values/${encodeURIComponent(`${q(tab)}!A1`)}?valueInputOption=RAW`, { values: [SHEET_HEADERS] });
  }
}

async function upsertRow(sheetId: string, tab: string, leadCode: string, row: string[], knownRow: number | null) {
  await ensureTab(sheetId, tab);
  const col = (await gapi("GET", `${sheetId}/values/${encodeURIComponent(`${q(tab)}!A:A`)}`)) as { values?: string[][] };
  const ids = (col.values ?? []).map((r) => r[0]);
  let rowNumber = ids.indexOf(leadCode) + 1; // 1-based; 0 means not found
  if (rowNumber <= 0 && knownRow && ids[knownRow - 1] === leadCode) rowNumber = knownRow;
  if (rowNumber > 0) {
    await gapi("PUT", `${sheetId}/values/${encodeURIComponent(`${q(tab)}!A${rowNumber}`)}?valueInputOption=RAW`, { values: [row] });
    return rowNumber;
  }
  const res = (await gapi("POST", `${sheetId}/values/${encodeURIComponent(`${q(tab)}!A:U`)}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`, {
    values: [row],
  })) as { updates?: { updatedRange?: string } };
  const m = /!A(\d+)/.exec(res.updates?.updatedRange ?? "");
  return m ? Number(m[1]) : null;
}

/** Build the sheet row for a lead (relevant summary only — full requirements stay in the database). */
export async function leadRow(leadId: string): Promise<{ row: string[]; leadCode: string; campaign: { sheetId: string | null; sheetTab: string | null } | null } | null> {
  const lead = await db.query.leads.findFirst({
    where: eq(t.leads.id, leadId),
    with: {
      business: { with: { industry: true } },
      contact: true,
      campaign: true,
      source: true,
      status: true,
      budgetRange: true,
      assignee: { columns: { name: true } },
      services: { with: { enquiryService: true } },
    },
  });
  if (!lead) return null;
  const budget = lead.budgetRange?.label ?? lead.budgetCustom ?? "";
  const row = [
    lead.leadCode,
    formatDate(lead.createdAt),
    lead.business.name,
    lead.contact?.fullName ?? "",
    lead.contact?.phone ?? "",
    lead.contact?.whatsapp ?? "",
    lead.contact?.email ?? "",
    lead.business.industry?.name ?? "",
    lead.business.location ?? "",
    lead.source?.name ?? "",
    lead.campaign?.name ?? "",
    lead.services.map((s) => s.enquiryService.label).join(", "),
    budget,
    lead.timeline ?? "",
    lead.assignee?.name ?? "",
    lead.mergedInto ? "Merged (duplicate)" : lead.status.name,
    lead.nextFollowUpAt ? formatDate(lead.nextFollowUpAt) : "",
    lead.estimatedValueNpr ? formatNpr(lead.estimatedValueNpr, { prefix: false }) : "",
    lead.priority ? lead.priority[0].toUpperCase() + lead.priority.slice(1) : "",
    siteUrl(`/admin/leads/${lead.id}`),
    formatDate(new Date(), true),
  ];
  return { row, leadCode: lead.leadCode, campaign: lead.campaign ? { sheetId: lead.campaign.sheetId, sheetTab: lead.campaign.sheetTab } : null };
}

/** Queue (or re-queue) sync jobs for a lead. Cheap and safe to call on every change. */
export async function enqueueLeadSync(leadId: string) {
  for (const target of ["campaign", "central"] as const) {
    await db
      .insert(t.sheetSyncJobs)
      .values({ leadId, target, status: "pending", nextAttemptAt: new Date() })
      .onConflictDoUpdate({
        target: [t.sheetSyncJobs.leadId, t.sheetSyncJobs.target],
        set: { status: "pending", attempts: 0, nextAttemptAt: new Date(), updatedAt: new Date() },
      });
  }
}

async function claimJobs(limit: number, leadIds?: string[]) {
  return db.transaction(async (tx) => {
    const rows = await tx.execute<{ id: string }>(sql`
      SELECT id FROM sheet_sync_jobs
      WHERE (status = 'pending' OR (status = 'running' AND updated_at < now() - interval '10 minutes'))
        AND next_attempt_at <= now()
        ${leadIds?.length ? sql`AND lead_id IN ${sql.raw(`(${leadIds.map((i) => `'${i.replace(/[^0-9a-f-]/gi, "")}'`).join(",")})`)}` : sql``}
      ORDER BY next_attempt_at
      LIMIT ${limit}
      FOR UPDATE SKIP LOCKED`);
    const ids = rows.map((r) => r.id);
    if (!ids.length) return [];
    return tx.update(t.sheetSyncJobs).set({ status: "running", updatedAt: new Date() }).where(inArray(t.sheetSyncJobs.id, ids)).returning();
  });
}

export async function processSyncJobs(opts: { limit?: number; leadIds?: string[] } = {}) {
  if (!sheetsConfigured()) return { processed: 0, ok: 0, failed: 0, skipped: "Google Sheets is not configured" };
  const jobs = await claimJobs(opts.limit ?? 25, opts.leadIds);
  let ok = 0;
  let failed = 0;
  for (const job of jobs) {
    try {
      const data = await leadRow(job.leadId);
      if (!data) throw new Error("Lead no longer exists");
      let sheetId: string | null = null;
      let tab = "Leads";
      if (job.target === "central") {
        sheetId = process.env.GOOGLE_SHEETS_CENTRAL_ID || null;
        tab = process.env.GOOGLE_SHEETS_CENTRAL_TAB || "Leads";
      } else {
        sheetId = data.campaign?.sheetId ?? null;
        tab = data.campaign?.sheetTab || "Leads";
      }
      if (!sheetId) {
        // Nothing to sync for this target (e.g. campaign has no sheet configured) — mark done.
        await db.update(t.sheetSyncJobs).set({ status: "success", lastError: "No sheet configured for this target — skipped", updatedAt: new Date() }).where(eq(t.sheetSyncJobs.id, job.id));
        continue;
      }
      const rowNumber = await upsertRow(sheetId, tab, data.leadCode, data.row, job.sheetRow);
      await db.update(t.sheetSyncJobs).set({
        status: "success", attempts: job.attempts + 1, lastError: null, lastSyncedAt: new Date(), sheetRow: rowNumber, updatedAt: new Date(),
      }).where(eq(t.sheetSyncJobs.id, job.id));
      await db.insert(t.syncLogs).values({ jobId: job.id, leadId: job.leadId, ok: true, message: `Synced to ${job.target} sheet row ${rowNumber ?? "?"}` });
      ok++;
    } catch (e) {
      failed++;
      const attempts = job.attempts + 1;
      const message = e instanceof Error ? e.message : String(e);
      const giveUp = attempts >= MAX_AUTO_ATTEMPTS;
      await db.update(t.sheetSyncJobs).set({
        status: giveUp ? "failed" : "pending",
        attempts,
        lastError: message.slice(0, 1000),
        nextAttemptAt: new Date(Date.now() + Math.min(2 ** attempts, 120) * 60_000),
        updatedAt: new Date(),
      }).where(eq(t.sheetSyncJobs.id, job.id));
      await db.insert(t.syncLogs).values({ jobId: job.id, leadId: job.leadId, ok: false, message: message.slice(0, 1000) });
      console.error("[sheets] sync failed", job.id, message);
    }
  }
  return { processed: jobs.length, ok, failed };
}

export async function retryJobs(jobIds: string[]) {
  if (!jobIds.length) return;
  await db.update(t.sheetSyncJobs).set({ status: "pending", attempts: 0, nextAttemptAt: new Date(), updatedAt: new Date() }).where(inArray(t.sheetSyncJobs.id, jobIds));
}

/** Retry every job that has failed permanently or is waiting in back-off after an error. */
export async function retryAllFailed() {
  await db.execute(sql`UPDATE sheet_sync_jobs SET status = 'pending', attempts = 0, next_attempt_at = now(), updated_at = now()
    WHERE status = 'failed' OR (status = 'pending' AND last_error IS NOT NULL)`);
}

export async function syncSummary() {
  const rows = await db.execute<{ status: string; n: number }>(sql`SELECT status, count(*)::int AS n FROM sheet_sync_jobs GROUP BY status`);
  const out: Record<string, number> = { pending: 0, running: 0, success: 0, failed: 0 };
  for (const r of rows) out[r.status] = Number(r.n);
  return out;
}

export async function dueJobsExist() {
  const r = await db.select({ id: t.sheetSyncJobs.id }).from(t.sheetSyncJobs).where(and(eq(t.sheetSyncJobs.status, "pending"), lte(t.sheetSyncJobs.nextAttemptAt, new Date()))).limit(1);
  return r.length > 0;
}
