import "server-only";
import postgres from "postgres";
import { drizzle } from "drizzle-orm/postgres-js";
import * as schema from "./schema";

const globalForDb = globalThis as unknown as { __pg?: ReturnType<typeof postgres> };

function createClient() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL is not set");
  return postgres(url, {
    max: Number(process.env.DATABASE_POOL_MAX ?? 5),
    ssl: process.env.DATABASE_SSL === "require" ? "require" : undefined,
    // Supabase transaction pooler (port 6543) does not support prepared statements.
    prepare: false,
    idle_timeout: 20,
  });
}

export const pg = globalForDb.__pg ?? createClient();
if (process.env.NODE_ENV !== "production") globalForDb.__pg = pg;

export const db = drizzle(pg, { schema });
export type DB = typeof db;
export * as t from "./schema";
