/**
 * Database schema — ByteCode Campaign Hub
 *
 * PostgreSQL (Supabase-compatible). All primary keys are UUIDs.
 * Lookup tables (industries, lead sources, statuses, budget ranges, categories, project types)
 * are editable from Admin → Lookups so nothing business-specific is hard-coded.
 */
import { relations, sql } from "drizzle-orm";
import {
  pgTable, pgEnum, uuid, text, integer, boolean, timestamp, jsonb, numeric, date,
  primaryKey, uniqueIndex, index, bigint, customType,
} from "drizzle-orm/pg-core";

const id = () => uuid("id").primaryKey().defaultRandom();
const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();
const updatedAt = () => timestamp("updated_at", { withTimezone: true }).notNull().defaultNow();

/* ───────────────────────────── Enums ───────────────────────────── */
export const roleEnum = pgEnum("user_role", ["admin", "manager", "bd"]);
export const campaignStatusEnum = pgEnum("campaign_status", ["draft", "active", "completed", "archived"]);
export const priceTypeEnum = pgEnum("price_type", ["fixed", "starting", "monthly", "custom", "tbc"]);
export const publishStatusEnum = pgEnum("publish_status", ["draft", "published"]);
export const projectClassEnum = pgEnum("project_classification", [
  "client_project", "internal_demo", "uiux_concept", "prototype", "in_progress",
]);
export const demoTypeEnum = pgEnum("demo_type", ["live_site", "vercel", "uiux_preview", "figma", "video", "other"]);
export const demoStatusEnum = pgEnum("demo_status", ["live", "beta", "archived"]);
export const visibilityEnum = pgEnum("visibility", ["public", "private", "internal"]);
export const resourceKindEnum = pgEnum("resource_kind", ["file", "link", "video_link", "website", "vercel", "figma"]);
export const mediaKindEnum = pgEnum("media_kind", ["desktop", "mobile", "gallery"]);
export const entryTypeEnum = pgEnum("lead_entry_type", ["public_enquiry", "internal", "quick_capture"]);
export const priorityEnum = pgEnum("lead_priority", ["hot", "warm", "cold"]);
export const activityTypeEnum = pgEnum("activity_type", [
  "note", "call", "whatsapp", "email", "meeting", "follow_up", "status_change", "system",
]);
export const syncTargetEnum = pgEnum("sync_target", ["campaign", "central"]);
export const syncStatusEnum = pgEnum("sync_status", ["pending", "running", "success", "failed"]);
export const fileStatusEnum = pgEnum("file_status", ["pending", "ready"]);

/* ───────────────────────────── Users & auth ───────────────────────────── */
export const users = pgTable("users", {
  id: id(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  role: roleEnum("role").notNull().default("bd"),
  passwordHash: text("password_hash").notNull(),
  active: boolean("active").notNull().default(true),
  mustChangePassword: boolean("must_change_password").notNull().default(false),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [uniqueIndex("users_email_uq").on(sql`lower(${t.email})`)]);

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(), // SHA-256 of the session token (raw token only lives in the cookie)
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  userAgent: text("user_agent"),
  createdAt: createdAt(),
}, (t) => [index("sessions_user_idx").on(t.userId)]);

/* ───────────────────────────── Settings & lookups ───────────────────────────── */
export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: updatedAt(),
});

export const industries = pgTable("industries", {
  id: id(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  sortOrder: integer("sort_order").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const projectTypes = pgTable("project_types", {
  id: id(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  sortOrder: integer("sort_order").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const resourceCategories = pgTable("resource_categories", {
  id: id(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  sortOrder: integer("sort_order").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const budgetRanges = pgTable("budget_ranges", {
  id: id(),
  label: text("label").notNull(),
  minNpr: integer("min_npr"),
  maxNpr: integer("max_npr"),
  sortOrder: integer("sort_order").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const leadStatuses = pgTable("lead_statuses", {
  id: id(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  sortOrder: integer("sort_order").notNull().default(0),
  color: text("color").notNull().default("#64748b"),
  isWon: boolean("is_won").notNull().default(false),
  isLost: boolean("is_lost").notNull().default(false),
  /** Statuses at or beyond "qualified" in the funnel — used for conversion reporting. */
  isQualified: boolean("is_qualified").notNull().default(false),
  active: boolean("active").notNull().default(true),
});

/* ───────────────────────────── Campaigns ───────────────────────────── */
export const campaigns = pgTable("campaigns", {
  id: id(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  location: text("location"),
  leadIdPrefix: text("lead_id_prefix").notNull().default("BC"),
  startDate: date("start_date"),
  endDate: date("end_date"),
  status: campaignStatusEnum("status").notNull().default("draft"),
  isDefault: boolean("is_default").notNull().default(false),
  heroTitle: text("hero_title"),
  heroSubtitle: text("hero_subtitle"),
  landingIntro: text("landing_intro"),
  sheetId: text("sheet_id"),
  sheetTab: text("sheet_tab").default("Leads"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const leadSources = pgTable("lead_sources", {
  id: id(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  campaignId: uuid("campaign_id").references(() => campaigns.id, { onDelete: "set null" }),
  sortOrder: integer("sort_order").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

/** Atomic per-prefix/per-year counters for human-readable Lead IDs (e.g. POK-2026-0001). */
export const leadCounters = pgTable("lead_counters", {
  prefix: text("prefix").notNull(),
  year: integer("year").notNull(),
  value: integer("value").notNull().default(0),
}, (t) => [primaryKey({ columns: [t.prefix, t.year] })]);

/* ───────────────────────────── Files ───────────────────────────── */
export const files = pgTable("files", {
  id: id(),
  storageKey: text("storage_key").notNull().unique(),
  driver: text("driver").notNull(),
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type").notNull(),
  sizeBytes: bigint("size_bytes", { mode: "number" }).notNull().default(0),
  status: fileStatusEnum("status").notNull().default("pending"),
  /** "public" files can be served without login; everything else requires an authenticated user. */
  isPublic: boolean("is_public").notNull().default(false),
  uploadedBy: uuid("uploaded_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: createdAt(),
});

/** File bytes for STORAGE_DRIVER=db (keeps a first deployment self-contained). */
const bytea = customType<{ data: Buffer; driverData: Buffer }>({ dataType: () => "bytea" });
export const fileBlobs = pgTable("file_blobs", {
  storageKey: text("storage_key").primaryKey(),
  data: bytea("data").notNull(),
  createdAt: createdAt(),
});

/* ───────────────────────────── Services & packages ───────────────────────────── */
export const services = pgTable("services", {
  id: id(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  /** Grouping on the public site: development | growth | creative | consulting */
  groupKey: text("group_key").notNull().default("development"),
  tagline: text("tagline"),
  summary: text("summary"),
  description: text("description"),
  icon: text("icon").default("sparkles"),
  /** "What we offer" bullet list */
  offerings: jsonb("offerings").$type<string[]>().notNull().default([]),
  /** Optional rich sections: [{title, body}] */
  sections: jsonb("sections").$type<{ title: string; body: string }[]>().notNull().default([]),
  pricingNote: text("pricing_note"),
  sortOrder: integer("sort_order").notNull().default(0),
  published: boolean("published").notNull().default(true),
  seoTitle: text("seo_title"),
  seoDescription: text("seo_description"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

/** Options shown in the "Interested services" checklist of the lead forms. Mapped to conditional question sets. */
export const enquiryServices = pgTable("enquiry_services", {
  id: id(),
  key: text("key").notNull().unique(), // e.g. website, seo, travel, video, system …
  label: text("label").notNull(),
  serviceId: uuid("service_id").references(() => services.id, { onDelete: "set null" }),
  sortOrder: integer("sort_order").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const packages = pgTable("packages", {
  id: id(),
  serviceId: uuid("service_id").notNull().references(() => services.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  description: text("description"),
  targetAudience: text("target_audience"),
  priceType: priceTypeEnum("price_type").notNull().default("tbc"),
  priceNpr: integer("price_npr"),
  priceNote: text("price_note"),
  deliverables: jsonb("deliverables").$type<string[]>().notNull().default([]),
  features: jsonb("features").$type<string[]>().notNull().default([]),
  exclusions: jsonb("exclusions").$type<string[]>().notNull().default([]),
  addOns: jsonb("add_ons").$type<string[]>().notNull().default([]),
  deliveryPeriod: text("delivery_period"),
  requirements: text("requirements"),
  featured: boolean("featured").notNull().default(false),
  isPlaceholder: boolean("is_placeholder").notNull().default(false),
  published: boolean("published").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [uniqueIndex("packages_service_slug_uq").on(t.serviceId, t.slug)]);

/* ───────────────────────────── Portfolio ───────────────────────────── */
export const portfolioProjects = pgTable("portfolio_projects", {
  id: id(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  clientName: text("client_name"),
  clientNamePublic: boolean("client_name_public").notNull().default(false),
  industryId: uuid("industry_id").references(() => industries.id, { onDelete: "set null" }),
  projectTypeId: uuid("project_type_id").references(() => projectTypes.id, { onDelete: "set null" }),
  classification: projectClassEnum("classification").notNull().default("client_project"),
  summary: text("summary"),
  description: text("description"),
  objectives: text("objectives"),
  problems: text("problems"),
  solution: text("solution"),
  features: jsonb("features").$type<string[]>().notNull().default([]),
  technologies: jsonb("technologies").$type<string[]>().notNull().default([]),
  coverFileId: uuid("cover_file_id").references(() => files.id, { onDelete: "set null" }),
  liveUrl: text("live_url"),
  videoUrl: text("video_url"),
  year: integer("year"),
  featured: boolean("featured").notNull().default(false),
  status: publishStatusEnum("status").notNull().default("draft"),
  /** Internal note, e.g. what still needs verifying before publishing. Never shown publicly. */
  internalNote: text("internal_note"),
  sortOrder: integer("sort_order").notNull().default(0),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const projectMedia = pgTable("project_media", {
  id: id(),
  projectId: uuid("project_id").notNull().references(() => portfolioProjects.id, { onDelete: "cascade" }),
  fileId: uuid("file_id").notNull().references(() => files.id, { onDelete: "cascade" }),
  kind: mediaKindEnum("kind").notNull().default("gallery"),
  caption: text("caption"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const projectServices = pgTable("project_services", {
  projectId: uuid("project_id").notNull().references(() => portfolioProjects.id, { onDelete: "cascade" }),
  serviceId: uuid("service_id").notNull().references(() => services.id, { onDelete: "cascade" }),
}, (t) => [primaryKey({ columns: [t.projectId, t.serviceId] })]);

/** Live sites, Vercel deployments, UI/UX previews and Figma prototypes — attachable to a project or standalone. */
export const demos = pgTable("demos", {
  id: id(),
  projectId: uuid("project_id").references(() => portfolioProjects.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  description: text("description"),
  url: text("url").notNull(),
  demoType: demoTypeEnum("demo_type").notNull().default("vercel"),
  classification: projectClassEnum("classification").notNull().default("internal_demo"),
  industryId: uuid("industry_id").references(() => industries.id, { onDelete: "set null" }),
  previewFileId: uuid("preview_file_id").references(() => files.id, { onDelete: "set null" }),
  status: demoStatusEnum("status").notNull().default("live"),
  technologies: jsonb("technologies").$type<string[]>().notNull().default([]),
  /** Admin confirms the target allows iframe embedding; the UI always offers an external link as a fallback. */
  embeddable: boolean("embeddable").notNull().default(false),
  visibility: visibilityEnum("visibility").notNull().default("public"),
  featured: boolean("featured").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

/* ───────────────────────────── Resources ───────────────────────────── */
export const resources = pgTable("resources", {
  id: id(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  categoryId: uuid("category_id").references(() => resourceCategories.id, { onDelete: "set null" }),
  industryId: uuid("industry_id").references(() => industries.id, { onDelete: "set null" }),
  kind: resourceKindEnum("kind").notNull().default("file"),
  fileId: uuid("file_id").references(() => files.id, { onDelete: "set null" }),
  url: text("url"),
  previewFileId: uuid("preview_file_id").references(() => files.id, { onDelete: "set null" }),
  visibility: visibilityEnum("visibility").notNull().default("private"),
  published: boolean("published").notNull().default(false),
  allowDownload: boolean("allow_download").notNull().default(true),
  featured: boolean("featured").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  downloadCount: integer("download_count").notNull().default(0),
  createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const resourceServices = pgTable("resource_services", {
  resourceId: uuid("resource_id").notNull().references(() => resources.id, { onDelete: "cascade" }),
  serviceId: uuid("service_id").notNull().references(() => services.id, { onDelete: "cascade" }),
}, (t) => [primaryKey({ columns: [t.resourceId, t.serviceId] })]);

export const resourceProjects = pgTable("resource_projects", {
  resourceId: uuid("resource_id").notNull().references(() => resources.id, { onDelete: "cascade" }),
  projectId: uuid("project_id").notNull().references(() => portfolioProjects.id, { onDelete: "cascade" }),
}, (t) => [primaryKey({ columns: [t.resourceId, t.projectId] })]);

export const campaignResources = pgTable("campaign_resources", {
  campaignId: uuid("campaign_id").notNull().references(() => campaigns.id, { onDelete: "cascade" }),
  resourceId: uuid("resource_id").notNull().references(() => resources.id, { onDelete: "cascade" }),
  sortOrder: integer("sort_order").notNull().default(0),
}, (t) => [primaryKey({ columns: [t.campaignId, t.resourceId] })]);

/* ───────────────────────────── Testimonials (verified only) ───────────────────────────── */
export const testimonials = pgTable("testimonials", {
  id: id(),
  personName: text("person_name").notNull(),
  designation: text("designation"),
  company: text("company"),
  quote: text("quote").notNull(),
  projectId: uuid("project_id").references(() => portfolioProjects.id, { onDelete: "set null" }),
  /** Must be ticked (with a note on where consent is recorded) before the testimonial can be published. */
  consentConfirmed: boolean("consent_confirmed").notNull().default(false),
  consentNote: text("consent_note"),
  published: boolean("published").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: createdAt(),
});

/* ───────────────────────────── Leads / CRM ───────────────────────────── */
export const businesses = pgTable("businesses", {
  id: id(),
  name: text("name").notNull(),
  industryId: uuid("industry_id").references(() => industries.id, { onDelete: "set null" }),
  location: text("location"),
  address: text("address"),
  website: text("website"),
  facebook: text("facebook"),
  instagram: text("instagram"),
  otherLinks: text("other_links"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [index("businesses_name_idx").on(sql`lower(${t.name})`)]);

export const contacts = pgTable("contacts", {
  id: id(),
  businessId: uuid("business_id").notNull().references(() => businesses.id, { onDelete: "cascade" }),
  fullName: text("full_name"),
  designation: text("designation"),
  phone: text("phone"),
  phoneNormalized: text("phone_normalized"),
  whatsapp: text("whatsapp"),
  email: text("email"),
  isPrimary: boolean("is_primary").notNull().default(true),
  createdAt: createdAt(),
}, (t) => [index("contacts_phone_idx").on(t.phoneNormalized), index("contacts_email_idx").on(sql`lower(${t.email})`)]);

export const leads = pgTable("leads", {
  id: id(),
  leadCode: text("lead_code").notNull().unique(),
  businessId: uuid("business_id").notNull().references(() => businesses.id, { onDelete: "restrict" }),
  contactId: uuid("contact_id").references(() => contacts.id, { onDelete: "set null" }),
  campaignId: uuid("campaign_id").references(() => campaigns.id, { onDelete: "set null" }),
  sourceId: uuid("source_id").references(() => leadSources.id, { onDelete: "set null" }),
  statusId: uuid("status_id").notNull().references(() => leadStatuses.id, { onDelete: "restrict" }),
  entryType: entryTypeEnum("entry_type").notNull(),
  priority: priorityEnum("priority"),
  budgetRangeId: uuid("budget_range_id").references(() => budgetRanges.id, { onDelete: "set null" }),
  budgetCustom: text("budget_custom"),
  /** Manually estimated deal value in NPR — always labelled as an estimate in reports. */
  estimatedValueNpr: numeric("estimated_value_npr", { precision: 14, scale: 2 }),
  timeline: text("timeline"),
  requirements: text("requirements"),
  initialInterest: text("initial_interest"),
  preferredContactMethod: text("preferred_contact_method"),
  meetingPreference: text("meeting_preference"),
  comments: text("comments"),
  consentToContact: boolean("consent_to_contact").notNull().default(false),
  consentAt: timestamp("consent_at", { withTimezone: true }),
  assignedTo: uuid("assigned_to").references(() => users.id, { onDelete: "set null" }),
  createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
  nextAction: text("next_action"),
  nextFollowUpAt: timestamp("next_follow_up_at", { withTimezone: true }),
  lostReason: text("lost_reason"),
  utm: jsonb("utm").$type<Record<string, string>>(),
  referrer: text("referrer"),
  landingPage: text("landing_page"),
  /** Client-generated idempotency key: retried/offline submissions never create duplicate leads. */
  clientRef: text("client_ref").unique(),
  possibleDuplicateOf: uuid("possible_duplicate_of"),
  duplicateReviewed: boolean("duplicate_reviewed").notNull().default(false),
  mergedInto: uuid("merged_into"),
  isComplete: boolean("is_complete").notNull().default(false),
  ipHash: text("ip_hash"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [
  index("leads_status_idx").on(t.statusId),
  index("leads_campaign_idx").on(t.campaignId),
  index("leads_assigned_idx").on(t.assignedTo),
  index("leads_followup_idx").on(t.nextFollowUpAt),
  index("leads_created_idx").on(t.createdAt),
]);

export const leadServices = pgTable("lead_services", {
  leadId: uuid("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
  enquiryServiceId: uuid("enquiry_service_id").notNull().references(() => enquiryServices.id, { onDelete: "cascade" }),
}, (t) => [primaryKey({ columns: [t.leadId, t.enquiryServiceId] })]);

/** Answers to the conditional, service-specific questions. One row per question set (website, seo, travel …). */
export const leadRequirements = pgTable("lead_requirements", {
  id: id(),
  leadId: uuid("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
  setKey: text("set_key").notNull(),
  answers: jsonb("answers").$type<Record<string, string>>().notNull().default({}),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("lead_req_uq").on(t.leadId, t.setKey)]);

export const meetings = pgTable("meetings", {
  id: id(),
  leadId: uuid("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
  mode: text("mode").notNull().default("in_person"),
  location: text("location"),
  attendees: text("attendees"),
  agenda: text("agenda"),
  outcome: text("outcome"),
  completed: boolean("completed").notNull().default(false),
  createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: createdAt(),
}, (t) => [index("meetings_lead_idx").on(t.leadId)]);

export const activities = pgTable("activities", {
  id: id(),
  leadId: uuid("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
  type: activityTypeEnum("type").notNull(),
  title: text("title"),
  body: text("body"),
  /** For follow-ups: when it is due, and when it was done. */
  dueAt: timestamp("due_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  assignedTo: uuid("assigned_to").references(() => users.id, { onDelete: "set null" }),
  createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: createdAt(),
}, (t) => [index("activities_lead_idx").on(t.leadId), index("activities_due_idx").on(t.dueAt)]);

export const leadStatusHistory = pgTable("lead_status_history", {
  id: id(),
  leadId: uuid("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
  fromStatusId: uuid("from_status_id").references(() => leadStatuses.id, { onDelete: "set null" }),
  toStatusId: uuid("to_status_id").notNull().references(() => leadStatuses.id, { onDelete: "restrict" }),
  note: text("note"),
  changedBy: uuid("changed_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: createdAt(),
}, (t) => [index("lsh_lead_idx").on(t.leadId)]);

export const leadAttachments = pgTable("lead_attachments", {
  id: id(),
  leadId: uuid("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
  fileId: uuid("file_id").notNull().references(() => files.id, { onDelete: "cascade" }),
  caption: text("caption"),
  createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: createdAt(),
});

/* ───────────────────────────── Integrations, notifications, audit ───────────────────────────── */
export const sheetSyncJobs = pgTable("sheet_sync_jobs", {
  id: id(),
  leadId: uuid("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
  target: syncTargetEnum("target").notNull(),
  status: syncStatusEnum("status").notNull().default("pending"),
  attempts: integer("attempts").notNull().default(0),
  lastError: text("last_error"),
  nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true }).notNull().defaultNow(),
  lastSyncedAt: timestamp("last_synced_at", { withTimezone: true }),
  sheetRow: integer("sheet_row"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [uniqueIndex("sync_job_uq").on(t.leadId, t.target), index("sync_status_idx").on(t.status, t.nextAttemptAt)]);

export const syncLogs = pgTable("sync_logs", {
  id: id(),
  jobId: uuid("job_id").references(() => sheetSyncJobs.id, { onDelete: "cascade" }),
  leadId: uuid("lead_id"),
  ok: boolean("ok").notNull(),
  message: text("message"),
  createdAt: createdAt(),
});

export const notifications = pgTable("notifications", {
  id: id(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  title: text("title").notNull(),
  body: text("body"),
  link: text("link"),
  readAt: timestamp("read_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [index("notifications_user_idx").on(t.userId, t.readAt)]);

export const auditLogs = pgTable("audit_logs", {
  id: id(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: text("entity_id"),
  details: jsonb("details"),
  ipHash: text("ip_hash"),
  createdAt: createdAt(),
}, (t) => [index("audit_created_idx").on(t.createdAt)]);

/** Fixed-window rate limiting stored in Postgres (works on serverless hosting). */
export const rateLimits = pgTable("rate_limits", {
  key: text("key").primaryKey(),
  windowStart: timestamp("window_start", { withTimezone: true }).notNull(),
  count: integer("count").notNull().default(0),
});

/* ───────────────────────────── Relations ───────────────────────────── */
export const leadsRelations = relations(leads, ({ one, many }) => ({
  business: one(businesses, { fields: [leads.businessId], references: [businesses.id] }),
  contact: one(contacts, { fields: [leads.contactId], references: [contacts.id] }),
  campaign: one(campaigns, { fields: [leads.campaignId], references: [campaigns.id] }),
  source: one(leadSources, { fields: [leads.sourceId], references: [leadSources.id] }),
  status: one(leadStatuses, { fields: [leads.statusId], references: [leadStatuses.id] }),
  budgetRange: one(budgetRanges, { fields: [leads.budgetRangeId], references: [budgetRanges.id] }),
  assignee: one(users, { fields: [leads.assignedTo], references: [users.id], relationName: "assignee" }),
  creator: one(users, { fields: [leads.createdBy], references: [users.id], relationName: "creator" }),
  services: many(leadServices),
  answers: many(leadRequirements),
  activities: many(activities),
  meetings: many(meetings),
  history: many(leadStatusHistory),
  attachments: many(leadAttachments),
}));
export const businessesRelations = relations(businesses, ({ one, many }) => ({
  industry: one(industries, { fields: [businesses.industryId], references: [industries.id] }),
  contacts: many(contacts),
}));
export const contactsRelations = relations(contacts, ({ one }) => ({
  business: one(businesses, { fields: [contacts.businessId], references: [businesses.id] }),
}));
export const leadServicesRelations = relations(leadServices, ({ one }) => ({
  lead: one(leads, { fields: [leadServices.leadId], references: [leads.id] }),
  enquiryService: one(enquiryServices, { fields: [leadServices.enquiryServiceId], references: [enquiryServices.id] }),
}));
export const leadRequirementsRelations = relations(leadRequirements, ({ one }) => ({
  lead: one(leads, { fields: [leadRequirements.leadId], references: [leads.id] }),
}));
export const activitiesRelations = relations(activities, ({ one }) => ({
  lead: one(leads, { fields: [activities.leadId], references: [leads.id] }),
  assignee: one(users, { fields: [activities.assignedTo], references: [users.id], relationName: "activityAssignee" }),
  creator: one(users, { fields: [activities.createdBy], references: [users.id], relationName: "activityCreator" }),
}));
export const meetingsRelations = relations(meetings, ({ one }) => ({
  lead: one(leads, { fields: [meetings.leadId], references: [leads.id] }),
  creator: one(users, { fields: [meetings.createdBy], references: [users.id] }),
}));
export const historyRelations = relations(leadStatusHistory, ({ one }) => ({
  lead: one(leads, { fields: [leadStatusHistory.leadId], references: [leads.id] }),
  from: one(leadStatuses, { fields: [leadStatusHistory.fromStatusId], references: [leadStatuses.id], relationName: "from" }),
  to: one(leadStatuses, { fields: [leadStatusHistory.toStatusId], references: [leadStatuses.id], relationName: "to" }),
  user: one(users, { fields: [leadStatusHistory.changedBy], references: [users.id] }),
}));
export const leadAttachmentsRelations = relations(leadAttachments, ({ one }) => ({
  lead: one(leads, { fields: [leadAttachments.leadId], references: [leads.id] }),
  file: one(files, { fields: [leadAttachments.fileId], references: [files.id] }),
}));
export const servicesRelations = relations(services, ({ many }) => ({
  packages: many(packages),
  resources: many(resourceServices),
  projects: many(projectServices),
}));
export const packagesRelations = relations(packages, ({ one }) => ({
  service: one(services, { fields: [packages.serviceId], references: [services.id] }),
}));
export const projectsRelations = relations(portfolioProjects, ({ one, many }) => ({
  industry: one(industries, { fields: [portfolioProjects.industryId], references: [industries.id] }),
  projectType: one(projectTypes, { fields: [portfolioProjects.projectTypeId], references: [projectTypes.id] }),
  cover: one(files, { fields: [portfolioProjects.coverFileId], references: [files.id] }),
  media: many(projectMedia),
  services: many(projectServices),
  demos: many(demos),
  resources: many(resourceProjects),
}));
export const projectMediaRelations = relations(projectMedia, ({ one }) => ({
  project: one(portfolioProjects, { fields: [projectMedia.projectId], references: [portfolioProjects.id] }),
  file: one(files, { fields: [projectMedia.fileId], references: [files.id] }),
}));
export const projectServicesRelations = relations(projectServices, ({ one }) => ({
  project: one(portfolioProjects, { fields: [projectServices.projectId], references: [portfolioProjects.id] }),
  service: one(services, { fields: [projectServices.serviceId], references: [services.id] }),
}));
export const demosRelations = relations(demos, ({ one }) => ({
  project: one(portfolioProjects, { fields: [demos.projectId], references: [portfolioProjects.id] }),
  industry: one(industries, { fields: [demos.industryId], references: [industries.id] }),
  preview: one(files, { fields: [demos.previewFileId], references: [files.id] }),
}));
export const resourcesRelations = relations(resources, ({ one, many }) => ({
  category: one(resourceCategories, { fields: [resources.categoryId], references: [resourceCategories.id] }),
  industry: one(industries, { fields: [resources.industryId], references: [industries.id] }),
  file: one(files, { fields: [resources.fileId], references: [files.id], relationName: "resourceFile" }),
  preview: one(files, { fields: [resources.previewFileId], references: [files.id], relationName: "resourcePreview" }),
  services: many(resourceServices),
  projects: many(resourceProjects),
  campaigns: many(campaignResources),
}));
export const resourceServicesRelations = relations(resourceServices, ({ one }) => ({
  resource: one(resources, { fields: [resourceServices.resourceId], references: [resources.id] }),
  service: one(services, { fields: [resourceServices.serviceId], references: [services.id] }),
}));
export const resourceProjectsRelations = relations(resourceProjects, ({ one }) => ({
  resource: one(resources, { fields: [resourceProjects.resourceId], references: [resources.id] }),
  project: one(portfolioProjects, { fields: [resourceProjects.projectId], references: [portfolioProjects.id] }),
}));
export const campaignResourcesRelations = relations(campaignResources, ({ one }) => ({
  campaign: one(campaigns, { fields: [campaignResources.campaignId], references: [campaigns.id] }),
  resource: one(resources, { fields: [campaignResources.resourceId], references: [resources.id] }),
}));
export const sheetSyncJobsRelations = relations(sheetSyncJobs, ({ one }) => ({
  lead: one(leads, { fields: [sheetSyncJobs.leadId], references: [leads.id] }),
}));
export const auditLogsRelations = relations(auditLogs, ({ one }) => ({
  user: one(users, { fields: [auditLogs.userId], references: [users.id] }),
}));
export const testimonialsRelations = relations(testimonials, ({ one }) => ({
  project: one(portfolioProjects, { fields: [testimonials.projectId], references: [portfolioProjects.id] }),
}));
