import "server-only";
import { and, asc, desc, eq, ilike, isNotNull, isNull, lt, gte, lte, or, sql, type SQL } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { leadScope, type SessionUser } from "@/lib/auth";
import { startOfNepalDay, fromNepalInput } from "@/lib/format";

export type LeadFilters = {
  q?: string; status?: string; source?: string; campaign?: string; industry?: string; service?: string; assigned?: string;
  priority?: string; entry?: string; from?: string; to?: string; followup?: string; duplicates?: string; sort?: string; page?: string;
};

export function leadWhere(user: SessionUser, f: LeadFilters): SQL | undefined {
  const c: (SQL | undefined)[] = [isNull(t.leads.mergedInto), leadScope(user)];
  if (f.q) {
    const q = `%${f.q.trim()}%`;
    c.push(or(
      ilike(t.leads.leadCode, q), ilike(t.businesses.name, q), ilike(t.businesses.location, q),
      sql`EXISTS (SELECT 1 FROM contacts ct WHERE ct.business_id = ${t.businesses.id} AND (ct.full_name ILIKE ${q} OR ct.phone ILIKE ${q} OR ct.email ILIKE ${q} OR ct.whatsapp ILIKE ${q}))`,
    ));
  }
  if (f.status) c.push(eq(t.leads.statusId, f.status));
  if (f.source) c.push(eq(t.leads.sourceId, f.source));
  if (f.campaign) c.push(eq(t.leads.campaignId, f.campaign));
  if (f.industry) c.push(eq(t.businesses.industryId, f.industry));
  if (f.service) c.push(sql`EXISTS (SELECT 1 FROM lead_services ls WHERE ls.lead_id = ${t.leads.id} AND ls.enquiry_service_id = ${f.service})`);
  if (f.assigned === "me") c.push(eq(t.leads.assignedTo, user.id));
  else if (f.assigned === "none") c.push(isNull(t.leads.assignedTo));
  else if (f.assigned) c.push(eq(t.leads.assignedTo, f.assigned));
  if (f.priority) c.push(sql`${t.leads.priority} = ${f.priority}`);
  if (f.entry) c.push(sql`${t.leads.entryType} = ${f.entry}`);
  if (f.from) { const d = fromNepalInput(f.from); if (d) c.push(gte(t.leads.createdAt, d)); }
  if (f.to) { const d = fromNepalInput(`${f.to}T23:59`); if (d) c.push(lte(t.leads.createdAt, d)); }
  if (f.followup === "overdue") c.push(and(isNotNull(t.leads.nextFollowUpAt), lt(t.leads.nextFollowUpAt, new Date()), eq(t.leadStatuses.isWon, false), eq(t.leadStatuses.isLost, false)));
  if (f.followup === "today") c.push(and(gte(t.leads.nextFollowUpAt, startOfNepalDay()), lt(t.leads.nextFollowUpAt, startOfNepalDay(1))));
  if (f.followup === "none") c.push(isNull(t.leads.nextFollowUpAt));
  if (f.duplicates === "1") c.push(and(isNotNull(t.leads.possibleDuplicateOf), eq(t.leads.duplicateReviewed, false)));
  return and(...c);
}

export function leadOrder(sort?: string) {
  switch (sort) {
    case "oldest": return [asc(t.leads.createdAt)];
    case "followup": return [sql`${t.leads.nextFollowUpAt} ASC NULLS LAST`];
    case "value": return [sql`${t.leads.estimatedValueNpr} DESC NULLS LAST`];
    case "business": return [asc(t.businesses.name)];
    case "updated": return [desc(t.leads.updatedAt)];
    default: return [desc(t.leads.createdAt)];
  }
}

export const PAGE_SIZE = 25;

export async function listLeads(user: SessionUser, f: LeadFilters, opts: { all?: boolean } = {}) {
  const where = leadWhere(user, f);
  const page = Math.max(1, Number(f.page ?? 1) || 1);
  const base = db
    .select({
      id: t.leads.id, leadCode: t.leads.leadCode, createdAt: t.leads.createdAt, updatedAt: t.leads.updatedAt, entryType: t.leads.entryType,
      priority: t.leads.priority, nextFollowUpAt: t.leads.nextFollowUpAt, nextAction: t.leads.nextAction, estimatedValueNpr: t.leads.estimatedValueNpr,
      possibleDuplicateOf: t.leads.possibleDuplicateOf, duplicateReviewed: t.leads.duplicateReviewed, isComplete: t.leads.isComplete,
      timeline: t.leads.timeline, budgetCustom: t.leads.budgetCustom, requirements: t.leads.requirements,
      businessName: t.businesses.name, location: t.businesses.location, website: t.businesses.website,
      industry: t.industries.name,
      statusName: t.leadStatuses.name, statusColor: t.leadStatuses.color, statusIsWon: t.leadStatuses.isWon, statusIsLost: t.leadStatuses.isLost,
      sourceName: t.leadSources.name, campaignName: t.campaigns.name,
      assigneeName: t.users.name,
      contactName: t.contacts.fullName, phone: t.contacts.phone, whatsapp: t.contacts.whatsapp, email: t.contacts.email,
      budgetLabel: t.budgetRanges.label,
      services: sql<string>`(SELECT string_agg(es.label, ', ' ORDER BY es.sort_order) FROM lead_services ls JOIN enquiry_services es ON es.id = ls.enquiry_service_id WHERE ls.lead_id = ${t.leads.id})`,
    })
    .from(t.leads)
    .innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId))
    .innerJoin(t.leadStatuses, eq(t.leadStatuses.id, t.leads.statusId))
    .leftJoin(t.industries, eq(t.industries.id, t.businesses.industryId))
    .leftJoin(t.leadSources, eq(t.leadSources.id, t.leads.sourceId))
    .leftJoin(t.campaigns, eq(t.campaigns.id, t.leads.campaignId))
    .leftJoin(t.users, eq(t.users.id, t.leads.assignedTo))
    .leftJoin(t.contacts, eq(t.contacts.id, t.leads.contactId))
    .leftJoin(t.budgetRanges, eq(t.budgetRanges.id, t.leads.budgetRangeId))
    .where(where)
    .orderBy(...leadOrder(f.sort));
  const rows = opts.all ? await base.limit(20000) : await base.limit(PAGE_SIZE).offset((page - 1) * PAGE_SIZE);
  const [{ n }] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(t.leads)
    .innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId))
    .innerJoin(t.leadStatuses, eq(t.leadStatuses.id, t.leads.statusId))
    .where(where);
  return { rows, total: Number(n), page, pages: Math.max(1, Math.ceil(Number(n) / PAGE_SIZE)) };
}

export async function lookupsForLeads() {
  const [statuses, sources, campaigns, industries, services, users, budgets] = await Promise.all([
    db.select().from(t.leadStatuses).where(eq(t.leadStatuses.active, true)).orderBy(asc(t.leadStatuses.sortOrder)),
    db.select().from(t.leadSources).where(eq(t.leadSources.active, true)).orderBy(asc(t.leadSources.sortOrder)),
    db.select().from(t.campaigns).orderBy(desc(t.campaigns.isDefault), asc(t.campaigns.name)),
    db.select().from(t.industries).where(eq(t.industries.active, true)).orderBy(asc(t.industries.sortOrder)),
    db.select().from(t.enquiryServices).where(eq(t.enquiryServices.active, true)).orderBy(asc(t.enquiryServices.sortOrder)),
    db.select({ id: t.users.id, name: t.users.name, role: t.users.role }).from(t.users).where(eq(t.users.active, true)).orderBy(asc(t.users.name)),
    db.select().from(t.budgetRanges).where(eq(t.budgetRanges.active, true)).orderBy(asc(t.budgetRanges.sortOrder)),
  ]);
  return { statuses, sources, campaigns, industries, services, users, budgets };
}

