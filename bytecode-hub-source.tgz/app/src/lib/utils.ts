import { clsx, type ClassValue } from "clsx";

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export function slugify(input: string) {
  return input
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80) || "item";
}

/** Split a textarea (one item per line) into a clean string list. */
export function lines(value: FormDataEntryValue | null | undefined): string[] {
  return String(value ?? "")
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export function str(value: FormDataEntryValue | null | undefined): string | null {
  const s = String(value ?? "").trim();
  return s.length ? s : null;
}

export function bool(value: FormDataEntryValue | null | undefined) {
  return value === "on" || value === "true" || value === "1";
}

export function int(value: FormDataEntryValue | null | undefined): number | null {
  const s = String(value ?? "").replace(/[, ]/g, "").trim();
  if (!s) return null;
  const n = Number(s);
  return Number.isFinite(n) ? Math.round(n) : null;
}

export function safeUrl(value: string | null | undefined): string | null {
  if (!value) return null;
  let v = value.trim();
  if (!v) return null;
  if (!/^https?:\/\//i.test(v)) v = `https://${v}`;
  try {
    const u = new URL(v);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    return u.toString();
  } catch {
    return null;
  }
}

/** Normalise a phone number for duplicate detection: digits only, Nepal country code stripped. */
export function normalizePhone(phone: string | null | undefined): string | null {
  if (!phone) return null;
  let d = phone.replace(/\D/g, "");
  if (d.startsWith("00")) d = d.slice(2);
  if (d.startsWith("977") && d.length > 10) d = d.slice(3);
  if (d.startsWith("0") && d.length > 7) d = d.slice(1);
  return d.length >= 6 ? d : null;
}

/**
 * Validates Nepali mobile (98/97/96 + 8 digits) and landline numbers (+977 area code), and accepts
 * international numbers in +<country code> format.
 */
export function isValidPhone(phone: string): boolean {
  const raw = phone.trim();
  const d = raw.replace(/[\s\-().]/g, "");
  if (/^(\+?977)?9[678]\d{8}$/.test(d)) return true; // Nepal mobile
  if (/^(\+?977)?0?\d{1,2}\d{5,7}$/.test(d) && d.replace(/\D/g, "").length >= 7) return true; // Nepal landline
  if (/^\+\d{7,15}$/.test(d)) return true; // international E.164
  return false;
}

export function whatsappLink(number: string | null | undefined, text?: string) {
  if (!number) return null;
  let d = number.replace(/\D/g, "");
  if (d.length === 10 && d.startsWith("9")) d = `977${d}`;
  return `https://wa.me/${d}${text ? `?text=${encodeURIComponent(text)}` : ""}`;
}

export function telLink(number: string | null | undefined) {
  if (!number) return null;
  return `tel:${number.replace(/[^\d+]/g, "")}`;
}

export function truncate(s: string | null | undefined, n: number) {
  if (!s) return "";
  return s.length > n ? `${s.slice(0, n - 1).trimEnd()}…` : s;
}
