/**
 * Role-based permissions. These checks are enforced on the server in every action, route handler
 * and data query (see requirePermission / leadScope) — hiding buttons in the UI is only cosmetic.
 */
export type Role = "admin" | "manager" | "bd";

export const PERMISSIONS = {
  manageUsers: ["admin"],
  manageSettings: ["admin"],
  manageIntegrations: ["admin"],
  manageCampaigns: ["admin"],
  manageLookups: ["admin"],
  managePricing: ["admin"], // services & packages
  manageContent: ["admin", "manager"], // portfolio, demos, resources, testimonials
  viewAllLeads: ["admin", "manager"],
  assignLeads: ["admin", "manager"],
  exportLeads: ["admin", "manager"],
  mergeLeads: ["admin", "manager"],
  deleteLeads: ["admin"],
  viewReports: ["admin", "manager"],
  retrySync: ["admin", "manager"],
  viewAudit: ["admin"],
  createLeads: ["admin", "manager", "bd"],
  viewInternalResources: ["admin", "manager", "bd"],
} as const satisfies Record<string, readonly Role[]>;

export type Permission = keyof typeof PERMISSIONS;

export function can(role: Role | undefined | null, permission: Permission) {
  if (!role) return false;
  return (PERMISSIONS[permission] as readonly Role[]).includes(role);
}

export const ROLE_LABELS: Record<Role, string> = {
  admin: "Administrator",
  manager: "Manager",
  bd: "BD Team Member",
};
