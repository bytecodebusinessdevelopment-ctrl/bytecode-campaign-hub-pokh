import "server-only";
import { cache } from "react";
import { db, t } from "@/lib/db";

export type SiteSettings = {
  companyName: string;
  shortName: string;
  tagline: string;
  heroTitle: string;
  heroSubtitle: string;
  aboutIntro: string;
  aboutBody: string;
  whyChoose: { title: string; body: string }[];
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  officeHours: string;
  mapUrl: string;
  social: { facebook: string; instagram: string; linkedin: string; x: string; youtube: string; tiktok: string };
  existingWebsiteUrl: string;
  externalPortfolioUrl: string;
  logoFileId: string | null;
  logoDarkFileId: string | null;
  colors: { navy: string; blue: string; teal: string };
  notificationEmails: string[];
  analytics: { ga4Id: string; metaPixelId: string };
  uploadLimitsMb: { document: number; image: number; video: number };
  publicResourcesLabel: string;
  seoTitle: string;
  seoDescription: string;
  privacyPolicy: string;
  termsOfUse: string;
  leadRetentionMonths: number;
  technologies: string[];
};

export const DEFAULT_SETTINGS: SiteSettings = {
  companyName: "ByteCode Developers",
  shortName: "ByteCode",
  tagline: "Websites, apps, software, SEO and digital growth — under one roof.",
  heroTitle: "Your Business. Digitally Ahead.",
  heroSubtitle:
    "From powerful websites and custom software to SEO, content and digital marketing, ByteCode helps businesses build, grow and succeed online.",
  aboutIntro: "ByteCode Developers is a Nepal-based technology and software development company operating from Kathmandu.",
  aboutBody: "",
  whyChoose: [
    { title: "Local market expertise", body: "We work with businesses in Nepal and understand local customers, payment methods and platforms." },
    { title: "One team, end to end", body: "Websites, apps, software, content, SEO and marketing handled together — no hand-offs between agencies." },
    { title: "Transparent reporting", body: "Clear scopes, clear timelines and regular progress reports throughout your project." },
    { title: "Dedicated support", body: "A named point of contact during the project and ongoing maintenance and support after launch." },
  ],
  phone: "+977 9802398559",
  whatsapp: "",
  email: "info@bytecodedevelopers.com",
  address: "Gravity Center, Anamnagar-29, Kathmandu 44600, Nepal",
  officeHours: "",
  mapUrl: "",
  social: {
    facebook: "https://www.facebook.com/profile.php?id=61576076060043",
    instagram: "https://www.instagram.com/bytecode_developers",
    linkedin: "https://www.linkedin.com/company/bytecode-developers-nepal",
    x: "",
    youtube: "",
    tiktok: "",
  },
  existingWebsiteUrl: "https://bytecodedevelopers.com",
  externalPortfolioUrl: "https://bytecodedevelopers.com/portfolio",
  logoFileId: null,
  logoDarkFileId: null,
  colors: { navy: "#17324D", blue: "#2878A8", teal: "#269B83" },
  notificationEmails: [],
  analytics: { ga4Id: "", metaPixelId: "" },
  uploadLimitsMb: { document: 25, image: 8, video: 100 },
  publicResourcesLabel: "Resources & Showcase",
  seoTitle: "ByteCode Developers — Websites, Software, SEO & Digital Growth in Nepal",
  seoDescription:
    "ByteCode Developers builds websites, web and mobile apps, custom business software, SEO and travel content, and digital marketing for businesses in Nepal.",
  privacyPolicy: "",
  termsOfUse: "",
  leadRetentionMonths: 36,
  technologies: [],
};

function merge<T>(base: T, override: unknown): T {
  if (override === null || override === undefined) return base;
  if (Array.isArray(base) || typeof base !== "object" || base === null) return override as T;
  const out: Record<string, unknown> = { ...(base as Record<string, unknown>) };
  for (const [k, v] of Object.entries(override as Record<string, unknown>)) {
    out[k] = k in out ? merge(out[k], v) : v;
  }
  return out as T;
}

export const getSettings = cache(async (): Promise<SiteSettings> => {
  try {
    const rows = await db.select().from(t.settings);
    const obj: Record<string, unknown> = {};
    for (const r of rows) obj[r.key] = r.value;
    return merge(DEFAULT_SETTINGS, obj);
  } catch {
    return DEFAULT_SETTINGS;
  }
});

export async function saveSettings(patch: Partial<SiteSettings>) {
  for (const [key, value] of Object.entries(patch)) {
    await db
      .insert(t.settings)
      .values({ key, value: value as object })
      .onConflictDoUpdate({ target: t.settings.key, set: { value: value as object, updatedAt: new Date() } });
  }
}

export function hexToRgbChannels(hex: string) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}
