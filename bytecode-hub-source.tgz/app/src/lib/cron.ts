import "server-only";
import { timingSafeEqual } from "crypto";

/** Vercel Cron sends `Authorization: Bearer <CRON_SECRET>`; external schedulers can send the same header. */
export function cronAuthorized(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;
  const got = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  const a = Buffer.from(got);
  const b = Buffer.from(secret);
  return a.length === b.length && timingSafeEqual(a, b);
}
