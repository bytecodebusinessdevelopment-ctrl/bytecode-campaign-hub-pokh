/** Client-safe configuration for the enquiry forms (conditional questions, option lists). */

export type Question = {
  key: string;
  label: string;
  type: "text" | "textarea" | "select" | "yesno";
  options?: string[];
  placeholder?: string;
};

export type QuestionSet = { key: string; title: string; triggers: string[]; questions: Question[] };

export const QUESTION_SETS: QuestionSet[] = [
  {
    key: "website",
    title: "Website details",
    triggers: ["website", "redesign", "management"],
    questions: [
      { key: "existing_website", label: "Do you have an existing website?", type: "yesno" },
      { key: "website_type", label: "Required website type", type: "select", options: ["Business / company", "Corporate", "NGO / INGO", "Travel & tourism", "E-commerce", "Educational", "Healthcare", "Other"] },
      { key: "pages", label: "Required pages", type: "textarea", placeholder: "e.g. Home, About, Services, Gallery, Contact…" },
      { key: "features", label: "Features and functionality", type: "textarea" },
      { key: "online_payment", label: "Do you need online payments?", type: "select", options: ["No", "Yes — eSewa / Khalti / Fonepay", "Yes — international cards", "Not sure"] },
      { key: "booking", label: "Do you need online booking?", type: "yesno" },
      { key: "admin_panel", label: "Do you need an admin panel to update content yourself?", type: "yesno" },
      { key: "domain_hosting", label: "Existing domain and hosting", type: "text", placeholder: "e.g. I own example.com, hosting with …" },
    ],
  },
  {
    key: "ecommerce",
    title: "E-commerce details",
    triggers: ["ecommerce"],
    questions: [
      { key: "products", label: "Approximate number of products", type: "select", options: ["Under 50", "50–200", "200–1,000", "More than 1,000"] },
      { key: "categories", label: "Main product categories", type: "text" },
      { key: "payments", label: "Preferred payment methods", type: "text", placeholder: "eSewa, Khalti, Fonepay, cards, cash on delivery…" },
      { key: "delivery", label: "Delivery coverage", type: "text", placeholder: "e.g. Pokhara only, all Nepal, international" },
      { key: "inventory", label: "Inventory management requirements", type: "textarea" },
      { key: "existing_store", label: "Existing online store or marketplace presence", type: "text", placeholder: "Daraz, Facebook shop, Instagram…" },
    ],
  },
  {
    key: "app",
    title: "Application details",
    triggers: ["app"],
    questions: [
      { key: "platforms", label: "Platforms required", type: "select", options: ["Web app", "Android", "iOS", "Android + iOS", "Web + mobile", "Not sure"] },
      { key: "users", label: "Who will use the application?", type: "text" },
      { key: "key_features", label: "Key features", type: "textarea" },
      { key: "roles", label: "User accounts and roles", type: "text" },
      { key: "integrations", label: "Required integrations", type: "text", placeholder: "payments, SMS, maps, existing software…" },
      { key: "designs", label: "Do you already have designs or wireframes?", type: "yesno" },
    ],
  },
  {
    key: "seo",
    title: "SEO details",
    triggers: ["seo"],
    questions: [
      { key: "website_url", label: "Website URL", type: "text" },
      { key: "target_locations", label: "Target locations", type: "text", placeholder: "e.g. Pokhara, Nepal, India, Europe…" },
      { key: "target_audience", label: "Target audience", type: "text" },
      { key: "main_offer", label: "Main services or products", type: "textarea" },
      { key: "existing_seo", label: "Existing SEO work", type: "textarea" },
      { key: "concerns", label: "Main search visibility concerns", type: "textarea" },
      { key: "competitors", label: "Competitors", type: "text" },
      { key: "keywords", label: "Target keywords (if known)", type: "text" },
    ],
  },
  {
    key: "travel",
    title: "Travel SEO content details",
    triggers: ["travel"],
    questions: [
      { key: "destinations", label: "Destinations", type: "text", placeholder: "e.g. Annapurna, Pokhara, Mustang…" },
      { key: "packages", label: "Tour and trekking packages", type: "textarea" },
      { key: "activities", label: "Activities", type: "text", placeholder: "Paragliding, rafting, jungle safari…" },
      { key: "audience", label: "Target audience", type: "text" },
      { key: "market", label: "Market", type: "select", options: ["International", "Domestic", "Both"] },
      { key: "content_types", label: "Required content types", type: "textarea", placeholder: "Itineraries, destination pages, blogs…" },
      { key: "volume", label: "Estimated content volume", type: "text", placeholder: "e.g. 20 itineraries + 8 blogs per month" },
    ],
  },
  {
    key: "marketing",
    title: "Digital marketing details",
    triggers: ["marketing"],
    questions: [
      { key: "platforms", label: "Platforms currently used", type: "text", placeholder: "Facebook, Instagram, TikTok, Google…" },
      { key: "objectives", label: "Campaign objectives", type: "textarea" },
      { key: "ad_budget", label: "Approximate monthly advertising budget (NPR)", type: "text" },
      { key: "content_needs", label: "Content creation requirements", type: "textarea" },
      { key: "previous", label: "Previous campaigns and results (if any)", type: "textarea" },
    ],
  },
  {
    key: "video",
    title: "Video production details",
    triggers: ["video"],
    questions: [
      { key: "video_type", label: "Video type", type: "select", options: ["Business introduction", "Promotional / advert", "Short-form social video", "Product / service video", "Event", "Other"] },
      { key: "count", label: "Number of videos", type: "text" },
      { key: "duration", label: "Approximate duration", type: "text" },
      { key: "shooting", label: "Shooting requirements", type: "textarea", placeholder: "Locations, people, drone…" },
      { key: "editing", label: "Editing requirements", type: "textarea" },
      { key: "platforms", label: "Social media platforms", type: "text" },
      { key: "ad_purpose", label: "Will the video be used for advertising?", type: "yesno" },
    ],
  },
  {
    key: "system",
    title: "System / software details",
    triggers: ["system", "automation"],
    questions: [
      { key: "processes", label: "Existing business processes", type: "textarea" },
      { key: "departments", label: "Departments involved", type: "text" },
      { key: "users", label: "Number of users", type: "text" },
      { key: "existing_software", label: "Existing software", type: "text" },
      { key: "manual", label: "Manual workflows you want to replace", type: "textarea" },
      { key: "automation", label: "Required automation", type: "textarea" },
      { key: "reporting", label: "Reporting requirements", type: "textarea" },
      { key: "problems", label: "Main business problems", type: "textarea" },
    ],
  },
];

export function activeSets(selectedKeys: string[]) {
  return QUESTION_SETS.filter((s) => s.triggers.some((k) => selectedKeys.includes(k)));
}

export const TIMELINES = ["Immediately", "Within two weeks", "Within one month", "Within three months", "Future planning", "Not decided"];
export const CONTACT_METHODS = ["Phone call", "WhatsApp", "Email", "Viber", "In-person meeting"];
export const MEETING_PREFERENCES = ["In-person meeting", "Video call", "Phone call", "No meeting needed yet"];
export const PRIORITIES = [
  { value: "hot", label: "Hot" },
  { value: "warm", label: "Warm" },
  { value: "cold", label: "Cold" },
] as const;

export const CLASSIFICATION_LABELS: Record<string, string> = {
  client_project: "Completed client project",
  internal_demo: "Internal demonstration",
  uiux_concept: "UI/UX concept",
  prototype: "Experimental prototype",
  in_progress: "In-progress project",
};

export const DEMO_TYPE_LABELS: Record<string, string> = {
  live_site: "Live website",
  vercel: "Vercel deployment",
  uiux_preview: "UI/UX preview",
  figma: "Figma prototype",
  video: "Video walkthrough",
  other: "Other demo",
};

export const RESOURCE_KIND_LABELS: Record<string, string> = {
  file: "Document / file",
  link: "External link",
  video_link: "Video link",
  website: "Live website",
  vercel: "Vercel deployment",
  figma: "Figma / prototype",
};
