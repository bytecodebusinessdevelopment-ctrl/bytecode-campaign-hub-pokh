/** Formatting helpers — NPR currency with Nepali/Indian digit grouping and Nepal time (UTC+5:45). */
export const NEPAL_TZ = "Asia/Kathmandu";

const nprFmt = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 });

export function formatNpr(value: number | string | null | undefined, opts: { prefix?: boolean } = {}) {
  if (value === null || value === undefined || value === "") return "—";
  const n = typeof value === "string" ? Number(value) : value;
  if (!Number.isFinite(n)) return "—";
  return `${opts.prefix === false ? "" : "Rs. "}${nprFmt.format(n)}`;
}

export function formatDate(d: Date | string | null | undefined, withTime = false) {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: NEPAL_TZ,
    day: "2-digit",
    month: "short",
    year: "numeric",
    ...(withTime ? { hour: "2-digit", minute: "2-digit", hour12: true } : {}),
  }).format(date);
}

export function formatDateTime(d: Date | string | null | undefined) {
  return formatDate(d, true);
}

/** Value for <input type="datetime-local"> expressed in Nepal time. */
export function toNepalInput(d: Date | string | null | undefined) {
  if (!d) return "";
  const date = typeof d === "string" ? new Date(d) : d;
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: NEPAL_TZ, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false,
  }).formatToParts(date);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "00";
  const hour = get("hour") === "24" ? "00" : get("hour");
  return `${get("year")}-${get("month")}-${get("day")}T${hour}:${get("minute")}`;
}

/** Parse a datetime-local value entered in Nepal time into a UTC Date. */
export function fromNepalInput(value: string | null | undefined): Date | null {
  if (!value) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?$/.exec(value.trim());
  if (!m) return null;
  const [, y, mo, da, h = "09", mi = "00"] = m;
  // Nepal is UTC+05:45 with no daylight saving.
  const utc = Date.UTC(+y, +mo - 1, +da, +h, +mi) - (5 * 60 + 45) * 60 * 1000;
  return new Date(utc);
}

export function nepalToday(): string {
  return toNepalInput(new Date()).slice(0, 10);
}

/** Start of the current day in Nepal, as a UTC Date. */
export function startOfNepalDay(offsetDays = 0) {
  const d = fromNepalInput(`${nepalToday()}T00:00`)!;
  return new Date(d.getTime() + offsetDays * 86400000);
}

export function relativeDays(d: Date | string | null | undefined) {
  if (!d) return "";
  const date = typeof d === "string" ? new Date(d) : d;
  const diff = Math.round((date.getTime() - Date.now()) / 86400000);
  if (diff === 0) return "today";
  if (diff === 1) return "tomorrow";
  if (diff === -1) return "yesterday";
  return diff > 0 ? `in ${diff} days` : `${-diff} days ago`;
}

export function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export function pct(part: number, whole: number) {
  if (!whole) return "0%";
  return `${((part / whole) * 100).toFixed(1).replace(/\.0$/, "")}%`;
}
