import "server-only";
import { unstable_rethrow } from "next/navigation";
import { ZodError } from "zod";
import { flattenErrors } from "@/lib/validation";

export type ActionState = { ok?: boolean; error?: string; message?: string; fieldErrors?: Record<string, string>; data?: Record<string, unknown> } | null;

/** Wraps a server action so thrown errors become a friendly message (redirects still propagate). */
export function safeAction(fn: (fd: FormData) => Promise<ActionState | void>) {
  return async (_prev: ActionState, fd: FormData): Promise<ActionState> => {
    try {
      return (await fn(fd)) ?? { ok: true, message: "Saved." };
    } catch (e) {
      unstable_rethrow(e);
      if (e instanceof ZodError) return { error: "Please check the highlighted fields.", fieldErrors: flattenErrors(e) };
      console.error("[action]", e);
      const msg = e instanceof Error ? e.message : "Something went wrong.";
      // Don't leak database internals to the browser.
      return { error: /duplicate key|violates|relation|syntax/i.test(msg) ? (/duplicate key/.test(msg) ? "That name / slug is already in use." : "The change could not be saved.") : msg };
    }
  };
}
