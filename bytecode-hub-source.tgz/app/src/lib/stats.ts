import "server-only";
import { sql, type SQL } from "drizzle-orm";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
import type { SessionUser } from "@/lib/auth";
import { fromNepalInput } from "@/lib/format";

/**
 * Reporting queries. Everything is computed from stored records. Monetary figures come from the
 * manually entered "estimated value" field and are always labelled as estimates in the UI.
 */

export type ReportFilters = { campaign?: string; from?: string; to?: string; assigned?: string };

function scope(user: SessionUser, f: ReportFilters): SQL {
  const parts: SQL[] = [sql`l.merged_into IS NULL`];
  if (!can(user.role, "viewAllLeads")) parts.push(sql`(l.assigned_to = ${user.id} OR l.created_by = ${user.id})`);
  if (f.campaign) parts.push(sql`l.campaign_id = ${f.campaign}`);
  if (f.assigned) parts.push(sql`l.assigned_to = ${f.assigned}`);
  const from = f.from ? fromNepalInput(f.from) : null;
  const to = f.to ? fromNepalInput(`${f.to}T23:59`) : null;
  if (from) parts.push(sql`l.created_at >= ${from}`);
  if (to) parts.push(sql`l.created_at <= ${to}`);
  return sql.join(parts, sql` AND `);
}

type Row = { label: string; value: number; id?: string | null; color?: string | null; extra?: number };

export async function dashboardStats(user: SessionUser, f: ReportFilters = {}) {
  const where = scope(user, f);
  const [totals] = await db.execute<{
    total: number; new_7d: number; overdue: number; due_today: number; open_value: string | null; won_value: string | null;
    meetings_upcoming: number; duplicates: number; unassigned: number;
  }>(sql`
    SELECT
      count(*)::int AS total,
      count(*) FILTER (WHERE l.created_at >= now() - interval '7 days')::int AS new_7d,
      count(*) FILTER (WHERE l.next_follow_up_at < now() AND NOT s.is_won AND NOT s.is_lost)::int AS overdue,
      count(*) FILTER (WHERE l.next_follow_up_at >= now() AND l.next_follow_up_at < now() + interval '1 day' AND NOT s.is_won AND NOT s.is_lost)::int AS due_today,
      sum(l.estimated_value_npr) FILTER (WHERE NOT s.is_won AND NOT s.is_lost) AS open_value,
      sum(l.estimated_value_npr) FILTER (WHERE s.is_won) AS won_value,
      (SELECT count(*)::int FROM meetings m JOIN leads l2 ON l2.id = m.lead_id WHERE m.scheduled_at >= now() AND NOT m.completed AND l2.id IN (SELECT l.id FROM leads l WHERE ${where})) AS meetings_upcoming,
      count(*) FILTER (WHERE l.possible_duplicate_of IS NOT NULL AND NOT l.duplicate_reviewed)::int AS duplicates,
      count(*) FILTER (WHERE l.assigned_to IS NULL AND NOT s.is_won AND NOT s.is_lost)::int AS unassigned
    FROM leads l JOIN lead_statuses s ON s.id = l.status_id
    WHERE ${where}`);

  const byStatus = await db.execute<Row>(sql`
    SELECT s.id, s.name AS label, s.color, count(l.id)::int AS value
    FROM lead_statuses s LEFT JOIN leads l ON l.status_id = s.id AND ${where}
    WHERE s.active GROUP BY s.id ORDER BY s.sort_order`);

  const bySource = await db.execute<Row>(sql`
    SELECT coalesce(src.name, 'Not recorded') AS label, count(*)::int AS value
    FROM leads l LEFT JOIN lead_sources src ON src.id = l.source_id WHERE ${where}
    GROUP BY 1 ORDER BY 2 DESC, 1`);

  const byIndustry = await db.execute<Row>(sql`
    SELECT coalesce(i.name, 'Not recorded') AS label, count(*)::int AS value
    FROM leads l JOIN businesses b ON b.id = l.business_id LEFT JOIN industries i ON i.id = b.industry_id WHERE ${where}
    GROUP BY 1 ORDER BY 2 DESC, 1`);

  const byService = await db.execute<Row>(sql`
    SELECT es.label, count(*)::int AS value
    FROM leads l JOIN lead_services ls ON ls.lead_id = l.id JOIN enquiry_services es ON es.id = ls.enquiry_service_id WHERE ${where}
    GROUP BY es.label, es.sort_order ORDER BY 2 DESC, es.sort_order`);

  const weekly = await db.execute<{ week: string; value: number }>(sql`
    WITH weeks AS (SELECT generate_series(date_trunc('week', now() AT TIME ZONE 'Asia/Kathmandu') - interval '11 weeks', date_trunc('week', now() AT TIME ZONE 'Asia/Kathmandu'), interval '1 week') AS w)
    SELECT to_char(w, 'DD Mon') AS week, (SELECT count(*)::int FROM leads l WHERE ${where} AND date_trunc('week', l.created_at AT TIME ZONE 'Asia/Kathmandu') = w) AS value
    FROM weeks ORDER BY w`);

  const byEntry = await db.execute<Row>(sql`
    SELECT l.entry_type AS label, count(*)::int AS value FROM leads l WHERE ${where} GROUP BY 1 ORDER BY 2 DESC`);

  return {
    totals: {
      total: Number(totals.total), new7d: Number(totals.new_7d), overdue: Number(totals.overdue), dueToday: Number(totals.due_today),
      openValue: Number(totals.open_value ?? 0), wonValue: Number(totals.won_value ?? 0), meetingsUpcoming: Number(totals.meetings_upcoming),
      duplicates: Number(totals.duplicates), unassigned: Number(totals.unassigned),
    },
    byStatus: [...byStatus], bySource: [...bySource], byIndustry: [...byIndustry], byService: [...byService],
    weekly: [...weekly].map((w) => ({ label: w.week, value: Number(w.value) })), byEntry: [...byEntry],
  };
}

/** Funnel based on the furthest stage each lead has ever reached (from status history), not just its current status. */
export async function funnelStats(user: SessionUser, f: ReportFilters = {}) {
  const where = scope(user, f);
  const rows = await db.execute<{ id: string; name: string; sort_order: number; is_won: boolean; is_lost: boolean; reached: number; current: number }>(sql`
    WITH scoped AS (SELECT l.id, l.status_id FROM leads l WHERE ${where}),
    furthest AS (
      SELECT sc.id AS lead_id, max(s.sort_order) FILTER (WHERE NOT s.is_lost) AS max_order
      FROM scoped sc
      LEFT JOIN lead_status_history h ON h.lead_id = sc.id
      LEFT JOIN lead_statuses s ON s.id = h.to_status_id
      GROUP BY sc.id
    )
    SELECT s.id, s.name, s.sort_order, s.is_won, s.is_lost,
      (CASE WHEN s.is_lost THEN (SELECT count(*) FROM scoped sc WHERE sc.status_id = s.id)
            ELSE (SELECT count(*) FROM furthest fu WHERE fu.max_order >= s.sort_order) END)::int AS reached,
      (SELECT count(*) FROM scoped sc WHERE sc.status_id = s.id)::int AS current
    FROM lead_statuses s WHERE s.active ORDER BY s.sort_order`);
  return [...rows].map((r) => ({ ...r, reached: Number(r.reached), current: Number(r.current) }));
}

export async function campaignComparison(user: SessionUser) {
  const where = scope(user, {});
  const rows = await db.execute<{ id: string | null; name: string; total: number; qualified: number; won: number; lost: number; meetings: number; est_value: string | null }>(sql`
    SELECT c.id, coalesce(c.name, 'No campaign') AS name,
      count(l.id)::int AS total,
      count(l.id) FILTER (WHERE s.is_qualified)::int AS qualified,
      count(l.id) FILTER (WHERE s.is_won)::int AS won,
      count(l.id) FILTER (WHERE s.is_lost)::int AS lost,
      (SELECT count(*)::int FROM meetings m WHERE m.lead_id IN (SELECT l3.id FROM leads l3 WHERE l3.campaign_id IS NOT DISTINCT FROM c.id)) AS meetings,
      sum(l.estimated_value_npr) FILTER (WHERE NOT s.is_lost) AS est_value
    FROM leads l JOIN lead_statuses s ON s.id = l.status_id LEFT JOIN campaigns c ON c.id = l.campaign_id
    WHERE ${where}
    GROUP BY c.id, c.name ORDER BY total DESC`);
  return [...rows];
}

export async function teamPerformance(user: SessionUser, f: ReportFilters = {}) {
  const where = scope(user, f);
  const rows = await db.execute<{ name: string; total: number; won: number; overdue: number; activities: number }>(sql`
    SELECT coalesce(u.name, 'Unassigned') AS name, count(l.id)::int AS total,
      count(l.id) FILTER (WHERE s.is_won)::int AS won,
      count(l.id) FILTER (WHERE l.next_follow_up_at < now() AND NOT s.is_won AND NOT s.is_lost)::int AS overdue,
      (SELECT count(*)::int FROM activities a WHERE a.created_by = u.id AND a.type IN ('note','call','whatsapp','email','meeting') AND a.created_at >= now() - interval '30 days') AS activities
    FROM leads l JOIN lead_statuses s ON s.id = l.status_id LEFT JOIN users u ON u.id = l.assigned_to
    WHERE ${where} GROUP BY u.id, u.name ORDER BY total DESC`);
  return [...rows];
}

export async function lostReasons(user: SessionUser, f: ReportFilters = {}) {
  const where = scope(user, f);
  return [...(await db.execute<{ label: string; value: number }>(sql`
    SELECT coalesce(nullif(trim(l.lost_reason), ''), 'Not recorded') AS label, count(*)::int AS value
    FROM leads l JOIN lead_statuses s ON s.id = l.status_id WHERE ${where} AND s.is_lost GROUP BY 1 ORDER BY 2 DESC LIMIT 10`))];
}
