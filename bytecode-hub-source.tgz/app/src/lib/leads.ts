import "server-only";
import { and, asc, eq, ilike, inArray, isNull, ne, or, sql } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { normalizePhone } from "@/lib/utils";
import { enqueueLeadSync } from "@/lib/sheets";
import { QUESTION_SETS } from "@/lib/enquiry-config";

export type LeadInput = {
  entryType: "public_enquiry" | "internal" | "quick_capture";
  business: {
    name: string; industryId?: string | null; location?: string | null; address?: string | null;
    website?: string | null; facebook?: string | null; instagram?: string | null; otherLinks?: string | null;
  };
  contact: { fullName?: string | null; designation?: string | null; phone?: string | null; whatsapp?: string | null; email?: string | null };
  enquiryServiceIds?: string[];
  answers?: Record<string, Record<string, string>>;
  requirements?: string | null;
  initialInterest?: string | null;
  budgetRangeId?: string | null;
  budgetCustom?: string | null;
  estimatedValueNpr?: number | null;
  timeline?: string | null;
  preferredContactMethod?: string | null;
  meetingPreference?: string | null;
  comments?: string | null;
  consentToContact?: boolean;
  campaignId?: string | null;
  sourceId?: string | null;
  priority?: "hot" | "warm" | "cold" | null;
  assignedTo?: string | null;
  nextAction?: string | null;
  nextFollowUpAt?: Date | null;
  discussionNotes?: string | null;
  meeting?: { scheduledAt: Date; mode?: string; location?: string | null; agenda?: string | null; outcome?: string | null; completed?: boolean } | null;
  utm?: Record<string, string> | null;
  referrer?: string | null;
  landingPage?: string | null;
  clientRef?: string | null;
  createdBy?: string | null;
  ipHash?: string | null;
};

export type CreatedLead = { id: string; leadCode: string; duplicateOf: string | null; existing: boolean };

export async function getDefaultCampaign() {
  const rows = await db
    .select()
    .from(t.campaigns)
    .where(inArray(t.campaigns.status, ["active", "draft"]))
    .orderBy(sql`${t.campaigns.isDefault} DESC`, sql`${t.campaigns.status} = 'active' DESC`, asc(t.campaigns.createdAt))
    .limit(1);
  return rows[0] ?? null;
}

async function nextLeadCode(tx: Parameters<Parameters<typeof db.transaction>[0]>[0], prefix: string) {
  const year = Number(new Intl.DateTimeFormat("en", { timeZone: "Asia/Kathmandu", year: "numeric" }).format(new Date()));
  const clean = prefix.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6) || "BC";
  const rows = await tx.execute<{ value: number }>(sql`
    INSERT INTO lead_counters (prefix, year, value) VALUES (${clean}, ${year}, 1)
    ON CONFLICT (prefix, year) DO UPDATE SET value = lead_counters.value + 1
    RETURNING value`);
  return `${clean}-${year}-${String(rows[0].value).padStart(4, "0")}`;
}

/** Find an existing (unmerged) lead that looks like the same business/contact. */
export async function findPossibleDuplicate(input: { phone?: string | null; whatsapp?: string | null; email?: string | null; businessName: string; location?: string | null }, excludeLeadId?: string) {
  const phones = [normalizePhone(input.phone), normalizePhone(input.whatsapp)].filter(Boolean) as string[];
  const conds = [];
  if (phones.length) conds.push(inArray(t.contacts.phoneNormalized, phones));
  if (input.email) conds.push(sql`lower(${t.contacts.email}) = ${input.email.toLowerCase().trim()}`);
  const nameCond = input.location
    ? and(sql`lower(${t.businesses.name}) = ${input.businessName.toLowerCase().trim()}`, sql`lower(coalesce(${t.businesses.location}, '')) = ${input.location.toLowerCase().trim()}`)
    : sql`lower(${t.businesses.name}) = ${input.businessName.toLowerCase().trim()}`;
  conds.push(nameCond!);
  const rows = await db
    .select({ id: t.leads.id, leadCode: t.leads.leadCode })
    .from(t.leads)
    .innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId))
    .leftJoin(t.contacts, eq(t.contacts.businessId, t.businesses.id))
    .where(and(isNull(t.leads.mergedInto), or(...conds), excludeLeadId ? ne(t.leads.id, excludeLeadId) : undefined))
    .orderBy(asc(t.leads.createdAt))
    .limit(1);
  return rows[0] ?? null;
}

async function resolveSource(input: LeadInput) {
  if (input.sourceId) return input.sourceId;
  const utmSource = (input.utm?.utm_source ?? "").toLowerCase();
  let slug = "other";
  if (/(facebook|fb|instagram|ig|meta)/.test(utmSource)) slug = "meta-ads";
  else if (/whatsapp|wa/.test(utmSource)) slug = "whatsapp";
  else if (/linkedin/.test(utmSource)) slug = "linkedin";
  else if (input.entryType === "public_enquiry") slug = "website-enquiry";
  const rows = await db.select({ id: t.leadSources.id }).from(t.leadSources).where(eq(t.leadSources.slug, slug)).limit(1);
  return rows[0]?.id ?? null;
}

function computeComplete(input: LeadInput) {
  return Boolean(
    input.business.name && input.business.industryId && input.business.location &&
    (input.contact.phone || input.contact.email) && input.contact.fullName &&
    (input.enquiryServiceIds?.length ?? 0) > 0 && (input.requirements || input.initialInterest),
  );
}

/** Create a lead (DB first), then queue Google Sheets sync. Idempotent on clientRef. */
export async function createLead(input: LeadInput): Promise<CreatedLead> {
  if (input.clientRef) {
    const existing = await db.select({ id: t.leads.id, leadCode: t.leads.leadCode, dup: t.leads.possibleDuplicateOf }).from(t.leads).where(eq(t.leads.clientRef, input.clientRef)).limit(1);
    if (existing[0]) return { id: existing[0].id, leadCode: existing[0].leadCode, duplicateOf: existing[0].dup, existing: true };
  }

  const campaign = input.campaignId
    ? (await db.select().from(t.campaigns).where(eq(t.campaigns.id, input.campaignId)).limit(1))[0] ?? null
    : await getDefaultCampaign();
  const sourceId = await resolveSource(input);
  const [status] = await db.select().from(t.leadStatuses).where(eq(t.leadStatuses.active, true)).orderBy(asc(t.leadStatuses.sortOrder)).limit(1);
  if (!status) throw new Error("No lead statuses configured.");

  const dup = await findPossibleDuplicate({
    phone: input.contact.phone, whatsapp: input.contact.whatsapp, email: input.contact.email,
    businessName: input.business.name, location: input.business.location,
  });

  const result = await db.transaction(async (tx) => {
    const leadCode = await nextLeadCode(tx, campaign?.leadIdPrefix ?? "BC");
    const [business] = await tx.insert(t.businesses).values({
      name: input.business.name.trim(),
      industryId: input.business.industryId || null,
      location: input.business.location || null,
      address: input.business.address || null,
      website: input.business.website || null,
      facebook: input.business.facebook || null,
      instagram: input.business.instagram || null,
      otherLinks: input.business.otherLinks || null,
    }).returning({ id: t.businesses.id });

    const hasContact = Object.values(input.contact).some(Boolean);
    const contact = hasContact
      ? (await tx.insert(t.contacts).values({
          businessId: business.id,
          fullName: input.contact.fullName || null,
          designation: input.contact.designation || null,
          phone: input.contact.phone || null,
          phoneNormalized: normalizePhone(input.contact.phone) ?? normalizePhone(input.contact.whatsapp),
          whatsapp: input.contact.whatsapp || null,
          email: input.contact.email?.toLowerCase().trim() || null,
        }).returning({ id: t.contacts.id }))[0]
      : null;

    const [lead] = await tx.insert(t.leads).values({
      leadCode,
      businessId: business.id,
      contactId: contact?.id ?? null,
      campaignId: campaign?.id ?? null,
      sourceId,
      statusId: status.id,
      entryType: input.entryType,
      priority: input.priority ?? null,
      budgetRangeId: input.budgetRangeId || null,
      budgetCustom: input.budgetCustom || null,
      estimatedValueNpr: input.estimatedValueNpr != null ? String(input.estimatedValueNpr) : null,
      timeline: input.timeline || null,
      requirements: input.requirements || null,
      initialInterest: input.initialInterest || null,
      preferredContactMethod: input.preferredContactMethod || null,
      meetingPreference: input.meetingPreference || null,
      comments: input.comments || null,
      consentToContact: Boolean(input.consentToContact),
      consentAt: input.consentToContact ? new Date() : null,
      assignedTo: input.assignedTo || (input.entryType !== "public_enquiry" ? input.createdBy : null) || null,
      createdBy: input.createdBy || null,
      nextAction: input.nextAction || null,
      nextFollowUpAt: input.nextFollowUpAt ?? null,
      utm: input.utm && Object.keys(input.utm).length ? input.utm : null,
      referrer: input.referrer?.slice(0, 500) || null,
      landingPage: input.landingPage?.slice(0, 500) || null,
      clientRef: input.clientRef || null,
      possibleDuplicateOf: dup?.id ?? null,
      isComplete: computeComplete(input),
      ipHash: input.ipHash || null,
    }).returning({ id: t.leads.id, leadCode: t.leads.leadCode });

    if (input.enquiryServiceIds?.length) {
      await tx.insert(t.leadServices).values([...new Set(input.enquiryServiceIds)].map((enquiryServiceId) => ({ leadId: lead.id, enquiryServiceId }))).onConflictDoNothing();
    }
    const validSets = new Set(QUESTION_SETS.map((s) => s.key));
    for (const [setKey, answers] of Object.entries(input.answers ?? {})) {
      const clean = Object.fromEntries(Object.entries(answers).filter(([, v]) => v && String(v).trim()).map(([k, v]) => [k, String(v).slice(0, 4000)]));
      if (validSets.has(setKey) && Object.keys(clean).length) await tx.insert(t.leadRequirements).values({ leadId: lead.id, setKey, answers: clean });
    }
    await tx.insert(t.leadStatusHistory).values({ leadId: lead.id, toStatusId: status.id, changedBy: input.createdBy ?? null, note: "Lead created" });
    const via = { public_enquiry: "public enquiry form", internal: "internal lead entry", quick_capture: "quick prospect capture" }[input.entryType];
    await tx.insert(t.activities).values({ leadId: lead.id, type: "system", title: `Lead created via ${via}`, body: dup ? `Possible duplicate of ${dup.leadCode}` : null, createdBy: input.createdBy ?? null });
    if (input.discussionNotes) {
      await tx.insert(t.activities).values({ leadId: lead.id, type: "note", title: "Discussion notes", body: input.discussionNotes, createdBy: input.createdBy ?? null });
    }
    if (input.nextFollowUpAt) {
      await tx.insert(t.activities).values({
        leadId: lead.id, type: "follow_up", title: input.nextAction || "Follow up", dueAt: input.nextFollowUpAt,
        assignedTo: input.assignedTo || input.createdBy || null, createdBy: input.createdBy ?? null,
      });
    }
    if (input.meeting) {
      await tx.insert(t.meetings).values({
        leadId: lead.id, scheduledAt: input.meeting.scheduledAt, mode: input.meeting.mode ?? "in_person", location: input.meeting.location ?? null,
        agenda: input.meeting.agenda ?? null, outcome: input.meeting.outcome ?? null, completed: Boolean(input.meeting.completed), createdBy: input.createdBy ?? null,
      });
    }
    return lead;
  });

  await enqueueLeadSync(result.id);
  return { id: result.id, leadCode: result.leadCode, duplicateOf: dup?.id ?? null, existing: false };
}

/** Change status with history + timeline entry. Requires a reason when moving to a "lost" status. */
export async function changeLeadStatus(leadId: string, toStatusId: string, userId: string, note?: string | null) {
  const [lead] = await db.select({ statusId: t.leads.statusId }).from(t.leads).where(eq(t.leads.id, leadId));
  if (!lead || lead.statusId === toStatusId) return;
  const [to] = await db.select().from(t.leadStatuses).where(eq(t.leadStatuses.id, toStatusId));
  if (!to) throw new Error("Unknown status");
  if (to.isLost && !note?.trim()) throw new Error("Please give a reason when marking a lead as lost.");
  const [from] = await db.select().from(t.leadStatuses).where(eq(t.leadStatuses.id, lead.statusId));
  await db.transaction(async (tx) => {
    await tx.update(t.leads).set({ statusId: toStatusId, lostReason: to.isLost ? note!.trim() : null, updatedAt: new Date() }).where(eq(t.leads.id, leadId));
    await tx.insert(t.leadStatusHistory).values({ leadId, fromStatusId: lead.statusId, toStatusId, changedBy: userId, note: note || null });
    await tx.insert(t.activities).values({ leadId, type: "status_change", title: `Status: ${from?.name ?? "?"} → ${to.name}`, body: note || null, createdBy: userId });
  });
  await enqueueLeadSync(leadId);
}

/**
 * Merge a duplicate lead into a primary lead. Timeline, meetings, attachments, services and requirements
 * move to the primary; empty fields on the primary are filled from the duplicate; the duplicate is marked merged.
 */
export async function mergeLeads(duplicateId: string, primaryId: string, userId: string) {
  if (duplicateId === primaryId) throw new Error("Cannot merge a lead into itself.");
  const [dup] = await db.select().from(t.leads).where(eq(t.leads.id, duplicateId));
  const [primary] = await db.select().from(t.leads).where(eq(t.leads.id, primaryId));
  if (!dup || !primary) throw new Error("Lead not found");
  if (dup.mergedInto || primary.mergedInto) throw new Error("One of these leads has already been merged.");

  await db.transaction(async (tx) => {
    await tx.update(t.activities).set({ leadId: primaryId }).where(eq(t.activities.leadId, duplicateId));
    await tx.update(t.meetings).set({ leadId: primaryId }).where(eq(t.meetings.leadId, duplicateId));
    await tx.update(t.leadAttachments).set({ leadId: primaryId }).where(eq(t.leadAttachments.leadId, duplicateId));
    await tx.execute(sql`INSERT INTO lead_services (lead_id, enquiry_service_id) SELECT ${primaryId}, enquiry_service_id FROM lead_services WHERE lead_id = ${duplicateId} ON CONFLICT DO NOTHING`);
    await tx.execute(sql`INSERT INTO lead_requirements (lead_id, set_key, answers) SELECT ${primaryId}, set_key, answers FROM lead_requirements WHERE lead_id = ${duplicateId} ON CONFLICT (lead_id, set_key) DO NOTHING`);
    // Move the duplicate's contact to the primary business so no contact details are lost.
    if (dup.contactId) await tx.update(t.contacts).set({ businessId: primary.businessId, isPrimary: false }).where(eq(t.contacts.id, dup.contactId));
    const fill: Partial<typeof t.leads.$inferInsert> = {};
    const keys = ["requirements", "initialInterest", "budgetRangeId", "budgetCustom", "estimatedValueNpr", "timeline", "preferredContactMethod", "meetingPreference", "comments", "priority", "assignedTo", "nextAction", "nextFollowUpAt", "contactId"] as const;
    for (const k of keys) if (primary[k] == null && dup[k] != null) (fill as Record<string, unknown>)[k] = dup[k];
    if (Object.keys(fill).length) await tx.update(t.leads).set({ ...fill, updatedAt: new Date() }).where(eq(t.leads.id, primaryId));
    await tx.update(t.leads).set({ mergedInto: primaryId, duplicateReviewed: true, updatedAt: new Date() }).where(eq(t.leads.id, duplicateId));
    await tx.update(t.leads).set({ possibleDuplicateOf: null, duplicateReviewed: true }).where(and(eq(t.leads.possibleDuplicateOf, duplicateId), ne(t.leads.id, primaryId)));
    await tx.insert(t.activities).values({ leadId: primaryId, type: "system", title: `Merged duplicate lead ${dup.leadCode} into this lead`, createdBy: userId });
  });
  await enqueueLeadSync(primaryId);
  await enqueueLeadSync(duplicateId);
}

export async function searchLeadsForMerge(q: string, excludeId: string) {
  return db
    .select({ id: t.leads.id, leadCode: t.leads.leadCode, business: t.businesses.name })
    .from(t.leads)
    .innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId))
    .where(and(isNull(t.leads.mergedInto), ne(t.leads.id, excludeId), or(ilike(t.leads.leadCode, `%${q}%`), ilike(t.businesses.name, `%${q}%`))))
    .limit(10);
}
