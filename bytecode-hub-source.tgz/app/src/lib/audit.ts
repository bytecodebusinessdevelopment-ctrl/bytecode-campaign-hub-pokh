import "server-only";
import { db, t } from "@/lib/db";
import { clientIpHash } from "@/lib/request";

export async function audit(
  userId: string | null,
  action: string,
  entity: string,
  entityId?: string | null,
  details?: Record<string, unknown>,
) {
  try {
    await db.insert(t.auditLogs).values({
      userId, action, entity, entityId: entityId ?? null, details: details ?? null, ipHash: await clientIpHash().catch(() => null),
    });
  } catch (e) {
    console.error("[audit] failed", e);
  }
}
