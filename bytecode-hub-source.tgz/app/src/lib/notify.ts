import "server-only";
import { and, eq, inArray, isNull, lt, sql } from "drizzle-orm";
import { db, t } from "@/lib/db";
import { sendMail, emailLayout } from "@/lib/mail";
import { getSettings } from "@/lib/settings";
import { siteUrl } from "@/lib/request";
import { formatDate } from "@/lib/format";

export async function notifyUsers(userIds: string[], n: { type: string; title: string; body?: string; link?: string }, email = true) {
  const ids = [...new Set(userIds.filter(Boolean))];
  if (!ids.length) return;
  await db.insert(t.notifications).values(ids.map((userId) => ({ userId, ...n })));
  if (!email) return;
  const recipients = await db.select({ email: t.users.email }).from(t.users).where(and(inArray(t.users.id, ids), eq(t.users.active, true)));
  await sendMail({
    to: recipients.map((r) => r.email),
    subject: n.title,
    html: emailLayout(n.title, [n.body ?? ""], n.link ? { label: "Open in dashboard", url: siteUrl(n.link) } : undefined),
    text: `${n.title}\n\n${n.body ?? ""}\n\n${n.link ? siteUrl(n.link) : ""}`,
  });
}

/** New public enquiry → all admins & managers (+ assignee) and any extra notification emails in settings. */
export async function notifyNewEnquiry(lead: { id: string; leadCode: string; businessName: string; services: string[]; assignedTo?: string | null }) {
  const staff = await db.select({ id: t.users.id }).from(t.users).where(and(eq(t.users.active, true), inArray(t.users.role, ["admin", "manager"])));
  const title = `New enquiry ${lead.leadCode}: ${lead.businessName}`;
  const body = `Interested in: ${lead.services.join(", ") || "not specified"}`;
  await notifyUsers([...staff.map((s) => s.id), lead.assignedTo ?? ""], { type: "new_lead", title, body, link: `/admin/leads/${lead.id}` });
  const s = await getSettings();
  if (s.notificationEmails.length) {
    await sendMail({ to: s.notificationEmails, subject: title, html: emailLayout(title, [body], { label: "Open lead", url: siteUrl(`/admin/leads/${lead.id}`) }) });
  }
}

export async function sendEnquiryAcknowledgement(to: string, name: string | null, leadCode: string) {
  const s = await getSettings();
  await sendMail({
    to,
    subject: `We received your enquiry (${leadCode}) — ${s.companyName}`,
    html: emailLayout(`Thank you${name ? `, ${name}` : ""}!`, [
      `We have received your enquiry. Your reference number is ${leadCode}.`,
      "A member of our team will review your requirements and get back to you soon.",
      `If you need to reach us sooner: ${[s.phone, s.email].filter(Boolean).join(" · ")}`,
    ]),
  });
}

/**
 * Daily digest: each active user receives their due-today and overdue follow-ups.
 * Also creates in-app notifications for overdue items. Called by /api/cron/daily.
 */
export async function sendDailyFollowUpDigest() {
  const endOfToday = new Date(Date.now() + 24 * 3600 * 1000);
  const rows = await db
    .select({
      leadId: t.leads.id, leadCode: t.leads.leadCode, business: t.businesses.name, nextAction: t.leads.nextAction,
      due: t.leads.nextFollowUpAt, userId: t.leads.assignedTo, createdBy: t.leads.createdBy,
    })
    .from(t.leads)
    .innerJoin(t.businesses, eq(t.businesses.id, t.leads.businessId))
    .innerJoin(t.leadStatuses, eq(t.leadStatuses.id, t.leads.statusId))
    .where(and(lt(t.leads.nextFollowUpAt, endOfToday), isNull(t.leads.mergedInto), eq(t.leadStatuses.isWon, false), eq(t.leadStatuses.isLost, false)));

  const byUser = new Map<string, typeof rows>();
  for (const r of rows) {
    const uid = r.userId ?? r.createdBy;
    if (!uid) continue;
    byUser.set(uid, [...(byUser.get(uid) ?? []), r]);
  }
  let emails = 0;
  for (const [userId, items] of byUser) {
    const [u] = await db.select().from(t.users).where(and(eq(t.users.id, userId), eq(t.users.active, true)));
    if (!u) continue;
    const overdue = items.filter((i) => i.due && i.due.getTime() < Date.now());
    if (overdue.length) {
      await db.insert(t.notifications).values({
        userId, type: "overdue", title: `${overdue.length} overdue follow-up${overdue.length > 1 ? "s" : ""}`,
        body: overdue.slice(0, 5).map((o) => `${o.leadCode} ${o.business}`).join(", "), link: "/admin/follow-ups?tab=overdue",
      });
    }
    const lines = items.map((i) => `• ${i.leadCode} — ${i.business} — ${i.nextAction ?? "Follow up"} (${formatDate(i.due)}${i.due && i.due.getTime() < Date.now() ? ", OVERDUE" : ""})`);
    const res = await sendMail({
      to: u.email,
      subject: `Your follow-ups for today (${items.length})`,
      html: emailLayout(`Good morning, ${u.name.split(" ")[0]}`, [`You have ${items.length} follow-up(s) due today or overdue:`, lines.join("\n")], { label: "Open follow-ups", url: siteUrl("/admin/follow-ups") }),
    });
    if (res.sent) emails++;
  }
  return { users: byUser.size, emails, items: rows.length };
}

export async function unreadCount(userId: string) {
  const [r] = await db.select({ n: sql<number>`count(*)::int` }).from(t.notifications).where(and(eq(t.notifications.userId, userId), isNull(t.notifications.readAt)));
  return Number(r?.n ?? 0);
}

