import { z } from "zod";
import { isValidPhone } from "@/lib/utils";

const opt = (max = 500) => z.string().trim().max(max).optional().nullable().transform((v) => (v ? v : null));
const phone = z.string().trim().max(30).refine((v) => isValidPhone(v), { message: "Enter a valid phone number (e.g. 98XXXXXXXX or +977…)" });
const optPhone = z.string().trim().max(30).optional().nullable().transform((v) => (v ? v : null)).refine((v) => !v || isValidPhone(v), { message: "Enter a valid phone number" });
const optEmail = z.string().trim().max(200).optional().nullable().transform((v) => (v ? v.toLowerCase() : null)).refine((v) => !v || z.string().email().safeParse(v).success, { message: "Enter a valid email address" });
const uuidOpt = z.string().uuid().optional().nullable().or(z.literal("")).transform((v) => (v ? v : null));

export const publicEnquirySchema = z.object({
  business: z.object({
    name: z.string().trim().min(2, "Business name is required").max(200),
    industryId: uuidOpt,
    location: z.string().trim().min(2, "Location is required").max(200),
    address: opt(300), website: opt(300), facebook: opt(300), instagram: opt(300), otherLinks: opt(500),
  }),
  contact: z.object({
    fullName: z.string().trim().min(2, "Your name is required").max(150),
    designation: opt(150),
    phone,
    whatsapp: optPhone,
    email: optEmail,
  }),
  serviceIds: z.array(z.string().uuid()).min(1, "Please choose at least one service").max(20),
  answers: z.record(z.string(), z.record(z.string(), z.string().max(4000))).optional().default({}),
  requirements: z.string().trim().min(10, "Please describe your requirements (at least a sentence)").max(8000),
  budgetRangeId: uuidOpt,
  budgetCustom: opt(200),
  timeline: opt(100),
  preferredContactMethod: opt(100),
  meetingPreference: opt(100),
  comments: opt(4000),
  consent: z.literal(true, { message: "Please agree so we can contact you about your enquiry" }),
  clientRef: z.string().trim().min(8).max(64),
  attribution: z.object({ utm: z.record(z.string(), z.string().max(200)).optional(), referrer: z.string().max(500).optional(), landingPage: z.string().max(500).optional() }).optional().nullable(),
  formToken: z.string().max(100),
  hp: z.string().max(200).optional(),
  turnstileToken: z.string().max(4000).optional().nullable(),
});
export type PublicEnquiryInput = z.input<typeof publicEnquirySchema>;

export const quickCaptureSchema = z.object({
  businessName: z.string().trim().min(2, "Business name is required").max(200),
  industryId: uuidOpt,
  location: opt(200),
  phone: optPhone,
  contactName: opt(150),
  website: opt(300),
  initialInterest: opt(1000),
  serviceIds: z.array(z.string().uuid()).max(20).optional().default([]),
  notes: opt(4000),
  priority: z.enum(["hot", "warm", "cold"]).optional().nullable(),
  clientRef: z.string().trim().min(8).max(64),
});

export const contactFormSchema = z.object({
  name: z.string().trim().min(2, "Your name is required").max(150),
  business: z.string().trim().min(2, "Business name is required").max(200),
  phone,
  email: optEmail,
  message: z.string().trim().min(5, "Please write a short message").max(4000),
  consent: z.literal(true, { message: "Please agree so we can reply" }),
  clientRef: z.string().trim().min(8).max(64),
  formToken: z.string().max(100),
  hp: z.string().max(200).optional(),
  attribution: z.object({ utm: z.record(z.string(), z.string().max(200)).optional(), referrer: z.string().max(500).optional(), landingPage: z.string().max(500).optional() }).optional().nullable(),
});

export function flattenErrors(err: z.ZodError) {
  const out: Record<string, string> = {};
  for (const issue of err.issues) {
    const key = issue.path.join(".");
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}
