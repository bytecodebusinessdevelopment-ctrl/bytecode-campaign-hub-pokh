import "server-only";
import { createHmac, timingSafeEqual } from "crypto";

/** Signed timestamp embedded in public forms: rejects bots that submit instantly or replay very old tokens. */
export function issueFormToken() {
  const ts = Date.now().toString(36);
  const sig = createHmac("sha256", process.env.APP_SECRET ?? "dev").update(`form:${ts}`).digest("base64url").slice(0, 22);
  return `${ts}.${sig}`;
}

export function checkFormToken(token: string | undefined | null, minSeconds = 4, maxHours = 48): { ok: boolean; reason?: string } {
  if (!token) return { ok: false, reason: "missing" };
  const [ts, sig] = token.split(".");
  if (!ts || !sig) return { ok: false, reason: "malformed" };
  const expected = createHmac("sha256", process.env.APP_SECRET ?? "dev").update(`form:${ts}`).digest("base64url").slice(0, 22);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return { ok: false, reason: "bad signature" };
  const age = Date.now() - parseInt(ts, 36);
  if (age < minSeconds * 1000) return { ok: false, reason: "too fast" };
  if (age > maxHours * 3600 * 1000) return { ok: false, reason: "expired" };
  return { ok: true };
}

export async function verifyTurnstile(token: string | undefined | null, ip: string) {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) return true; // not configured — honeypot + timing + rate limit still apply
  if (!token) return false;
  try {
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body: new URLSearchParams({ secret, response: token, remoteip: ip }),
      signal: AbortSignal.timeout(8000),
    });
    const json = (await res.json()) as { success: boolean };
    return json.success;
  } catch {
    return false;
  }
}
