-- ─────────────────────────────────────────────────────────────────────────────
-- Supabase hardening (run once in Supabase → SQL Editor after `npm run db:migrate`)
--
-- The Campaign Hub talks to Postgres ONLY from the server, using the database
-- connection string. Supabase additionally exposes every table in the `public`
-- schema through its auto-generated REST/GraphQL API (PostgREST) to anyone holding
-- the project's "anon" key. This script closes that door at the DATABASE level:
--   • Row Level Security is enabled on every table with NO policies → the `anon`
--     and `authenticated` API roles can read/write nothing.
--   • Direct privileges for those roles are revoked as a second layer.
-- The application's own connection (role `postgres`) bypasses RLS and keeps working.
-- Re-run after adding new tables in future migrations.
-- ─────────────────────────────────────────────────────────────────────────────
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', r.tablename);
  END LOOP;
END $$;

-- RLS is not FORCED, so the table owner (the role that ran the migrations and that the app connects as)
-- is unaffected. Make sure DATABASE_URL uses that same role (on Supabase: `postgres`).

REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon, authenticated;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon, authenticated;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON SEQUENCES FROM anon, authenticated;

-- Verify: should return 0 rows
SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND NOT rowsecurity;
