/**
 * Create or reset an administrator account.
 *   ADMIN_EMAIL=you@company.com ADMIN_PASSWORD='a-strong-password' ADMIN_NAME='Your Name' npm run create-admin
 */
import "dotenv/config";
import postgres from "postgres";
import bcrypt from "bcryptjs";

async function main() {
  const email = process.env.ADMIN_EMAIL?.toLowerCase().trim();
  const password = process.env.ADMIN_PASSWORD;
  const name = process.env.ADMIN_NAME || "Administrator";
  if (!email || !password) throw new Error("Set ADMIN_EMAIL and ADMIN_PASSWORD");
  if (password.length < 10) throw new Error("ADMIN_PASSWORD must be at least 10 characters");
  const sql = postgres(process.env.DATABASE_URL!, { max: 1, ssl: process.env.DATABASE_SSL === "require" ? "require" : undefined, prepare: false });
  const hash = await bcrypt.hash(password, 12);
  const existing = await sql`SELECT id FROM users WHERE lower(email) = ${email}`;
  if (existing.length) {
    await sql`UPDATE users SET password_hash = ${hash}, role = 'admin', active = true, name = ${name}, updated_at = now() WHERE id = ${existing[0].id}`;
    await sql`DELETE FROM sessions WHERE user_id = ${existing[0].id}`;
    console.log(`✔ Updated administrator ${email} (password reset, sessions revoked)`);
  } else {
    await sql`INSERT INTO users (name, email, role, password_hash) VALUES (${name}, ${email}, 'admin', ${hash})`;
    console.log(`✔ Created administrator ${email}`);
  }
  await sql.end();
}
main().catch((e) => { console.error(e.message); process.exit(1); });
