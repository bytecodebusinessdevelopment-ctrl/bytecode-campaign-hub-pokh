/**
 * Seed script — safe to run repeatedly (upserts by slug/key).
 *
 * Seeds ONLY configuration and ByteCode-supplied facts:
 *  - lookup lists from the development brief (industries, project types, resource categories, lead sources,
 *    pipeline statuses, NPR budget ranges)
 *  - the eight service pages and the enquiry service checklist
 *  - clearly-labelled, UNPUBLISHED placeholder packages (no invented prices or deliverables)
 *  - the Pokhara campaign
 *  - portfolio project names listed on bytecodedevelopers.com/portfolio as UNPUBLISHED drafts for verification
 *  - the first administrator account (from ADMIN_EMAIL / ADMIN_PASSWORD)
 */
import "dotenv/config";
import postgres from "postgres";
import { drizzle } from "drizzle-orm/postgres-js";
import { eq, sql } from "drizzle-orm";
import bcrypt from "bcryptjs";
import * as t from "../src/lib/db/schema";

const client = postgres(process.env.DATABASE_URL!, { max: 1, ssl: process.env.DATABASE_SSL === "require" ? "require" : undefined, prepare: false });
const db = drizzle(client, { schema: t });

const slug = (s: string) => s.toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

// eslint-disable-next-line @typescript-eslint/no-explicit-any -- generic helper over several lookup tables
async function upsertBySlug<T extends { slug: string }>(table: any, rows: T[]) {
  for (const row of rows) {
    await db.insert(table).values(row).onConflictDoNothing({ target: table.slug });
  }
}

const INDUSTRIES = [
  "Travel, Tours and Trekking", "NGOs and INGOs", "Healthcare and Clinics", "E-commerce and Retail",
  "Corporate and Professional Services", "Hospitality and Restaurants", "Education", "Other Industries",
];
const PROJECT_TYPES = [
  "Business websites", "E-commerce websites", "Web applications", "Mobile applications",
  "Custom management systems", "UI/UX projects", "Digital marketing projects", "Other project types",
];
const RESOURCE_CATEGORIES = [
  "Company Profile", "Service Brochures", "Website Development Packages", "SEO Packages", "Travel SEO Samples",
  "Content Writing Samples", "Video Portfolio", "Project Case Studies", "Technical Demonstrations",
  "Proposals and Presentations", "Other Resources",
];
const LEAD_SOURCES = [
  ["Pokhara physical visit", "pokhara-physical-visit"], ["Meta Ads", "meta-ads"], ["Website enquiry", "website-enquiry"],
  ["WhatsApp", "whatsapp"], ["Phone call", "phone-call"], ["Email", "email"], ["Referral", "referral"],
  ["LinkedIn", "linkedin"], ["Existing relationship", "existing-relationship"], ["Other", "other"],
];
const STATUSES = [
  { name: "New", slug: "new", color: "#2878A8" },
  { name: "Contacted", slug: "contacted", color: "#6366F1" },
  { name: "Meeting Scheduled", slug: "meeting-scheduled", color: "#0EA5E9" },
  { name: "Qualified", slug: "qualified", color: "#269B83", isQualified: true },
  { name: "Proposal Sent", slug: "proposal-sent", color: "#D97706", isQualified: true },
  { name: "Negotiation", slug: "negotiation", color: "#A855F7", isQualified: true },
  { name: "Won", slug: "won", color: "#16A34A", isQualified: true, isWon: true },
  { name: "Lost", slug: "lost", color: "#DC2626", isLost: true },
];
const BUDGETS: [string, number | null, number | null][] = [
  ["Below Rs. 50,000", null, 50000],
  ["Rs. 50,000 – 1,00,000", 50000, 100000],
  ["Rs. 1,00,000 – 2,50,000", 100000, 250000],
  ["Rs. 2,50,000 – 5,00,000", 250000, 500000],
  ["Rs. 5,00,000 – 10,00,000", 500000, 1000000],
  ["Above Rs. 10,00,000", 1000000, null],
];

type ServiceSeed = {
  slug: string; name: string; groupKey: string; icon: string; tagline: string; summary: string; description: string;
  offerings: string[]; sections?: { title: string; body: string }[]; pricingNote?: string;
};

const SERVICES: ServiceSeed[] = [
  {
    slug: "website-development", name: "Website Development", groupKey: "development", icon: "globe",
    tagline: "Fast, responsive websites that turn visitors into enquiries.",
    summary: "Business, corporate, NGO, travel and e-commerce websites — designed, built, launched and maintained by one team.",
    description: "Your website is often the first conversation a customer has with your business. We plan, design and build websites that load quickly on mobile, are easy for you to update, and are structured for search engines from day one. After launch we can continue managing, maintaining and improving the site for you.",
    offerings: ["Business websites", "Corporate websites", "NGO and INGO websites", "Travel and tourism websites", "E-commerce websites", "Educational and healthcare websites", "Website redesign", "Website management", "Maintenance and support"],
    sections: [
      { title: "How we work", body: "Discovery of your goals and audience → sitemap and content plan → design → development → testing on real devices → launch → ongoing support." },
    ],
    pricingNote: "Standard website packages are being finalised. Request a quotation and we will recommend the right scope for your business.",
  },
  {
    slug: "application-development", name: "Application Development", groupKey: "development", icon: "smartphone",
    tagline: "Web and mobile apps built around how your customers and team actually work.",
    summary: "Web applications, Android and iOS apps, customer portals and booking applications.",
    description: "When a website is not enough, an application lets your customers book, buy, track and interact with your business — and lets your team manage it all from one place. We design and develop web and mobile applications tailored to your requirements.",
    offerings: ["Web applications", "Mobile applications (Android & iOS)", "Customer portals", "Booking applications", "Custom application solutions"],
    pricingNote: "Applications are quoted individually because pricing depends on features, platforms and integrations.",
  },
  {
    slug: "system-software-development", name: "System & Software Development", groupKey: "development", icon: "server",
    tagline: "Replace spreadsheets and manual work with software that fits your business.",
    summary: "Custom management systems, CRM, booking, inventory, reporting dashboards and business automation.",
    description: "Many growing businesses run on spreadsheets, paper and WhatsApp messages. We build custom systems that bring your data and workflows into one place, automate repetitive tasks and give management clear, real-time reporting.",
    offerings: ["Inventory management", "Procurement management", "CRM", "Booking management", "Staff and workflow management", "Reporting dashboards", "Business automation", "Custom ERP or management systems"],
    pricingNote: "Systems are quoted after a short requirements discussion.",
  },
  {
    slug: "seo", name: "SEO Services", groupKey: "growth", icon: "search",
    tagline: "Be found by the customers already searching for what you offer.",
    summary: "Technical, on-page and off-page SEO, keyword research, content and monthly reporting.",
    description: "Search engine optimisation helps the right people find your business on Google and other search and AI-assisted platforms. We review your website's technical health, improve on-page content and structure, research the keywords your customers use, and report progress every month. We do not promise specific rankings — no honest SEO provider can — but we do commit to transparent work and reporting.",
    offerings: ["Technical SEO", "On-page SEO", "Off-page SEO", "Keyword research", "SEO content production", "Monthly reporting", "Performance monitoring", "Local SEO for Google Business Profile"],
    pricingNote: "Tiered monthly SEO packages (Starter, Growth, Advanced) are being finalised.",
  },
  {
    slug: "travel-tourism-seo-content", name: "Travel & Tourism SEO Content", groupKey: "growth", icon: "mountain",
    tagline: "Itineraries and destination content that bring travellers to your website.",
    summary: "Trekking itineraries, destination and activity pages, tour package descriptions and SEO blogs for travel businesses.",
    description: "Travellers research extensively before they book. Structured, accurate and search-friendly content — detailed itineraries, destination guides, activity pages and package descriptions — helps tour operators, trekking agencies and hotels attract relevant search traffic and turn it into enquiries. This service is designed especially for Pokhara and the wider Nepal tourism industry.",
    offerings: ["Travel itinerary writing", "Trekking itinerary content", "Destination pages", "Attraction and activity pages", "Tour package descriptions", "SEO blog writing", "Travel website content", "Keyword-focused landing pages", "Travel website optimisation"],
    sections: [
      { title: "Why structured travel content works", body: "Search engines reward pages that answer travellers' real questions: how many days, how difficult, what's included, when to go, what it costs. Consistent, well-structured itinerary and destination pages build topical authority over time, help each package rank for its own searches, and give visitors the confidence to send an enquiry." },
    ],
    pricingNote: "Pricing depends on content type and volume. Request a quotation with your destinations and packages.",
  },
  {
    slug: "content-writing", name: "Content Writing", groupKey: "creative", icon: "pen-line",
    tagline: "Clear, persuasive words for your website and marketing.",
    summary: "Website content, service pages, blogs, articles, business descriptions, SEO content and marketing copy.",
    description: "Good content explains what you do, why it matters and what the reader should do next. Our writers produce website and marketing content that is accurate, on-brand and written with search in mind.",
    offerings: ["Website content", "Service pages", "Blog posts", "Articles", "Business descriptions", "SEO content", "Marketing copy"],
  },
  {
    slug: "digital-marketing-video", name: "Digital Marketing & Video Production", groupKey: "creative", icon: "megaphone",
    tagline: "Campaigns and videos that put your business in front of the right people.",
    summary: "Social media marketing, Meta advertising creatives, promotional and short-form videos, and campaign planning.",
    description: "We plan and run social media and advertising campaigns, and produce the creatives and videos that make them work — from business introduction videos to short-form reels and product promotions.",
    offerings: ["Social media marketing", "Meta advertising creatives", "Promotional videos", "Business introduction videos", "Short-form videos", "Product and service promotional videos", "Campaign planning", "Digital advertising support"],
  },
  {
    slug: "business-automation-consulting", name: "Business Automation & Technology Consulting", groupKey: "consulting", icon: "workflow",
    tagline: "Practical technology advice and automation for growing businesses.",
    summary: "Process review and digitisation, workflow automation, systems integration and technology advice.",
    description: "Not sure which software you need, or how to connect the tools you already use? We review how your business works today, identify what can be digitised or automated, and recommend — or build — the right solution.",
    offerings: ["Business process review and digitisation", "Workflow automation", "Integration of existing tools and systems", "Technology and software selection advice", "IT and digital transformation consulting"],
    pricingNote: "Consulting and automation are quoted based on scope.",
  },
];

const ENQUIRY_SERVICES: [string, string, string | null][] = [
  ["website", "Website development", "website-development"],
  ["redesign", "Website redesign", "website-development"],
  ["management", "Website management", "website-development"],
  ["ecommerce", "E-commerce", "website-development"],
  ["app", "Application development", "application-development"],
  ["system", "System development", "system-software-development"],
  ["seo", "SEO", "seo"],
  ["travel", "Travel SEO content", "travel-tourism-seo-content"],
  ["content", "General content writing", "content-writing"],
  ["marketing", "Digital marketing", "digital-marketing-video"],
  ["video", "Video production", "digital-marketing-video"],
  ["automation", "Business automation and consulting", "business-automation-consulting"],
  ["other", "Other", null],
];

const PLACEHOLDER_PACKAGES: { service: string; name: string; target: string }[] = [
  { service: "website-development", name: "Starter Website", target: "Small businesses needing a professional online presence" },
  { service: "website-development", name: "Business Website", target: "Growing businesses needing more pages and features" },
  { service: "website-development", name: "E-commerce Website", target: "Businesses selling products online" },
  { service: "seo", name: "SEO Starter", target: "Small local businesses starting with SEO" },
  { service: "seo", name: "SEO Growth", target: "Businesses competing in their city or region" },
  { service: "seo", name: "SEO Advanced", target: "Competitive or national / international markets" },
];

/** Project names as listed on ByteCode's own website (bytecodedevelopers.com/portfolio, retrieved Nov 2026). */
const PORTFOLIO_DRAFTS: [string, string, string][] = [
  ["New Century International Recruitment Website", "Corporate and Professional Services", "Business websites"],
  ["AAA Orange: Hong Kong Fashion E-commerce Store", "E-commerce and Retail", "E-commerce websites"],
  ["Banke UNESCO Club: Humanitarian & Community Development Website", "NGOs and INGOs", "Business websites"],
  ["Disabled Care Nepal: Accessibility & Inclusion Website", "NGOs and INGOs", "Business websites"],
  ["Center for Disabled Children Assistance: NGO Website", "NGOs and INGOs", "Business websites"],
  ["Nepal Eco Green: Energy-Saving Solutions Website", "Corporate and Professional Services", "Business websites"],
  ["Boundless Adventure: Trekking & Expedition Booking Platform", "Travel, Tours and Trekking", "Business websites"],
  ["City Interiors Pvt. Ltd — Interior Design Company Website", "Corporate and Professional Services", "Business websites"],
  ["Chaulagai Business Solution Pvt. Ltd", "Corporate and Professional Services", "Business websites"],
  ["Chaulagai Herbal Pvt. Ltd", "E-commerce and Retail", "Business websites"],
  ["Sagittarius Outsourcing and Tech Services", "Corporate and Professional Services", "Business websites"],
  ["Fitlife Traders — Healthcare Solutions", "Healthcare and Clinics", "Business websites"],
  ["Fewa Law Associates", "Corporate and Professional Services", "Business websites"],
  ["IP Law Firm Nepal", "Corporate and Professional Services", "Business websites"],
  ["Imperial Law Associates", "Corporate and Professional Services", "Business websites"],
  ["Parbat Samaj", "NGOs and INGOs", "Business websites"],
  ["Marriage Registration Nepal", "Corporate and Professional Services", "Business websites"],
  ["Lawneeti Associates", "Corporate and Professional Services", "Business websites"],
  ["Tesseract HRMS: Recruitment Management Portal", "Corporate and Professional Services", "Custom management systems"],
];

async function main() {
  console.log("Seeding lookups…");
  await upsertBySlug(t.industries, INDUSTRIES.map((name, i) => ({ name, slug: slug(name), sortOrder: i })));
  await upsertBySlug(t.projectTypes, PROJECT_TYPES.map((name, i) => ({ name, slug: slug(name), sortOrder: i })));
  await upsertBySlug(t.resourceCategories, RESOURCE_CATEGORIES.map((name, i) => ({ name, slug: slug(name), sortOrder: i })));
  await upsertBySlug(t.leadStatuses, STATUSES.map((s, i) => ({ ...s, sortOrder: i })));
  const existingBudgets = await db.select().from(t.budgetRanges);
  if (!existingBudgets.length) await db.insert(t.budgetRanges).values(BUDGETS.map(([label, minNpr, maxNpr], i) => ({ label, minNpr, maxNpr, sortOrder: i })));

  console.log("Seeding campaign…");
  await db.insert(t.campaigns).values({
    name: "Pokhara Business Development Campaign", slug: "pokhara", location: "Pokhara, Gandaki Province", leadIdPrefix: "POK",
    status: "active", isDefault: true,
    heroTitle: "Your Business. Digitally Ahead.",
    heroSubtitle: "ByteCode Developers is meeting businesses across Pokhara — from tourism and hospitality to healthcare, education and retail — to help them build, grow and succeed online.",
    landingIntro: "Whether you run a trekking agency in Lakeside, a hotel, a clinic or a growing local business, we can show you live examples of our work and talk through what would help your business most.",
    sheetTab: "Pokhara Leads",
  }).onConflictDoNothing({ target: t.campaigns.slug });
  const [pokhara] = await db.select().from(t.campaigns).where(eq(t.campaigns.slug, "pokhara"));

  for (const [i, [name, s]] of LEAD_SOURCES.entries()) {
    await db.insert(t.leadSources).values({ name, slug: s, sortOrder: i, campaignId: s === "pokhara-physical-visit" ? pokhara.id : null }).onConflictDoNothing({ target: t.leadSources.slug });
  }

  console.log("Seeding services…");
  for (const [i, s] of SERVICES.entries()) {
    await db.insert(t.services).values({ ...s, sections: s.sections ?? [], sortOrder: i, published: true }).onConflictDoNothing({ target: t.services.slug });
  }
  const svc = Object.fromEntries((await db.select().from(t.services)).map((s) => [s.slug, s.id]));
  for (const [i, [key, label, s]] of ENQUIRY_SERVICES.entries()) {
    await db.insert(t.enquiryServices).values({ key, label, serviceId: s ? svc[s] : null, sortOrder: i }).onConflictDoNothing({ target: t.enquiryServices.key });
  }
  for (const [i, p] of PLACEHOLDER_PACKAGES.entries()) {
    await db.insert(t.packages).values({
      serviceId: svc[p.service], name: p.name, slug: slug(p.name), targetAudience: p.target,
      description: "PLACEHOLDER — ByteCode to supply the approved description, price, deliverables, exclusions and delivery period before publishing.",
      priceType: "tbc", isPlaceholder: true, published: false, sortOrder: i,
    }).onConflictDoNothing();
  }

  console.log("Seeding portfolio drafts (unpublished)…");
  const ind = Object.fromEntries((await db.select().from(t.industries)).map((x) => [x.name, x.id]));
  const pt = Object.fromEntries((await db.select().from(t.projectTypes)).map((x) => [x.name, x.id]));
  for (const [i, [title, industry, type]] of PORTFOLIO_DRAFTS.entries()) {
    await db.insert(t.portfolioProjects).values({
      slug: slug(title).slice(0, 70), title, industryId: ind[industry] ?? null, projectTypeId: pt[type] ?? null,
      classification: "client_project", status: "draft", sortOrder: i,
      internalNote: "Imported from the project list on bytecodedevelopers.com/portfolio (Nov 2026). Before publishing: confirm the industry/type, add a description, screenshots and live URL, and confirm the client agrees to their name being shown.",
    }).onConflictDoNothing({ target: t.portfolioProjects.slug });
  }

  const adminEmail = process.env.ADMIN_EMAIL;
  const adminPassword = process.env.ADMIN_PASSWORD;
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(t.users).where(eq(t.users.role, "admin"));
  if (!Number(n) && adminEmail && adminPassword) {
    console.log(`Creating first administrator ${adminEmail}…`);
    await db.insert(t.users).values({
      name: process.env.ADMIN_NAME || "Administrator", email: adminEmail.toLowerCase(), role: "admin",
      passwordHash: await bcrypt.hash(adminPassword, 12), mustChangePassword: false,
    });
  } else if (!Number(n)) {
    console.log("⚠ No administrator exists. Set ADMIN_EMAIL and ADMIN_PASSWORD and run `npm run create-admin`.");
  }
  console.log("✔ Seed complete");
  await client.end();
}

main().catch(async (e) => { console.error(e); await client.end(); process.exit(1); });
