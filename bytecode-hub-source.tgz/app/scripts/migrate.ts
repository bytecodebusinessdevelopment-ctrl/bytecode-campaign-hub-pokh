import "dotenv/config";
import postgres from "postgres";
import { drizzle } from "drizzle-orm/postgres-js";
import { migrate } from "drizzle-orm/postgres-js/migrator";

async function main() {
  const sql = postgres(process.env.DATABASE_URL!, { max: 1, ssl: process.env.DATABASE_SSL === "require" ? "require" : undefined, prepare: false });
  await migrate(drizzle(sql), { migrationsFolder: "./drizzle" });
  console.log("✔ Migrations applied");
  await sql.end();
}
main().catch((e) => { console.error(e); process.exit(1); });
