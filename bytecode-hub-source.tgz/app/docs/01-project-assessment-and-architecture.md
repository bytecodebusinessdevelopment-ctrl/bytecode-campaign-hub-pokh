# 1. Project assessment and architecture

This document records Stages 1–3 of the brief: discovery, architecture and design direction, and the decisions taken.

## 1.1 What was reviewed

| Material | Status | Notes |
|---|---|---|
| Master development prompt (v1.1) | ✅ Provided | Proofread and revised before the build began |
| Existing website, bytecodedevelopers.com | ✅ Reviewed (public pages) | Built with Next.js. Uses the name "Bytecode Developers". Lists five services: Mobile App Development, Website Development, SEO Services, Digital Marketing and Software Development. Packages are not published ("No plans available"). |
| Contact details | ✅ From the website | +977 9802398559 · info@bytecodedevelopers.com · Gravity Center, Anamnagar-29, Kathmandu 44600 |
| Social profiles | ✅ From the website | Facebook, Instagram and LinkedIn URLs are seeded in Settings |
| Portfolio project names | ⚠️ Names only | 19 project names from bytecodedevelopers.com/portfolio are seeded as **unpublished drafts**. Descriptions, screenshots, URLs and client permission are still needed. |
| Logo and brand files | ❌ Not provided | The logo images could not be downloaded from the website. A text wordmark is used until a logo is uploaded in Settings. |
| Company profile, brochures, proposals | ❌ Not provided | The resource library is ready; nothing has been invented. |
| Package prices and deliverables | ❌ Not provided | Six placeholder packages are seeded **unpublished**. Public pages show "Custom quotation / Price on request". |
| Vercel and UI/UX demo links | ❌ Not provided | The showcase module is ready. |
| Hosting details | ❌ Not provided | See the recommendation in 1.6. |
| Existing lead spreadsheets | ❌ Not provided | The Google Sheets layout is defined in 1.8. Existing data can be imported later. |

Third-party directory listings disagree with each other on founding year, pricing and phone number, and one lists the Iranian dialling code (+98). Only details from ByteCode's own website were used.

## 1.2 Brand and website assessment

- **Name.** The brief uses "ByteCode Developers"; the website uses "Bytecode Developers". The platform uses the brief's spelling, and it can be changed in **Settings → Company name**. ByteCode needs to confirm the official spelling.
- **Messaging.** The website's own positioning ("Websites, Apps, Software, SEO – All in One Place", "We Build. You Move Forward.") fits the brief's "Your Business. Digitally Ahead." The platform uses the brief's headline and the website's edge points: local market expertise, transparent reporting and dedicated support.
- **Gaps on the current site.** It has no package prices or deliverables, no individual case-study pages, no lead pipeline, no downloadable materials, and its contact block links to placeholder social URLs. The platform addresses each of these.

## 1.3 Visual identity direction

- **Colours.** These come from ByteCode's own brief document: navy `#17324D`, blue `#2878A8` and teal `#269B83`. They are runtime variables, so changing them in **Settings → Brand** re-themes the whole site without a deploy. They should be checked against the official logo.
- **Typography.** Plus Jakarta Sans for headings and Inter for body text. Both are self-hosted (fast, no Google Fonts dependency) and render Latin and Devanagari punctuation cleanly.
- **Style.** Deep-navy hero sections with a subtle grid texture and soft gradient light, white content sections, rounded cards and restrained motion that respects "reduce motion" settings. The look aims for premium and calm rather than generic IT stock imagery. It uses no stock photos and no fake device mockups showing invented metrics.
- **Mobile first.** Touch targets are at least 44px. The admin area has a bottom tab bar with a central **Capture** button for one-handed use during visits.

## 1.4 Sitemap

```
Public
├── /                         Home (company-wide)
├── /c/pokhara                Campaign landing page (one per campaign)
├── /services                 Services index (grouped)
│   └── /services/<slug>      Website Development · Application Development · System & Software Development · SEO ·
│                             Travel & Tourism SEO Content · Content Writing · Digital Marketing & Video · Automation & Consulting
├── /packages                 Package catalogue (published packages + "custom quotation" services)
├── /portfolio                Projects, filtered by industry and type
│   └── /portfolio/<slug>     Case study: links, screenshots, video, documents, services
├── /showcase                 Vercel, UI/UX and Figma demos
│   └── /showcase/<id>        Embedded preview with device toggle + external link
├── /resources                Resource library: search and filters (category, industry, service, file type)
│   └── /resources/<slug>     Preview (PDF, image, video, Office viewer) + download
├── /about · /contact · /request-proposal
├── /privacy · /terms · 404
└── /sitemap.xml · /robots.txt · /manifest.webmanifest

Team (/admin, login required)
├── Dashboard · Leads (list, new, detail) · Quick capture · Follow-ups · Presenter kit · Reports
├── Content: Portfolio · Demos & UI/UX · Resources · Testimonials · Services & packages
└── Configuration: Campaigns · Lists & options · Users · Google Sheets sync · Settings · Audit log
```

## 1.5 Technical architecture

```mermaid
flowchart LR
  V[Visitor / BD phone] -->|HTTPS| N[Next.js on Vercel<br/>Server Components + Server Actions]
  N -->|SQL via pooler| P[(Supabase Postgres)]
  N -->|presigned URLs| S[(Supabase Storage<br/>S3 protocol)]
  V -->|direct upload with presigned PUT| S
  N -->|queue rows| P
  C[Vercel Cron] -->|/api/cron/sync, /api/cron/daily| N
  N -->|service account| G[Google Sheets<br/>campaign sheet + central register]
  N -->|SMTP| M[Email]
```

**Why this stack.** The brief's suggested stack was used, with two reasoned changes.

1. **Next.js + TypeScript + Tailwind on Vercel.** One codebase serves the fast public site (static pages refreshed every 60 seconds) and the secure dashboard. ByteCode already uses Next.js and Vercel, so there is no new technology to learn.
2. **PostgreSQL on Supabase, accessed through Drizzle ORM.** Supabase is used for what it does best: managed Postgres, backups and S3-compatible storage. Drizzle keeps the schema in version-controlled SQL migrations. The app is not locked to Supabase and runs on any Postgres (Neon, AWS RDS or self-hosted).
3. **Change 1: application-managed authentication instead of Supabase Auth.** Only staff sign in, and the permission model (Administrator, Manager, BD) is enforced in one server-side module (`src/lib/permissions.ts`) that every action, route and query calls. This is simpler to audit than splitting rules between Supabase RLS policies and app code. Supabase's public REST API is closed off at the database level with `scripts/supabase-hardening.sql` (RLS enabled, no policies, grants revoked for `anon` and `authenticated`), so the only path to the data is the server.
4. **Change 2: uploads go directly from the browser to storage** through short-lived presigned URLs. Vercel limits request bodies to 4.5 MB, so this is required for brochures and videos. The server then checks each file's real signature (magic bytes) before accepting it.

## 1.6 Hosting recommendation

The existing infrastructure stays as it is. Deploy the hub on a **subdomain of the existing domain**, for example `hub.bytecodedevelopers.com`, with campaign pages such as `hub.bytecodedevelopers.com/c/pokhara`. This needs no new domain, leaves the current website untouched, and adds only one DNS CNAME record. If ByteCode prefers, it can later replace the current marketing site, because the hub already contains every page that site has.

- **Vercel Pro** is recommended because the Google Sheets retry job runs every 10 minutes. On the Hobby plan, cron jobs run once a day; new leads still sync immediately, and only retries would be slower.
- **Supabase Pro** is recommended for production. Free projects pause after a week of inactivity and have only limited backups.

## 1.7 Database structure

There are 38 tables, all normalised with UUID keys. The full definitions are in `src/lib/db/schema.ts` and the SQL is in `drizzle/0000_initial_schema.sql`.

| Area | Tables |
|---|---|
| Users & roles | `users` (role enum: admin, manager, bd), `sessions` (hashed tokens) |
| CRM | `businesses` → `contacts`, `leads` (Lead ID, status, source, campaign, assignee, budget, estimated value, consent, UTM, idempotency key, duplicate flags), `lead_services`, `lead_requirements` (answers to conditional questions), `meetings`, `activities` (notes, calls, follow-ups with due and completed dates), `lead_status_history`, `lead_attachments`, `lead_counters` |
| Campaigns | `campaigns` (prefix, dates, landing copy, sheet), `lead_sources` (optionally campaign-specific), `campaign_resources` |
| Catalogue | `services`, `packages`, `enquiry_services` (form checklist mapped to services and question sets) |
| Portfolio | `portfolio_projects` (classification: client project, internal demo, UI/UX concept, prototype or in progress), `project_media`, `project_services`, `demos` |
| Resources | `resources` (visibility: public, internal or private), `resource_categories`, `resource_services`, `resource_projects`, `files` (storage metadata and public flag) |
| Config | `industries`, `project_types`, `budget_ranges`, `lead_statuses` (colour, won, lost, qualified), `settings`, `testimonials` (consent required) |
| Ops | `sheet_sync_jobs` (unique per lead and target), `sync_logs`, `notifications`, `audit_logs`, `rate_limits` |

## 1.8 Google Sheets integration

- Every lead is **saved to Postgres first**. The sheets are an operational copy and never the source of truth.
- Each lead gets one job per target, **campaign sheet** and **central register**, enforced by a unique index. Jobs are claimed with `FOR UPDATE SKIP LOCKED`.
- The worker finds the row by **Lead ID** in column A and updates it in place, or appends a new row. Retries and status changes therefore never create duplicate rows. This was verified by the automated tests.
- Sync runs immediately after the response is sent (Next.js `after()`). If Google is down, it retries with exponential back-off for up to 6 attempts, then marks the job **failed**. Failures are logged, and Admin → Google Sheets sync offers **Retry** and **Full re-sync**.
- Columns: Lead ID, Date, Business, Contact person, Phone, WhatsApp, Email, Industry, Location, Source, Campaign, Services, Budget, Timeline, Assigned to, Status, Follow-up date, Estimated value (NPR), Priority, **Lead record link**, Last updated. Detailed requirements stay in the database, reachable through the link.
- Credentials (a service-account key) exist only in server environment variables.

## 1.9 Workflows

**Public enquiry.** The visitor picks services. The form then asks for business details and contact details (with Nepal phone validation), followed by requirements plus only the question sets relevant to the chosen services: website, e-commerce, app, SEO, travel, marketing, video or system. Next come budget in NPR and timeline, then preferences and **explicit consent**. The enquiry is saved with a Lead ID such as `POK-2026-0001`. The visitor sees a confirmation, receives an acknowledgement email, and admins and managers are notified. The lead is synced to Google Sheets. Drafts survive refreshes and lost connections on the device.

**Field visit (BD).** Open **Quick capture** from the bottom bar and enter the business name plus whatever else is known, then tap Save. A Lead ID is generated, the campaign's "physical visit" source is applied, and the lead is assigned to the person who captured it. Without a signal, the lead is stored on the phone and uploaded automatically later. Possible duplicates (same phone, email, or name and location) are flagged. The team member can then open the lead to add meetings, notes and the next follow-up.

**Pipeline.** New → Contacted → Meeting Scheduled → Qualified → Proposal Sent → Negotiation → Won / Lost. Statuses can be configured. Marking a lead Lost requires a reason, and every change is recorded in the status history and timeline.

**Content.** Upload a file once, then attach it to many services, projects and campaign collections. Visibility can be public, internal (team only, shown in the presenter kit) or private. Only *published and public* items reach the website, and file access is re-checked on every request.

## 1.10 Security plan (implemented)

- **Accounts:** individual accounts with bcrypt (cost 12), httpOnly SameSite cookies, sliding 30-day sessions stored as SHA-256 hashes, and sign-in rate limits per IP and per email.
- **Permissions:** checked on the server in every action, route and query. BD users only see leads they created or were assigned.
- **Database:** Supabase's REST API is locked down with RLS and revoked grants.
- **Input:** validated with Zod. Public forms use a honeypot, a signed time token, a rate limit of 6 per hour per IP, and optional Cloudflare Turnstile.
- **Uploads:** an allow-list of file types (SVG and HTML are blocked), per-type size limits, magic-byte checks, and randomised storage keys. Private files return 404 to visitors; lead attachments require access to the lead, and private resources are restricted to content managers.
- **Exports:** spreadsheet exports are protected against formula injection.
- **Headers:** CSP, HSTS, `nosniff`, a referrer policy and frame protection. Admin pages are `noindex` and `no-store`.
- **Privacy:** IP addresses are stored only as salted hashes. Consent and its timestamp are recorded on each lead. The Privacy Policy reflects Nepal's Privacy Act, 2075 (2018) and needs legal review.
- **Audit:** an audit log records sign-ins, exports, deletions, merges, permission changes and content changes.
