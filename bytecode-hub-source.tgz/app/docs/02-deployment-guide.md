# 2. Deployment guide

The recommended production setup is **Vercel** for the app, **Supabase** for Postgres and file storage, a **Google Cloud service account** for Sheets, and any **SMTP** provider for email. Allow about an hour for the first deployment.

## 2.1 Hosting requirements

| Item | Minimum | Recommended |
|---|---|---|
| App hosting | Node.js 20.9+ (any host that runs `next start`) | Vercel Pro (frequent cron jobs, team access) |
| Database | PostgreSQL 14+ | Supabase Pro (daily backups, no auto-pause), region `ap-south-1` (Mumbai), closest to Nepal |
| File storage | S3-compatible bucket | Supabase Storage (same project) or Cloudflare R2 |
| Email | Any SMTP | Google Workspace / Zoho Mail SMTP, or Brevo / Postmark |
| Domain | One DNS record | `hub.bytecodedevelopers.com` (CNAME to Vercel) |

## 2.2 Create the database (Supabase)

1. Create a new Supabase project in region **South Asia (Mumbai)** and set a strong database password.
2. Go to **Project Settings → Database → Connection string → URI** and copy the **Transaction pooler** string (port `6543`). This becomes `DATABASE_URL`. Set `DATABASE_SSL=require`.
3. On your computer, run the migrations and seed data once:
   ```bash
   cp .env.example .env    # paste DATABASE_URL, DATABASE_SSL=require, APP_SECRET, ADMIN_* values
   npm install
   npm run db:setup        # migrate + seed (creates the first administrator from ADMIN_EMAIL / ADMIN_PASSWORD)
   ```
4. In **Supabase → SQL Editor**, paste and run `scripts/supabase-hardening.sql`. This shuts off Supabase's public REST API for every table. The final query should return **0 rows**.

## 2.3 Create file storage (Supabase Storage)

> **Quick start alternative:** set `STORAGE_DRIVER=db` to keep uploaded files inside Postgres (no bucket or keys
> needed; each file is limited to `DB_STORAGE_MAX_MB`, default 20 MB). The live launch on Render uses this.
> Switch to S3 storage later when the library grows. Existing files keep working because each file remembers its driver.

1. Go to **Storage → New bucket** and create `campaign-hub`. Keep it **private**; the app serves files through short-lived signed URLs.
2. Go to **Project Settings → Storage → S3 Connection**, enable it, and create an access key. Note the endpoint (`https://<project>.supabase.co/storage/v1/s3`), the region, the access key ID and the secret.
3. Set these variables:
   ```
   STORAGE_DRIVER=s3
   S3_ENDPOINT=https://<project-ref>.supabase.co/storage/v1/s3
   S3_REGION=ap-south-1
   S3_BUCKET=campaign-hub
   S3_ACCESS_KEY_ID=...
   S3_SECRET_ACCESS_KEY=...
   S3_FORCE_PATH_STYLE=true
   ```
4. **CORS.** Browsers upload directly to the bucket. Supabase Storage allows this by default. If you use **Cloudflare R2 or AWS S3** instead, add a CORS rule that allows `PUT` from `https://hub.bytecodedevelopers.com` with the header `Content-Type`.

> Do not use `STORAGE_DRIVER=local` on Vercel. Its filesystem is temporary, so uploaded files would disappear.

## 2.4 Google Sheets

1. In **Google Cloud Console**, create a project, enable the **Google Sheets API**, then go to **IAM → Service accounts → Create**. Open the new account's **Keys → Add key → JSON**.
2. From the JSON file, copy `client_email` into `GOOGLE_SERVICE_ACCOUNT_EMAIL` and `private_key` into `GOOGLE_PRIVATE_KEY`. Keep the `\n` sequences and wrap the value in double quotes.
3. Create two Google Sheets:
   - **ByteCode – Central Lead Register.** Copy its ID from the URL (`/d/<ID>/edit`) into `GOOGLE_SHEETS_CENTRAL_ID`. The tab name defaults to `Leads`.
   - **ByteCode – Pokhara Campaign Leads.** Paste its URL into **Admin → Campaigns → Pokhara → Google Sheets**.
4. **Share both sheets** with the service-account email as **Editor**.
5. The app creates the tab and header row automatically on the first sync. Check **Admin → Google Sheets sync**: every item in the configuration list should show a green tick.

Treat the sheets as read-mostly. The database is the master copy, and manual edits to synced columns are overwritten on the next update of that lead. Add your own columns to the right of column U if the team needs extra notes in the sheet.

## 2.5 Email (SMTP)

```
SMTP_HOST=smtp.zoho.com        # example
SMTP_PORT=587
SMTP_USER=no-reply@bytecodedevelopers.com
SMTP_PASSWORD=...
SMTP_FROM="ByteCode Developers <no-reply@bytecodedevelopers.com>"
```

Use **Admin → Google Sheets sync → Send test email to me** to check the setup. Without SMTP, everything still works, but emails are only written to the server log.

## 2.6 Deploy to Vercel

1. Push the repository to GitHub, then go to **Vercel → Add New Project → Import**. The framework preset is detected as Next.js.
2. Add **all** environment variables from `.env.example` under **Settings → Environment Variables** for the Production environment:

| Variable | Notes |
|---|---|
| `NEXT_PUBLIC_SITE_URL` | `https://hub.bytecodedevelopers.com` (no trailing slash) |
| `DATABASE_URL`, `DATABASE_SSL` | From 2.2 (`require`) |
| `APP_SECRET` | `openssl rand -base64 48`. Never change it after launch (it signs form tokens and hashes IPs). |
| `CRON_SECRET` | `openssl rand -hex 32`. Vercel Cron sends it automatically. |
| `STORAGE_*`, `S3_*` | From 2.3 |
| `GOOGLE_*` | From 2.4 |
| `SMTP_*` | From 2.5 |
| `NEXT_PUBLIC_TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY` | Optional. Add Cloudflare Turnstile keys if spam becomes a problem. |

3. Deploy. The database must be reachable at build time, because public pages are pre-rendered and then refreshed every 60 seconds.
4. **Cron jobs** are defined in `vercel.json`:
   - `/api/cron/sync` runs every 10 minutes and retries Google Sheets jobs. The Pro plan is needed for this frequency; on Hobby, change it to once a day, or call the URL from an external scheduler such as cron-job.org with the header `Authorization: Bearer <CRON_SECRET>`.
   - `/api/cron/daily` runs at 02:15 UTC (08:00 Nepal time). It sends the follow-up digest emails and cleans up expired sessions and abandoned uploads.

## 2.7 Domain configuration

1. In **Vercel → Project → Settings → Domains**, add `hub.bytecodedevelopers.com`.
2. At your DNS provider, add **CNAME `hub` → `cname.vercel-dns.com`**. Vercel issues the SSL certificate automatically.
3. Update `NEXT_PUBLIC_SITE_URL` and redeploy.
4. Optionally, link to the hub from the existing website's navigation, for example "Packages", "Resources" and "Request a proposal".
5. Use the campaign URL in Meta Ads and WhatsApp, with UTM tags, for example:
   `https://hub.bytecodedevelopers.com/c/pokhara?utm_source=facebook&utm_medium=paid&utm_campaign=pokhara-launch`

## 2.8 Administrator account setup

- The first administrator is created by `npm run db:setup` from `ADMIN_EMAIL` and `ADMIN_PASSWORD`.
- To create another administrator, or to reset a forgotten admin password, run:
  ```bash
  ADMIN_EMAIL=name@bytecodedevelopers.com ADMIN_PASSWORD='a-long-password' ADMIN_NAME='Full Name' npm run create-admin
  ```
- Add all other team members in **Admin → Users**, giving each person their own account. New users must change their temporary password the first time they sign in.

## 2.9 First-day checklist

- [ ] **Settings:** logo (light and dark versions), WhatsApp number, office hours, Google Maps link, brand colours checked against the logo.
- [ ] **Settings:** GA4 and Meta Pixel IDs, if used. They only load after the visitor accepts cookies.
- [ ] **Settings → Legal pages:** legal advisor has reviewed the Privacy Policy and Terms.
- [ ] **Campaigns → Pokhara:** start and end dates, sheet URL, landing copy.
- [ ] **Services & packages:** approved prices and deliverables entered; placeholder flag removed; packages published.
- [ ] **Portfolio:** draft projects completed with screenshots, URLs and client permission, then published.
- [ ] **Resources:** company profile and brochures uploaded as public and published.
- [ ] **Users:** an account for every BD team member.
- [ ] **On each BD phone:** open the hub in Chrome or Safari, sign in, then use **Add to Home screen**. The Quick capture shortcut then opens like an app.
- [ ] **Integrations page:** all green. Submit a test enquiry and check that the row appears in both sheets.

## 2.10 Backups

- **Database:** Supabase Pro keeps daily backups for 7 days, and point-in-time recovery is available as an add-on. Also keep a weekly offline copy:
  ```bash
  pg_dump "$DATABASE_URL" --no-owner --format=custom -f bytecode-hub-$(date +%F).dump
  # restore: pg_restore --no-owner -d "$NEW_DATABASE_URL" bytecode-hub-YYYY-MM-DD.dump
  ```
- **Files:** with the Supabase CLI or `rclone` (S3 remote), sync the bucket to a second location every week.
- **Google Sheets:** these are a copy and can be rebuilt at any time with **Admin → Google Sheets sync → Full re-sync**.
- **Code and configuration:** the code is in Git. Keep a copy of the production environment variables in a password manager.

## 2.11 Alternative: a VPS or ByteCode's own server

1. Install Node 20+, PostgreSQL 16 and nginx.
2. Set `STORAGE_DRIVER=local` and `STORAGE_LOCAL_DIR=/var/lib/bytecode-hub/storage`, and include that directory in your backups.
3. Run `npm ci && npm run build && npm run db:setup`, then run `npm start` under systemd or pm2 behind nginx with TLS (Let's Encrypt).
4. Schedule the two cron URLs with system cron:
   `*/10 * * * * curl -fsS -H "Authorization: Bearer $CRON_SECRET" https://hub.example.com/api/cron/sync`
