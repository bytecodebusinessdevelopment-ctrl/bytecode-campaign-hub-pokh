# 3. Admin user guide

This guide is for the ByteCode team. Sign in at **/admin** with your own email and password. On a phone, use **Add to Home screen** so the hub opens like an app.

## Roles at a glance

| | BD Team Member | Manager | Administrator |
|---|:-:|:-:|:-:|
| Quick capture and new leads | ✅ | ✅ | ✅ |
| See leads | Own and assigned only | All | All |
| Notes, meetings, follow-ups, status | Own and assigned only | All | All |
| Assign leads, merge duplicates, export | — | ✅ | ✅ |
| Reports | Dashboard only | ✅ | ✅ |
| Portfolio, demos, resources, testimonials | — | ✅ | ✅ |
| Services and packages (pricing), campaigns, lists, users, settings, audit log | — | — | ✅ |
| Delete leads | — | — | ✅ |

## During a business visit (phone)

1. Tap the green **+ Capture** button in the bottom bar.
2. Type the **business name** (the only required field). Add whatever else you know: industry, location, phone, contact person, website, the services they are interested in, notes and **Hot / Warm / Cold** priority.
3. Tap **Save prospect**. You will see the new Lead ID, for example `POK-2026-0007`.
   - With **no signal**, the lead is saved on your phone and uploads automatically when you are back online. A yellow bar shows how many leads are waiting.
   - If the phone number or business already exists, you will see "may be a duplicate". A manager will review it.
4. Tap **Add more details** to record the meeting and set the **next follow-up**.

**Showing our work in a meeting.** Open **Present** in the bottom bar. It lists live demos, published projects (with live-site links), documents and services. The green WhatsApp icon sends a link straight to the prospect. Items marked *Internal only* are for your eyes only and should not be shared.

## Working a lead

Open a lead from **Leads**, from the dashboard, or from a notification.

- **Call / WhatsApp / Email** buttons are at the top. WhatsApp opens with a greeting already written.
- **Pipeline:** change the status. Marking a lead **Lost** requires a reason, which feeds the lost-deal report. Managers can **assign** the lead to a team member, who is notified by email and in the app.
- **Follow-ups:** add the next action and its date and time (Nepal time). When done, write the outcome and tap **Done**. The lead's "next follow-up" moves to the next open item automatically.
- **Activity & notes:** record calls, WhatsApp chats, emails and internal notes. Everything is time-stamped with your name.
- **Meetings:** add past or future meetings. Booking a future meeting can move the status to *Meeting Scheduled*.
- **Requirements:** shows everything the client entered, including the service-specific answers.
- **Edit lead details:** complete partial information, add the estimated deal value (NPR) and set the budget and timeline.
- **Attachments:** add visiting cards, photos or briefs. These are private to people who can see the lead.
- **Google Sheets:** shows the sync status. **Sync now** retries the sync immediately.

**Duplicates.** A yellow banner appears when a lead looks like an existing one. **Merge** moves notes, meetings, attachments and services to the original lead and fills any empty fields. **Not a duplicate** removes the flag.

## Follow-ups page

The tabs are **Upcoming**, **Overdue** (in red), **Completed** and **Meetings**. Managers can switch between "only mine" and the whole team. Every morning at 08:00, each person receives an email listing their follow-ups that are due or overdue.

## Dashboard and reports

- **Dashboard:** totals, overdue follow-ups, upcoming meetings, counts per status, leads per week, leads by source, industry and service, recent leads and Google Sheets sync health. Filter by campaign.
- **Reports** (managers and admins):
  - **Recorded results:** prospects, meetings, qualified, proposals, won, lost and conversion rates.
  - **Estimates**, kept separate: open pipeline and won value, both from the *estimated value* field.
  - Funnel by furthest stage reached, lost reasons, campaign comparison and team performance.
  - Filter by campaign, team member or date range.
- **Export:** CSV or Excel from the Leads page or Reports. The export respects your current filters.

## Managing website content (no code needed)

### Portfolio

1. Go to **Portfolio → New project**, or open one of the **draft** projects imported from the current website.
2. Choose the honest **classification**: Completed client project, Internal demonstration, UI/UX concept, Experimental prototype or In-progress project. It is shown publicly as a label.
3. Add a summary, description and case study (objectives, problems, solution), features, technologies, live URL, video URL, cover image and desktop, mobile and gallery screenshots.
4. Tick **"client authorised showing their name"** only when you have permission.
5. Set the status to **Published**. Projects marked **Featured** appear on the home page.

### Demos & UI/UX

Add Vercel deployments, live sites, UI/UX previews, Figma prototypes and video walkthroughs. They can be standalone or linked to a project.

- Tick **Show an embedded preview** only after checking that the site opens inside a frame, because many sites block this. An **Open** link is always shown as well.
- Set visibility to **Team only** for demos you want in the presenter kit but not on the website.

### Resources (document library)

1. Choose **Add resource**, then pick the type: document/file, external link, video link, live website, Vercel deployment or Figma.
2. Upload the file: PDF, Word, PowerPoint, Excel, JPG, PNG, WebP or video. The size limits are set in Settings.
3. Choose who can see it:
   - **Public:** on the website, with download if allowed.
   - **Internal only:** visible to the team in the presenter kit.
   - **Private:** admins and managers only.
4. Tick the **service pages**, **projects** and **campaign collections** where it should appear. One upload can appear in many places.
5. Tick **Published**. The Published/Draft badge in the list toggles it quickly.

> Never make internal proposals, private client documents or pricing negotiations public.

### Services & packages (administrators)

- Edit each service page's tagline, overview, "What we offer" list, extra sections and pricing note.
- Packages hold the price type (fixed, starting from, monthly, custom quotation or to be confirmed), the NPR price, deliverables, features, exclusions, add-ons, delivery period and requirements.
- Seeded packages are **placeholders**. Replace their content with approved details, untick *Placeholder*, then publish. A placeholder cannot be published, which is a deliberate safeguard.

### Testimonials

Add only real client words. Publishing requires **Client consent confirmed** plus a note saying where that consent is recorded. The home-page section stays hidden until at least one testimonial is published.

## Campaigns (administrators)

To run a new campaign, for example Chitwan:

1. Go to **Campaigns → New campaign**. Enter the name, location, landing slug (`chitwan`), Lead ID prefix (`CHT`), dates and status.
2. Write the landing-page headline, supporting text and introduction. The page is live at `/c/chitwan`.
3. Paste the campaign's Google Sheet URL and share the sheet with the service account.
4. In **Lists & options → Lead sources**, add "Chitwan physical visit" linked to the campaign. Quick capture will use it automatically.
5. Tick **Default campaign** while it is the active field campaign.
6. Add documents to the campaign's collection from each resource's editor.

When a campaign ends, set it to **Completed** or **Archived**. Its data and reports stay intact.

## Lists & options (administrators)

Configure pipeline statuses (colour, Won, Lost, Qualified+), lead sources, industries, the enquiry form's service checklist, NPR budget ranges, project types and resource categories. **Deactivate** items rather than deleting them, so that history is kept.

## Users (administrators)

Use **Add user**, leaving the password blank to generate one. Share the temporary password securely; it is also emailed if SMTP is configured. **Deactivating** a user signs them out immediately. **Reset password** issues a new temporary password. The system always keeps at least one active administrator.

## Settings (administrators)

- Company details and contact information, including the WhatsApp number (this turns on the WhatsApp buttons).
- Social links, brand colours and logos.
- Home and about copy: the "Why choose us" lines (format: `Title | description`) and the technology chips (list only what ByteCode actually uses).
- SEO defaults, GA4 and Meta Pixel IDs, and extra email addresses to notify of new enquiries.
- Upload limits, the lead retention period, and the Privacy Policy and Terms text.

## Good practice

- Set a follow-up on every open lead. To find leads that have none, filter the Leads list by **Follow-up → No follow-up set**.
- Record the outcome every time you complete a follow-up.
- Keep estimated values realistic; reports always label them as estimates.
- Never publish a project, testimonial or client name without real information and permission.
