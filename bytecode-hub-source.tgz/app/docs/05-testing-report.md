# 5. Testing report

| | |
|---|---|
| **Date** | 1 November 2026 |
| **Build** | Next.js 15.5 production build (`next build` + `next start`), Node 22, PostgreSQL 16 |
| **Data** | Fresh database: migrations plus seed. Test records are created by the suite and have unique suffixes. |
| **Google Sheets** | Exercised against `tests/mock-google.mjs`, a local mock of the OAuth and Sheets endpoints the app calls, with a real RSA-signed service-account JWT |
| **Browser** | Chromium (Playwright), at desktop 1280×900 and phones 390×844 and 360×780 |
| **Result** | **23 of 23 automated acceptance tests passed** |

## Static checks

| Check | Result |
|---|---|
| `tsc --noEmit` (strict TypeScript) | ✅ No errors |
| `eslint .` (next/core-web-vitals and next/typescript) | ✅ No errors or warnings |
| `next build` | ✅ Succeeded: 57 routes; public pages statically generated with 60 s revalidation |
| `npm audit --omit=dev` | ⚠️ One moderate advisory (`minimatch`, through `exceljs` → `archiver`). It is server-side only and never receives user input. All high-severity advisories were fixed by upgrading `zod`, `nodemailer` and Next's bundled `postcss`. |
| `scripts/supabase-hardening.sql` | ✅ Ran against Postgres with `anon` and `authenticated` roles. `SELECT` as `anon` fails with *permission denied*, and the app keeps working. |

## Acceptance criteria (Part 18 of the brief)

| # | Criterion | Automated test(s) | Result |
|---|---|---|---|
| 1 | A visitor can explore all public sections | *Visitor can open every public section* (15 routes plus a 404); *Navigation links work* | ✅ |
| 2 | A visitor can submit an enquiry | *Visitor can submit a multi-step enquiry with conditional questions*: SEO and Website question sets shown, unrelated sets hidden, phone validation, consent required | ✅ |
| 3 | The enquiry is stored in the database | *Enquiry is stored…*: Lead ID `POK-2026-0001`, conditional answers, source "Website enquiry", consent with timestamp | ✅ |
| 4 | Relevant information synchronises to Google Sheets | *Relevant information synchronises…*: header row created, row written to the campaign sheet **and** the central register, **3 retries plus a status change leave exactly 1 row** (updated in place), detailed requirements not copied to the sheet | ✅ |
| 4a | Sync failures are logged; an admin can retry | *Sync failures are logged…*: simulated Google outage, error visible in Integrations, "Retry all failed" succeeds | ✅ |
| 5 | An authorised team member can create a lead during a physical visit | *Quick capture — offline-safe and idempotent*: phone viewport, duplicate flagged, **offline save queued on the device and uploaded after reconnecting**, **same submission sent twice returns the same Lead ID** | ✅ |
| 6 | A lead can be edited and followed up | *Full internal lead entry…* (partial save, overdue flagged on Follow-ups and the dashboard); *A lead can be edited and followed up* (Lost requires a reason, notes, follow-up scheduled and completed with outcome, estimated value shown as **Rs. 1,80,000**); *Possible duplicates can be merged* | ✅ |
| 7 | A project can be added from the admin dashboard | *A project can be added…*: cover upload, publish, visible on /portfolio with "View Live Website" and the classification label | ✅ |
| 8 | A Vercel deployment can be added and displayed | *A Vercel deployment can be added and displayed*: embedded preview iframe, "Open in new tab" fallback, "UI/UX concept" label | ✅ |
| 9 | A document can be uploaded and published | *A document can be uploaded, published…*: PDF uploaded, public download works without signing in | ✅ |
| 10 | A resource can appear on multiple relevant service pages | Same test: one PDF appears on **Website Development** and **SEO** | ✅ |
| 11 | Private documents remain private | *Private documents remain private*: anonymous request returns **404**, not listed publicly, admin can open it | ✅ |
| 12 | An administrator can manage packages and services | *An administrator can manage packages…*: placeholder safeguard blocks publishing, then the edited package shows **Rs. 25,000 / month** publicly | ✅ |
| 13 | The system works on mobile devices | *No horizontal overflow on key pages* (360 px); Quick capture, BD lead page and dashboard exercised at 390 px | ✅ |
| 14 | Campaign reports reflect actual stored records | *Campaign reports reflect actual stored records; exports work*: recorded vs estimated sections, CSV contains the lead, Excel export valid | ✅ |
| 15 | No fake company information is published | *Navigation links work and nothing fake is published*: no placeholder packages, no testimonials, portfolio empty state by default | ✅ |
| — | Permissions enforced on the server | *Permissions are enforced on the server for a BD team member*: BD redirected away from Users, **404** on another person's lead, **403** on export, sees only own leads, can create and open own lead | ✅ |
| — | Upload security | *Uploads are validated*: an HTML file renamed `.pdf` is rejected by the signature check; `.svg` is rejected by the allow-list | ✅ |
| — | Spam protection | *Spam protection*: instant submission rejected (signed timing token); honeypot path covered in code | ✅ |
| — | Security headers and admin protection | CSP, HSTS and `nosniff` present; `/admin/*` redirects to login; cron endpoints return 401 without the secret | ✅ |
| — | SEO basics | Sitemap lists services, robots.txt blocks `/admin`, Organization JSON-LD, Open Graph image | ✅ |

## Stage 5 checklist from the brief

| Area | How it was verified |
|---|---|
| All public pages, navigation | Automated (tests 1–3) and visual review at desktop and mobile widths |
| Mobile responsiveness | Automated overflow check; screenshots reviewed (`docs/screenshots/`) |
| Public lead submission, conditional questions | Automated |
| Internal lead entry, quick capture | Automated (including offline and idempotency) |
| Database storage | Automated, plus direct SQL inspection during development |
| Google Sheets synchronisation | Automated against the API mock. **Run one live check after deployment** with real credentials (Deployment guide §2.4). |
| Authentication, permissions | Automated for Administrator and BD; Manager covered by the same permission matrix |
| Portfolio publishing, document uploads | Automated |
| External links, Vercel previews | Automated (iframe and fallback link) |
| Follow-up management | Automated (schedule, complete, overdue flag, dashboard alert) |
| Reports and exports | Automated (CSV and Excel) |

## Visual review

The screenshots in `docs/screenshots/` come from the automated test run, so they show test data such as "Test package description".

- `01-home-hero-desktop.jpg`, `02-home-mobile.jpg`: landing page
- `03-request-proposal-mobile.jpg`: multi-step enquiry with progress indicator
- `04-quick-capture-mobile.jpg`: field capture with duplicate warning
- `05-lead-detail-desktop.jpg`: lead record with pipeline, follow-ups, timeline and sync status
- `06-dashboard-desktop.jpg`, `07-reports-desktop.jpg`: dashboard and campaign reports
- `08-packages-desktop.jpg`: package catalogue with an approved package and custom-quotation services

Issues found and fixed during testing:

- A drafted enquiry overrode a service pre-selected from a service page. Drafts are now saved only after the visitor starts typing, and pre-selections are merged into restored drafts.
- "Retry all failed" ignored jobs still in back-off. It now retries those too.
- Saved resources did not appear on service pages until the cache expired. Saving now refreshes all affected pages immediately.
- The mobile dashboard overflowed horizontally because of the campaign filter. This is fixed.
- The chart axis showed duplicate ticks for small numbers, and the sidebar logo was too wide. Both are fixed.

## Not covered by automated tests (manual checks after deployment)

1. Live Google Sheets with the real service account: submit one enquiry and confirm the rows in both sheets.
2. SMTP delivery: use Integrations → "Send test email", then submit an enquiry with an email address and confirm the acknowledgement arrives.
3. S3 or Supabase Storage uploads in production: upload a 10 MB or larger PDF. This confirms direct-to-storage upload and the bucket CORS setup.
4. "Add to Home screen" on one Android and one iPhone BD device, then put the phone in airplane mode and test Quick capture.
5. Office document preview on the live domain (Microsoft viewer) for a public `.docx` or `.pptx`.
6. Cloudflare Turnstile, if it is enabled.
7. Cron jobs on Vercel: check under Vercel → Cron Jobs that `/api/cron/sync` and `/api/cron/daily` return 200.

## Re-running the suite

See [Technical maintenance → Running the test-suite](04-technical-maintenance.md#running-the-test-suite). The suite writes `test-results/results.json` and screenshots.
