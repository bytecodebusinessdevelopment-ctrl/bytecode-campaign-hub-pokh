# 4. Technical maintenance

## Code map

| Concern | Where |
|---|---|
| Database schema (single source of truth) | `src/lib/db/schema.ts` → `drizzle/*.sql` |
| Permissions matrix | `src/lib/permissions.ts` (`PERMISSIONS`) |
| Sessions and auth helpers (`requireUser`, `requirePermission`, `leadScope`) | `src/lib/auth.ts` |
| Lead creation, Lead IDs, duplicates, status changes, merging | `src/lib/leads.ts` |
| Lead list and filter queries, exports | `src/lib/lead-queries.ts`, `src/app/api/leads/export` |
| Google Sheets queue and worker | `src/lib/sheets.ts`, `src/app/api/cron/sync` |
| File storage drivers, upload validation, file publicity | `src/lib/storage.ts`, `src/app/api/uploads/*`, `src/app/api/files/[id]` |
| Email and notifications, daily digest | `src/lib/mail.ts`, `src/lib/notify.ts`, `src/app/api/cron/daily` |
| Reporting SQL | `src/lib/stats.ts` |
| Site settings (defaults and DB overrides) | `src/lib/settings.ts` |
| Conditional enquiry questions and option lists | `src/lib/enquiry-config.ts` |
| Public data access (only published/public content) | `src/lib/public-data.ts` |
| Offline support | `public/sw.js`, `src/components/admin/quick-capture.tsx` |

## Routine tasks

**Changing the database schema**

1. Edit `src/lib/db/schema.ts`.
2. Run `npm run db:generate -- --name short_description`. This creates a new SQL file in `drizzle/`; review it.
3. Commit the change, then run `npm run db:migrate` against production *before* or *with* the deploy. Migrations are additive and are recorded in `drizzle.__drizzle_migrations`.
4. On Supabase, re-run `scripts/supabase-hardening.sql` so the new tables are also closed to the public API.

**Adding a conditional question set.** Add an entry to `QUESTION_SETS` in `src/lib/enquiry-config.ts`, with `triggers` matching enquiry-service keys. No database change is needed, because answers are stored as JSON per set.

**Adding a permission.** Add it to `PERMISSIONS`, then call `requirePermission("…")` in the action or route, and `requirePagePermission` on the page. Hiding a menu item alone is not enough.

**Rotating secrets**

| Secret | How to rotate | Effect |
|---|---|---|
| `CRON_SECRET` | Change it in Vercel | Takes effect on the next cron run |
| `GOOGLE_PRIVATE_KEY` | Create a new key, update the variable, delete the old key in Google Cloud | — |
| `SMTP_PASSWORD` | Update the variable | — |
| `APP_SECRET` | Change it | Forms that are open at that moment fail once. Stored IP hashes can no longer be matched (harmless). |
| Database password | Reset in Supabase, update `DATABASE_URL` | — |

**Dependency updates (monthly):**

```bash
npm outdated
npm update            # minor/patch
npm run typecheck && npm run lint && npm run build && npm run test:e2e
npm audit --omit=dev
```

At handover, `npm audit --omit=dev` reports only a moderate `minimatch` advisory pulled in by `exceljs` (used for the Excel export). User input never reaches it.

## Monitoring

- **Health check:** `GET /api/health` returns `{ ok: true, db: "up" }`. Point an uptime monitor at it (UptimeRobot, Better Stack, or Vercel's own checks).
- **Errors:** server errors appear in **Vercel → Logs** (look for `[action]`, `[sheets]`, `[mail]`, `[enquiry]`). For alerting, add Sentry with `npx @sentry/wizard@latest -i nextjs` and set `SENTRY_DSN`; no code changes are needed elsewhere.
- **Sync health:** the dashboard card and **Admin → Google Sheets sync** show pending and failed jobs.
- **Security:** the **Admin → Audit log** shows sign-ins, failed sign-ins, exports, deletions and permission changes.

## Data housekeeping

- The daily cron job removes expired sessions, old rate-limit rows and abandoned uploads (files that were reserved but never completed after 24 hours).
- **Lead retention** (default 36 months, set in Settings) is documented in the Privacy Policy. It is deliberately **not** auto-deleted. Review and delete old lost or spam leads periodically, as an administrator, from the lead page.
- **Deleting a lead** does not remove its row from Google Sheets (by design, for record-keeping). Remove the row manually if a data-subject request requires it.
- **Data-subject requests** (access or deletion): search the lead by phone or email, export it, or delete it, and note the action in the audit log.

## Performance notes

- Public pages are statically generated and revalidated every 60 seconds, and immediately after an admin saves content. Admin pages render dynamically.
- Images and documents are served through `/api/files/<id>`. Public files are cached for 5 minutes at the browser and edge; with the S3 driver, requests are redirected to short-lived signed URLs, so file bytes do not pass through Vercel functions.
- For very large video libraries, use YouTube or Vimeo links (the *Video link* resource type) instead of uploads.

## Running the test-suite

```bash
# terminal 1 – mock Google APIs
node tests/mock-google.mjs
# terminal 2 – app against a fresh database, with the mock wired in
export GOOGLE_SERVICE_ACCOUNT_EMAIL=test@mock.iam.gserviceaccount.com
export GOOGLE_PRIVATE_KEY="$(openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 2>/dev/null)"
export GOOGLE_SHEETS_CENTRAL_ID=CENTRAL_SHEET_TEST GOOGLE_SHEETS_API_BASE=http://localhost:4555/sheets GOOGLE_OAUTH_TOKEN_URL=http://localhost:4555/token
npm run db:setup && npm run build && npm start
# terminal 3
npm i -D playwright && npx playwright install chromium
npm run test:e2e        # writes test-results/results.json + screenshots
```

The `GOOGLE_SHEETS_API_BASE` and `GOOGLE_OAUTH_TOKEN_URL` overrides exist only for testing. **Never set them in production.**

## Known limitations and possible next steps

- **Nepali language:** content is structured so a Nepali version can be added later (for example with `next-intl`), but only English is implemented.
- **Two-way Sheets sync** is intentionally not implemented; the database is the master copy.
- **WhatsApp notifications to staff** would need the WhatsApp Business API (Meta Cloud API) and an approved template. Email and in-app notifications are implemented.
- **Office document previews** use Microsoft's free online viewer, which only works for *public* documents on the live public domain. Private and internal Office files are download-only. Upload a PDF version for in-browser preview.
- **Bikram Sambat dates** are not shown; all dates use the Gregorian calendar in Nepal Time.
