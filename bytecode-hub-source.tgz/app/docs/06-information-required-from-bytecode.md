# 6. Information and assets still required from ByteCode

Nothing in this list was invented. Each item has a clearly labelled placeholder, or stays hidden, until ByteCode supplies it. Everything can be entered from the admin dashboard without code changes.

## A. Brand and company (Admin → Settings)

| # | Item | Why it's needed | Current state |
|---|---|---|---|
| A1 | Official spelling: "ByteCode Developers" or "Bytecode Developers"? | Brief and website differ | Uses "ByteCode Developers" (from the brief) |
| A2 | Logo files: PNG/WebP with transparent background, versions for light and dark backgrounds, and a square icon | Header, footer, favicon, PWA icon | Text wordmark and generated `</>` icon |
| A3 | Confirmed brand colours (hex) | Theme | Navy #17324D, Blue #2878A8, Teal #269B83 (from the brief document) |
| A4 | **WhatsApp business number** | WhatsApp buttons on the site and in emails | Hidden until set |
| A5 | Office hours and Google Maps link | Contact page | Hidden until set |
| A6 | Approved "About" text, mission and founding details | About page | Neutral description only |
| A7 | Technologies ByteCode actually uses (for the chips on the home page) | Technology section | Chips hidden; the capability cards use wording from ByteCode's website |
| A8 | Domain decision (recommended: `hub.bytecodedevelopers.com`) and DNS access | Deployment | — |

## B. Services and pricing (Admin → Services & packages)

| # | Item | Current state |
|---|---|---|
| B1 | Website packages (e.g. Starter, Business, E-commerce): name, description, **price or starting price (NPR)**, deliverables, features, exclusions, delivery period, add-ons | 3 unpublished placeholders |
| B2 | SEO packages (Starter, Growth, Advanced): **monthly price**, target audience, deliverables, technical, on-page and off-page scope, content volume, reporting, website requirements, exclusions | 3 unpublished placeholders |
| B3 | Pricing approach for travel SEO content (per itinerary? per word? monthly?) | "Custom quotation" |
| B4 | Any standard packages for apps, systems, content writing, marketing, video and consulting | "Custom quotation" |
| B5 | Review of the eight service-page texts | Written from the brief and ByteCode's website. Makes no claims of results. |
| B6 | Whether VAT is included in prices | — |

## C. Portfolio and demonstrations (Admin → Portfolio, Demos & UI/UX)

| # | Item | Current state |
|---|---|---|
| C1 | For each of the **19 draft projects** imported from bytecodedevelopers.com/portfolio: confirm it is a completed client project, the industry and type, a description, the problem and solution, features, technologies, **live URL**, desktop and mobile screenshots, and **written permission to show the client name** | Unpublished drafts with an internal note |
| C2 | Any further projects (e.g. "Tesseract HRMS", listed on the home page of the current site; included as a draft) | Draft |
| C3 | **Vercel deployment links** and **UI/UX / Figma prototype links**, each with an honest classification (client project, internal demo, UI/UX concept or prototype) | None |
| C4 | Video walkthroughs or promotional videos (YouTube, Vimeo or files) | None |
| C5 | Real client testimonials, with documented consent | None (the section stays hidden) |

## D. Documents (Admin → Resources)

| # | Item | Suggested visibility |
|---|---|---|
| D1 | Company profile (PDF) | Public |
| D2 | Service brochures | Public |
| D3 | Website development package sheet | Public (once prices are approved) |
| D4 | SEO package sheet | Public |
| D5 | Travel SEO content samples (itineraries, destination pages) | Public |
| D6 | General content writing samples | Public |
| D7 | Case studies | Public |
| D8 | Proposal templates and pitch presentations | Internal only |
| D9 | Past proposals and client documents | Private, or do not upload |

## E. Campaign and operations

| # | Item |
|---|---|
| E1 | Pokhara campaign **start and end dates**, and the target business areas (Lakeside, Damside, etc.) |
| E2 | Names, emails and roles of all **BD team members** and managers |
| E3 | Google Workspace account to own the **Central Lead Register** and **Pokhara Campaign Leads** sheets, plus a Google Cloud project for the service account |
| E4 | SMTP mailbox for sending notifications (e.g. `no-reply@bytecodedevelopers.com`) |
| E5 | Existing lead spreadsheets to import (any format; a one-off import can map them to Lead IDs) |
| E6 | Meta Ads account details: Pixel ID, and the UTM naming convention for ads |
| E7 | Google Analytics 4 measurement ID (if used) |
| E8 | Budget ranges (NPR) the team prefers in the enquiry form (6 sensible defaults are seeded and editable) |

## F. Legal

| # | Item |
|---|---|
| F1 | Legal review of the **Privacy Policy** and **Terms of Use** (defaults describe exactly how the platform handles data, referencing Nepal's Privacy Act, 2075) |
| F2 | Confirmed **lead data retention period** (default: 36 months) |
| F3 | Company registration and PAN/VAT numbers, if they should appear in the footer |

## G. Hosting accounts

| # | Item |
|---|---|
| G1 | Vercel team (Pro recommended) with access for the developer |
| G2 | Supabase organisation (Pro recommended, Mumbai region) |
| G3 | DNS access for `bytecodedevelopers.com` to add the `hub` CNAME record |
