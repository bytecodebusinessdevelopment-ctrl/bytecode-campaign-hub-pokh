/* ByteCode Campaign Hub service worker — keeps the quick-capture screen usable on weak connections. */
const VERSION = "bc-v1";
const STATIC = `${VERSION}-static`;
const PAGES = `${VERSION}-pages`;
const OFFLINE_PAGES = ["/admin/leads/quick"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(STATIC).then((c) => c.addAll(["/offline.html", "/icon.svg"])).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)))).then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // Immutable build assets: cache-first.
  if (url.pathname.startsWith("/_next/static/") || url.pathname.startsWith("/icons/")) {
    e.respondWith(
      caches.match(req).then((hit) => hit || fetch(req).then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(STATIC).then((c) => c.put(req, copy)); }
        return res;
      })),
    );
    return;
  }

  // Quick-capture page: network-first, fall back to the last good copy when offline.
  if (req.mode === "navigate" && OFFLINE_PAGES.includes(url.pathname)) {
    e.respondWith(
      fetch(req).then((res) => {
        if (res.ok && !res.redirected) { const copy = res.clone(); caches.open(PAGES).then((c) => c.put(url.pathname, copy)); }
        return res;
      }).catch(() => caches.match(url.pathname).then((hit) => hit || caches.match("/offline.html"))),
    );
    return;
  }

  // Other admin navigations: show a friendly offline page if the network is down.
  if (req.mode === "navigate" && url.pathname.startsWith("/admin")) {
    e.respondWith(fetch(req).catch(() => caches.match("/offline.html")));
  }
});
