# ByteCode Campaign Hub

A reusable digital sales platform for **ByteCode Developers**, built first for the Pokhara business-development campaign.

It combines the following in one application:

- **Public website:** landing page, eight service pages, a package catalogue, portfolio and case studies, a UI/UX and live-demo showcase, and a resource library.
- **Lead capture:** a multi-step public enquiry form with conditional questions, a contact form, full internal lead entry, and a mobile **Quick capture** screen that keeps working offline.
- **CRM:** a pipeline, assignment, a notes timeline, meetings, follow-ups and reminders, duplicate detection and merging, and CSV and Excel export.
- **Reporting:** a dashboard and campaign reports that keep recorded results separate from estimated values.
- **Admin:** portfolio, demos, resources, testimonials, services and packages, campaigns, lists, users, settings and an audit log. None of these need code changes.
- **Integrations:** Google Sheets synchronisation (idempotent, queued, with retry), email notifications, analytics that respect cookie consent, and S3-compatible file storage.

## Tech stack

| Layer | Choice |
|---|---|
| Framework | Next.js 15 (App Router, Server Components, Server Actions) + TypeScript |
| Styling | Tailwind CSS 3; self-hosted Inter and Plus Jakarta Sans fonts |
| Database | PostgreSQL (Supabase recommended) through Drizzle ORM. SQL migrations are in `drizzle/` |
| Auth | Individual accounts, bcrypt password hashes, httpOnly session cookies. Role permissions are enforced on the server |
| Files | S3-compatible storage (Supabase Storage, Cloudflare R2 or AWS S3), or local disk for development |
| Sheets | Google Sheets API with a service account, through a background job queue |
| Hosting | Vercel (recommended) or any Node 20+ server |

## Quick start (local)

```bash
cp .env.example .env            # then edit DATABASE_URL, APP_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD
npm install
npm run db:setup                # runs the migrations and seeds the configuration and first admin
npm run dev                     # http://localhost:3000  ·  team login at /admin
```

## Scripts

| Command | Purpose |
|---|---|
| `npm run dev` / `build` / `start` | Develop, build and serve |
| `npm run db:migrate` | Apply SQL migrations in `drizzle/` |
| `npm run db:seed` | Seed lookups, services, the Pokhara campaign, placeholder packages and draft portfolio. Safe to re-run |
| `npm run db:generate` | Create a new migration after editing `src/lib/db/schema.ts` |
| `npm run create-admin` | Create an administrator or reset their password (reads `ADMIN_*` env vars) |
| `npm run typecheck` / `lint` | Static checks |
| `npm run test:e2e` | End-to-end acceptance tests. See `docs/05-testing-report.md` |

## Project structure

```
src/
  app/(public)/          public website (home, services, packages, portfolio, showcase, resources, about, contact, request-proposal, legal, /c/<campaign>)
  app/admin/             login + protected panel (dashboard, leads, quick capture, follow-ups, presenter kit, reports, content, configuration)
  app/api/               files, uploads, lead export, quick-capture endpoint, cron jobs, health
  components/            public UI, forms, admin UI, charts
  lib/                   db schema & client, auth & permissions, leads service, sheets sync, storage, mail, stats, settings
drizzle/                 SQL migrations
scripts/                 migrate, seed, create-admin, supabase-hardening.sql
tests/                   e2e acceptance suite + Google Sheets API mock
docs/                    assessment & architecture, deployment, admin guide, maintenance, testing report, information required
```

## Documentation

1. [Project assessment & architecture](docs/01-project-assessment-and-architecture.md)
2. [Deployment guide](docs/02-deployment-guide.md)
3. [Admin user guide](docs/03-admin-user-guide.md)
4. [Technical maintenance](docs/04-technical-maintenance.md)
5. [Testing report](docs/05-testing-report.md)
6. [Information and assets still required from ByteCode](docs/06-information-required-from-bytecode.md)
