import type { Config } from "tailwindcss";
import typography from "@tailwindcss/typography";

const v = (name: string) => `rgb(var(--${name}) / <alpha-value>)`;

export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    container: { center: true, padding: { DEFAULT: "1rem", sm: "1.5rem", lg: "2rem" }, screens: { "2xl": "1240px" } },
    extend: {
      colors: {
        navy: { DEFAULT: v("brand-navy"), 950: "#0b1a29" },
        brand: { DEFAULT: v("brand-blue") },
        teal: { DEFAULT: v("brand-teal") },
        ink: { DEFAULT: "#0f1d2b", soft: "#425466", muted: "#6b7c8f" },
        line: "#e3e9ef",
        surface: "#f6f8fb",
      },
      fontFamily: {
        sans: ['"Inter Variable"', "Inter", "system-ui", "-apple-system", "Segoe UI", "Roboto", "sans-serif"],
        display: ['"Plus Jakarta Sans Variable"', '"Inter Variable"', "system-ui", "sans-serif"],
      },
      borderRadius: { xl: "0.875rem", "2xl": "1.25rem", "3xl": "1.75rem" },
      boxShadow: {
        card: "0 1px 2px rgba(15,29,43,.04), 0 4px 16px -4px rgba(15,29,43,.08)",
        lift: "0 2px 4px rgba(15,29,43,.04), 0 18px 40px -12px rgba(15,29,43,.22)",
      },
      keyframes: {
        "fade-up": { from: { opacity: "0", transform: "translateY(12px)" }, to: { opacity: "1", transform: "none" } },
      },
      animation: { "fade-up": "fade-up .6s cubic-bezier(.2,.7,.2,1) both" },
    },
  },
  plugins: [typography],
} satisfies Config;
