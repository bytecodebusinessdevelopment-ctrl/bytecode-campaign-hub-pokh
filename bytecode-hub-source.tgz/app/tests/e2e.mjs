/**
 * End-to-end acceptance tests (Part 18 of the brief).
 *
 * Prerequisites: app running (BASE_URL, default http://localhost:3000) against a freshly seeded database,
 * ADMIN_EMAIL / ADMIN_PASSWORD set, and — for the Sheets test — the app started with
 * GOOGLE_SHEETS_API_BASE=http://localhost:4555/sheets and GOOGLE_OAUTH_TOKEN_URL=http://localhost:4555/token
 * while `node tests/mock-google.mjs` is running.
 *
 *   npm i -D playwright && npx playwright install chromium
 *   node tests/e2e.mjs
 */
import { createRequire } from "node:module";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";

// CommonJS require so a globally installed Playwright (NODE_PATH) also works.
const { chromium } = createRequire(import.meta.url)("playwright");

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const MOCK = process.env.MOCK_GOOGLE_URL ?? "http://localhost:4555";
const ADMIN = { email: process.env.ADMIN_EMAIL ?? "admin@bytecode.test", password: process.env.ADMIN_PASSWORD ?? "ChangeMe!2026" };
const OUT = process.env.E2E_OUT ?? path.join(process.cwd(), "test-results");
fs.mkdirSync(OUT, { recursive: true });

const results = [];
async function test(name, fn) {
  const t0 = Date.now();
  try {
    await fn();
    results.push({ name, ok: true, ms: Date.now() - t0 });
    console.log(`✔ ${name}`);
  } catch (e) {
    results.push({ name, ok: false, ms: Date.now() - t0, error: String(e?.message ?? e).slice(0, 500) });
    console.log(`✘ ${name}\n   ${String(e?.message ?? e).split("\n")[0]}`);
  }
}
const assert = (c, m) => { if (!c) throw new Error(m); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── fixture files ──
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "bc-e2e-"));
const png = path.join(tmp, "screenshot.png");
fs.writeFileSync(png, Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAFElEQVR4nGNgYGD4z8DAwMDAwMAAAA0ABHEk3n0AAAAASUVORK5CYII=", "base64"));
const pdf = path.join(tmp, "company-profile.pdf");
fs.writeFileSync(pdf, "%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj 2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj 3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 200]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF");
const fakePdf = path.join(tmp, "not-really.pdf");
fs.writeFileSync(fakePdf, "<html><script>alert(1)</script></html>");
const docx = path.join(tmp, "internal-proposal.docx");
fs.writeFileSync(docx, Buffer.concat([Buffer.from([0x50, 0x4b, 0x03, 0x04]), Buffer.alloc(200, 1)]));
const svg = path.join(tmp, "logo.svg");
fs.writeFileSync(svg, "<svg xmlns='http://www.w3.org/2000/svg'><script>alert(1)</script></svg>");

const uniq = Date.now().toString(36);
const browser = await chromium.launch();
const anon = await browser.newContext({ viewport: { width: 1280, height: 900 } });
const admin = await browser.newContext({ viewport: { width: 1280, height: 900 } });
const pub = await anon.newPage();
const page = await admin.newPage();
page.on("dialog", (d) => d.accept());

async function login(p, email, password) {
  await p.goto(`${BASE}/admin/login`);
  await p.fill("#email", email);
  await p.fill("#password", password);
  await Promise.all([p.waitForURL((u) => u.pathname.startsWith("/admin") && !u.pathname.endsWith("/login")), p.click("button:has-text('Sign in')")]);
}

let enquiryCode = "";
let enquiryLeadId = "";
let resourceSlug = "";
let resourceFileId = "";
let privateFileId = "";

/* 1 — Public site */
await test("Visitor can open every public section (desktop)", async () => {
  for (const p of ["/", "/services", "/services/website-development", "/services/seo", "/services/travel-tourism-seo-content", "/packages", "/portfolio", "/showcase", "/resources", "/about", "/contact", "/request-proposal", "/privacy", "/terms", "/c/pokhara"]) {
    const r = await pub.goto(BASE + p);
    assert(r.status() === 200, `${p} returned ${r.status()}`);
    assert(await pub.locator("header").count() > 0 && await pub.locator("footer").count() > 0, `${p} missing header/footer`);
  }
  const r404 = await pub.goto(`${BASE}/this-does-not-exist`);
  assert(r404.status() === 404, "404 page");
});

await test("Navigation links work and nothing fake is published (no testimonials/prices/portfolio by default)", async () => {
  await pub.goto(BASE);
  await pub.click("header nav >> text=Portfolio");
  await pub.waitForURL(/\/portfolio/);
  const body = await pub.textContent("main");
  assert(/Our portfolio is being updated|View project/.test(body), "portfolio empty-state or projects");
  await pub.goto(`${BASE}/packages`);
  const pk = await pub.textContent("main");
  assert(!/PLACEHOLDER/i.test(pk), "placeholder packages must not be public");
  await pub.goto(BASE);
  assert(!(await pub.textContent("main")).includes("What our clients say"), "testimonials hidden without consented entries");
});

await test("SEO basics: sitemap, robots, structured data, OG tags", async () => {
  const sm = await (await pub.request.get(`${BASE}/sitemap.xml`)).text();
  assert(sm.includes("/services/seo"), "sitemap lists services");
  const rb = await (await pub.request.get(`${BASE}/robots.txt`)).text();
  assert(rb.includes("Disallow: /admin"), "robots blocks admin");
  await pub.goto(BASE);
  assert(await pub.locator('script[type="application/ld+json"]').count() === 1, "JSON-LD present");
  assert(await pub.locator('meta[property="og:image"]').count() >= 1, "OG image");
});

/* 2 — Public enquiry with conditional questions */
await test("Visitor can submit a multi-step enquiry with conditional questions", async () => {
  await pub.goto(`${BASE}/request-proposal?service=seo`);
  await pub.waitForSelector("text=What can we help you with?");
  // SEO pre-selected via ?service=seo; add Website development
  await pub.click("button[role=checkbox]:has-text('Website development')");
  await pub.click("button:has-text('Continue')");
  await pub.fill("#b-name", `Lakeside Treks ${uniq}`);
  await pub.selectOption("#b-industry", { label: "Travel, Tours and Trekking" });
  await pub.fill("#b-loc", "Lakeside, Pokhara");
  await pub.click("button:has-text('Continue')");
  await pub.fill("#c-name", "Sita Gurung");
  await pub.fill("#c-phone", "abc");
  await pub.click("button:has-text('Continue')");
  assert(await pub.isVisible("text=Enter a valid phone number"), "phone validation");
  await pub.fill("#c-phone", "9846000001");
  await pub.fill("#c-email", `sita.${uniq}@example.com`);
  await pub.click("button:has-text('Continue')");
  assert(await pub.isVisible("legend:has-text('SEO details')"), "SEO conditional section shown");
  assert(await pub.isVisible("legend:has-text('Website details')"), "Website conditional section shown");
  assert(!(await pub.isVisible("legend:has-text('Video production details')")), "unrelated sections hidden");
  await pub.fill("#req", "We want more direct bookings from international trekkers instead of relying on OTAs.");
  await pub.fill("#seo-target_locations", "Europe, Australia");
  await pub.click("button:has-text('Continue')");
  await pub.click("button[role=radio]:has-text('Within one month')");
  await pub.click("button:has-text('Continue')");
  await pub.click("button:has-text('Submit enquiry')");
  assert(await pub.isVisible("text=Please agree so we can contact you"), "consent required");
  await pub.check("input[type=checkbox] >> nth=-1");
  await sleep(4200); // signed form token rejects bots that submit within 4s of loading the page
  await pub.click("button:has-text('Submit enquiry')");
  await pub.waitForSelector("text=we've received your enquiry", { timeout: 15000 });
  enquiryCode = (await pub.textContent("span.font-mono")).trim();
  assert(/^POK-\d{4}-\d{4}$/.test(enquiryCode), `unexpected lead code ${enquiryCode}`);
});

await test("Spam protection: honeypot and instant submissions are rejected", async () => {
  await pub.goto(`${BASE}/contact`);
  await pub.fill("#cf-name", "Bot");
  await pub.fill("#cf-biz", "Bot Inc");
  await pub.fill("#cf-phone", "9800000000");
  await pub.fill("#cf-msg", "Buy cheap things");
  await pub.check("form input[type=checkbox]");
  await pub.click("button:has-text('Send message')");
  await pub.waitForSelector("text=Please take a moment", { timeout: 8000 }); // too fast
});

/* 3 — Admin */
await test("Administrator can sign in; wrong password is rejected", async () => {
  await page.goto(`${BASE}/admin/login`);
  await page.fill("#email", ADMIN.email);
  await page.fill("#password", "wrong-password-1");
  await page.click("button:has-text('Sign in')");
  await page.waitForSelector("text=Incorrect email or password");
  await login(page, ADMIN.email, ADMIN.password);
  assert(await page.isVisible("text=Total leads"), "dashboard visible");
});

await test("Enquiry is stored in the database with answers, attribution and consent", async () => {
  await page.goto(`${BASE}/admin/leads?q=${enquiryCode}`);
  await page.click(`table >> text=Lakeside Treks ${uniq}`);
  await page.waitForURL(/\/admin\/leads\/[0-9a-f-]{36}/);
  enquiryLeadId = page.url().split("/").pop().split("?")[0];
  const txt = await page.textContent("main");
  assert(txt.includes(enquiryCode), "lead code shown");
  assert(txt.includes("Europe, Australia"), "conditional SEO answer stored");
  assert(txt.includes("Website enquiry"), "entry type / source");
  assert(/Consent\s*Yes/.test(txt), "consent recorded");
});

await test("Relevant information synchronises to Google Sheets (mock) without duplicate rows on retry", async () => {
  // Campaign sheet configured via Admin → Campaigns
  const dump0 = await (await fetch(`${MOCK}/__dump`).catch(() => null))?.json?.();
  assert(dump0 !== undefined, "mock Google server not running — start tests/mock-google.mjs");
  await page.goto(`${BASE}/admin/campaigns`);
  await page.click("text=Pokhara Business Development Campaign");
  await page.fill("input[name=sheetId]", "https://docs.google.com/spreadsheets/d/POKHARA_SHEET_123/edit#gid=0");
  await page.click("button:has-text('Save campaign')");
  await page.waitForSelector("text=Campaign saved.");
  await page.goto(`${BASE}/admin/leads/${enquiryLeadId}`);
  await page.click("button:has-text('Sync now')");
  await page.waitForSelector("text=Sync attempted");
  let dump = await (await fetch(`${MOCK}/__dump`)).json();
  const rows = () => (dump.POKHARA_SHEET_123?.["Pokhara Leads"] ?? []);
  assert(rows()[0]?.[0] === "Lead ID", "header row written");
  assert(rows().filter((r) => r[0] === enquiryCode).length === 1, "lead row written once");
  assert(dump.CENTRAL_SHEET_TEST?.Leads?.some((r) => r[0] === enquiryCode), "central register row written");
  // Retry three times + change status → still exactly one row, updated in place
  for (let i = 0; i < 3; i++) { await page.click("button:has-text('Sync now')"); await page.waitForTimeout(600); }
  await page.selectOption("#statusId", { label: "Contacted" });
  await page.click("button:has-text('Update status')");
  await page.waitForSelector("text=Status updated.");
  await page.waitForTimeout(1500);
  dump = await (await fetch(`${MOCK}/__dump`)).json();
  const mine = rows().filter((r) => r[0] === enquiryCode);
  assert(mine.length === 1, `expected 1 row, found ${mine.length}`);
  assert(mine[0].includes("Contacted"), "status change synced to existing row");
  assert(!JSON.stringify(mine[0]).includes("international trekkers"), "detailed requirements stay out of the sheet");
});

await test("Sync failures are logged and an administrator can retry", async () => {
  await fetch(`${MOCK}/__fail?n=50`);
  await page.goto(`${BASE}/admin/leads/${enquiryLeadId}`);
  await page.click("button:has-text('Sync now')");
  await page.waitForSelector("text=failed");
  await fetch(`${MOCK}/__fail?n=0`);
  await page.goto(`${BASE}/admin/integrations`);
  assert((await page.textContent("main")).includes("Simulated outage"), "error logged");
  await page.click("button:has-text('Retry all failed & process queue')");
  await page.waitForSelector("text=Processed");
  await page.goto(`${BASE}/admin/leads/${enquiryLeadId}`);
  assert((await page.locator("text=success").count()) >= 1, "retry succeeded");
});

await test("Team member can create a lead during a visit (Quick capture) — offline-safe and idempotent", async () => {
  const m = await admin.newPage();
  await m.setViewportSize({ width: 390, height: 844 });
  await m.goto(`${BASE}/admin/leads/quick`);
  await m.getByLabel("Business name").fill(`Fewa Hotel ${uniq}`);
  await m.fill("input[type=tel]", "9846000001"); // same phone as the enquiry → duplicate flag
  await m.click("button[aria-pressed]:has-text('SEO')");
  await m.click("button:has-text('Hot')");
  await m.click("button:has-text('Save prospect')");
  await m.waitForSelector("text=Saved as");
  assert(await m.isVisible("text=may be a duplicate"), "duplicate flagged");
  await m.screenshot({ path: path.join(OUT, "mobile-quick-capture.png"), fullPage: true });
  // Offline: queue on device, then flush when back online
  await admin.setOffline(true);
  await m.getByLabel("Business name").fill(`Offline Cafe ${uniq}`);
  await m.click("button:has-text('Save prospect')");
  await m.waitForSelector("text=saved on this phone");
  await admin.setOffline(false);
  await m.evaluate(() => window.dispatchEvent(new Event("online")));
  await m.waitForTimeout(2500);
  await m.reload();
  assert(!(await m.isVisible("text=waiting to upload")), "offline queue flushed");
  // Same clientRef twice → same lead
  const payload = { businessName: `Retry Test ${uniq}`, clientRef: `retry-${uniq}`, serviceIds: [] };
  const a = await (await m.request.post(`${BASE}/api/leads/quick`, { data: payload })).json();
  const b = await (await m.request.post(`${BASE}/api/leads/quick`, { data: payload })).json();
  assert(a.leadCode && a.leadCode === b.leadCode && b.existing === true, "retry returns the same lead");
  await m.close();
  await page.goto(`${BASE}/admin/leads?q=Offline Cafe ${uniq}`);
  assert(await page.locator("table").getByText(`Offline Cafe ${uniq}`).isVisible(), "offline lead uploaded");
});

await test("Full internal lead entry saves partial information; overdue follow-ups are flagged", async () => {
  await page.goto(`${BASE}/admin/leads/new`);
  await page.fill("input[name=businessName]", `Pokhara Dental Clinic ${uniq}`);
  await page.fill("input[name=nextAction]", "Call back with SEO proposal");
  await page.fill("input[name=followUpAt]", "2026-01-05T10:00");
  await page.click("button:has-text('Save lead')");
  await page.waitForURL(/created=1/);
  assert(await page.isVisible("text=Partial information"), "partial lead allowed");
  await page.goto(`${BASE}/admin/follow-ups?tab=overdue`);
  assert(await page.isVisible(`text=Pokhara Dental Clinic ${uniq}`), "overdue follow-up listed");
  await page.goto(`${BASE}/admin`);
  assert(await page.isVisible("text=overdue follow-up"), "dashboard alert");
});

await test("A lead can be edited and followed up (status rules, notes, follow-up, meeting)", async () => {
  await page.goto(`${BASE}/admin/leads/${enquiryLeadId}`);
  await page.selectOption("#statusId", { label: "Lost" });
  await page.click("button:has-text('Update status')");
  await page.waitForSelector("text=Please give a reason");
  await page.reload();
  await page.fill("textarea[name=body]", "Called Sita, interested in SEO Growth package.");
  await page.click("button:has-text('Add')");
  await page.waitForSelector("text=Added to timeline.");
  await page.fill("input[name=title]", "Send SEO proposal");
  await page.click("button:has-text('Schedule')");
  await page.waitForSelector("text=Follow-up scheduled.");
  await page.fill("input[name=outcome] >> nth=0", "Proposal emailed");
  await page.click("button:has-text('Done') >> nth=0");
  await page.waitForSelector("text=Follow-up completed.");
  await page.click("summary:has-text('Edit lead details')");
  await page.fill("input[name=estimatedValue]", "180000");
  await page.click("button:has-text('Save changes')");
  await page.waitForSelector("text=Lead updated.");
  await page.reload();
  assert((await page.textContent("main")).includes("Rs. 1,80,000"), "estimated value saved & formatted in NPR");
  assert((await page.textContent("main")).includes("Proposal emailed"), "follow-up outcome in timeline");
});

await test("Possible duplicates can be merged", async () => {
  await page.goto(`${BASE}/admin/leads?duplicates=1&q=Fewa Hotel ${uniq}`);
  await page.click(`table >> text=Fewa Hotel ${uniq}`);
  await page.waitForSelector("text=Possible duplicate of");
  await page.click("button:has-text('Merge into')");
  await page.waitForURL(/merged=1/);
  assert(page.url().includes(enquiryLeadId), "merged into primary");
  assert((await page.textContent("main")).includes("Merged duplicate lead"), "timeline records merge");
});

/* 4 — Content management */
await test("A project can be added from the admin dashboard and published", async () => {
  await page.goto(`${BASE}/admin/portfolio/new`);
  await page.fill("input[name=title]", `Annapurna Trek Booking Site ${uniq}`);
  await page.selectOption("select[name=industryId]", { label: "Travel, Tours and Trekking" });
  await page.fill("textarea[name=summary]", "Test project created by the automated acceptance tests.");
  await page.fill("input[name=liveUrl]", "https://example.com");
  await page.setInputFiles("input[type=file] >> nth=0", png);
  await page.waitForSelector("a:has-text('screenshot.png')");
  await page.check("input[name=services][value]>> nth=0");
  await page.selectOption("select[name=status]", "published");
  await page.click("button:has-text('Save project')");
  await page.waitForURL(/saved=1/);
  await pub.goto(`${BASE}/portfolio`);
  assert(await pub.isVisible(`text=Annapurna Trek Booking Site ${uniq}`), "project visible publicly");
  await Promise.all([pub.waitForURL(/\/portfolio\/.+/), pub.click(`text=Annapurna Trek Booking Site ${uniq}`)]);
  assert(await pub.isVisible("text=View Live Website"), "live website button");
  assert(await pub.isVisible("text=Completed client project"), "classification label");
});

await test("A Vercel deployment can be added and displayed", async () => {
  await page.goto(`${BASE}/admin/showcase/new`);
  await page.fill("input[name=title]", `Hotel Booking UI ${uniq}`);
  await page.fill("input[name=url]", "https://example.com");
  await page.selectOption("select[name=demoType]", "vercel");
  await page.selectOption("select[name=classification]", "uiux_concept");
  await page.check("input[name=embeddable]");
  await page.click("button:has-text('Save demo')");
  await page.waitForURL(/saved=1/);
  await pub.goto(`${BASE}/showcase`);
  assert(await pub.isVisible(`text=Hotel Booking UI ${uniq}`), "demo listed");
  await Promise.all([pub.waitForURL(/\/showcase\/.+/), pub.click(`a:has-text('Preview') >> nth=0`)]);
  assert(await pub.locator("iframe").count() === 1, "embedded preview");
  assert(await pub.isVisible("text=Open in new tab"), "external fallback link");
  assert(await pub.isVisible("text=UI/UX concept"), "honest classification");
});

await test("Uploads are validated (type allow-list + file signature check)", async () => {
  await page.goto(`${BASE}/admin/resources/new`);
  await page.setInputFiles("input[type=file] >> nth=0", fakePdf);
  await page.waitForSelector("text=failed validation");
  await page.goto(`${BASE}/admin/resources/new`);
  const r = await page.request.post(`${BASE}/api/uploads/init`, { data: { name: "logo.svg", size: 100, purpose: "any" } });
  assert(r.status() === 400, "svg rejected");
});

await test("A document can be uploaded, published and appear on multiple service pages", async () => {
  await page.goto(`${BASE}/admin/resources/new`);
  await page.fill("input[name=title]", `Company Profile ${uniq}`);
  await page.selectOption("select[name=categoryId]", { label: "Company Profile" });
  await page.setInputFiles("input[type=file] >> nth=0", pdf);
  await page.waitForSelector("a:has-text('company-profile.pdf')");
  await page.selectOption("select[name=visibility]", "public");
  await page.check("input[name=published]");
  await page.check("input[name=featured]");
  const labels = ["Website Development", "SEO Services"];
  for (const l of labels) await page.check(`label:has-text('${l}') >> input[name=services]`);
  await page.click("button:has-text('Save resource')");
  await page.waitForURL(/saved=1/);
  resourceSlug = (await page.getAttribute("a:has-text('View')", "href")).split("/").pop();
  for (const s of ["website-development", "seo"]) {
    await pub.goto(`${BASE}/services/${s}`);
    await pub.reload();
    assert(await pub.isVisible(`text=Company Profile ${uniq}`), `resource on ${s}`);
  }
  await pub.goto(`${BASE}/resources/${resourceSlug}`);
  const dl = await pub.getAttribute("a:has-text('Download')", "href");
  resourceFileId = dl.split("/")[3].split("?")[0];
  const res = await pub.request.get(BASE + dl);
  assert(res.status() === 200 && (res.headers()["content-type"] ?? "").includes("pdf"), "public download works without login");
});

await test("Private documents remain private", async () => {
  await page.goto(`${BASE}/admin/resources/new`);
  await page.fill("input[name=title]", `Internal proposal ${uniq}`);
  await page.setInputFiles("input[type=file] >> nth=0", docx);
  await page.waitForSelector("a:has-text('internal-proposal.docx')");
  await page.selectOption("select[name=visibility]", "private");
  await page.check("input[name=published]");
  await page.click("button:has-text('Save resource')");
  await page.waitForURL(/saved=1/);
  privateFileId = (await page.getAttribute("a:has-text('internal-proposal.docx')", "href")).split("/").pop();
  const r = await pub.request.get(`${BASE}/api/files/${privateFileId}`);
  assert(r.status() === 404, `private file served to anonymous visitor (${r.status()})`);
  await pub.goto(`${BASE}/resources`);
  assert(!(await pub.isVisible(`text=Internal proposal ${uniq}`)), "not listed publicly");
  const ok = await page.request.get(`${BASE}/api/files/${privateFileId}`);
  assert(ok.status() === 200, "admin can open it");
});

await test("An administrator can manage packages and services", async () => {
  await page.goto(`${BASE}/admin/services`);
  await page.click("text=SEO Services");
  await page.click("text=SEO Starter");
  await page.selectOption("select[name=priceType]", "monthly");
  await page.fill("input[name=priceNpr]", "25000");
  await page.check("input[name=published]");
  await page.click("button:has-text('Save package')");
  await page.waitForSelector("text=marked as a placeholder"); // guard
  await page.uncheck("input[name=isPlaceholder]");
  await page.fill("textarea[name=description]", "Test package description.");
  await page.fill("textarea[name=deliverables]", "Monthly report\nOn-page fixes");
  await page.click("button:has-text('Save package')");
  await page.waitForSelector("text=Package saved.");
  await pub.goto(`${BASE}/packages`);
  await pub.reload();
  assert(await pub.isVisible("text=Rs. 25,000 / month"), "package price shown in NPR");
});

/* 5 — Roles & permissions */
let bdPassword = "";
await test("Permissions are enforced on the server for a BD team member", async () => {
  await page.goto(`${BASE}/admin/users`);
  await page.fill("input[name=name]", `Ram BD ${uniq}`);
  await page.fill("input[name=email]", `ram.${uniq}@bytecode.test`);
  await page.fill("input[name=password]", "BdPassword2026");
  await page.click("button:has-text('Create')");
  await page.waitForSelector("text=User created");
  bdPassword = "BdPassword2026";
  const bdCtx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const bd = await bdCtx.newPage();
  await login(bd, `ram.${uniq}@bytecode.test`, bdPassword);
  await bd.goto(`${BASE}/admin/users`);
  assert(bd.url().includes("denied=1"), "BD cannot open Users");
  const lead = await bd.goto(`${BASE}/admin/leads/${enquiryLeadId}`);
  assert(lead.status() === 404, "BD cannot open a lead they don't own");
  const exp = await bd.request.get(`${BASE}/api/leads/export?format=csv`);
  assert(exp.status() === 403, "BD cannot export");
  const list = await bd.goto(`${BASE}/admin/leads`);
  assert(list.status() === 200 && !(await bd.isVisible(`text=Lakeside Treks ${uniq}`)), "BD sees only own leads");
  await bd.goto(`${BASE}/admin/leads/quick`);
  await bd.getByLabel("Business name").fill(`BD Own Lead ${uniq}`);
  await bd.click("button:has-text('Save prospect')");
  await bd.waitForSelector("text=Saved as");
  await Promise.all([bd.waitForURL(/\/admin\/leads\/[0-9a-f-]{36}/), bd.click("text=Add more details")]);
  assert(await bd.locator("h1").getByText(`BD Own Lead ${uniq}`).isVisible(), "BD can open own lead");
  await bd.screenshot({ path: path.join(OUT, "mobile-bd-lead.png"), fullPage: true });
  await bd.goto(`${BASE}/admin`);
  await bd.screenshot({ path: path.join(OUT, "mobile-dashboard.png"), fullPage: true });
  await bdCtx.close();
});

/* 6 — Reporting & export */
await test("Campaign reports reflect actual stored records; exports work", async () => {
  await page.goto(`${BASE}/admin/reports`);
  const txt = await page.textContent("main");
  assert(txt.includes("Total prospects") && txt.includes("Estimates (manually entered"), "recorded vs estimated separated");
  const csv = await (await page.request.get(`${BASE}/api/leads/export?format=csv`)).text();
  assert(csv.includes(enquiryCode), "CSV contains enquiry");
  const x = await page.request.get(`${BASE}/api/leads/export?format=xlsx`);
  assert(x.status() === 200 && (x.headers()["content-type"] ?? "").includes("spreadsheetml"), "Excel export");
  await page.screenshot({ path: path.join(OUT, "desktop-reports.png"), fullPage: true });
  await page.goto(`${BASE}/admin`);
  await page.screenshot({ path: path.join(OUT, "desktop-dashboard.png"), fullPage: true });
});

/* 7 — Mobile */
await test("The system works on mobile devices (no horizontal overflow on key pages)", async () => {
  const m = await anon.newPage();
  await m.setViewportSize({ width: 360, height: 780 });
  for (const p of ["/", "/services/seo", "/portfolio", "/resources", "/request-proposal", "/contact", "/packages"]) {
    await m.goto(BASE + p);
    const overflow = await m.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    assert(overflow <= 1, `${p} overflows horizontally by ${overflow}px`);
  }
  await m.goto(BASE);
  await m.screenshot({ path: path.join(OUT, "mobile-home.png"), fullPage: false });
  await m.close();
});

await test("Security headers and admin protection", async () => {
  const r = await pub.request.get(BASE);
  const h = r.headers();
  assert(h["content-security-policy"] && h["x-content-type-options"] === "nosniff" && h["strict-transport-security"], "security headers");
  const a = await pub.request.get(`${BASE}/admin/leads`, { maxRedirects: 0 });
  assert([302, 307].includes(a.status()), "admin redirects to login");
  const c = await pub.request.get(`${BASE}/api/cron/sync`);
  assert(c.status() === 401, "cron requires secret");
});

await browser.close();
const passed = results.filter((r) => r.ok).length;
fs.writeFileSync(path.join(OUT, "results.json"), JSON.stringify({ base: BASE, date: new Date().toISOString(), passed, total: results.length, results }, null, 2));
console.log(`\n${passed}/${results.length} passed`);
process.exit(passed === results.length ? 0 : 1);
