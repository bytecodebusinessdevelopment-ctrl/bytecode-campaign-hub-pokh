/**
 * Minimal in-memory mock of the Google OAuth token endpoint and Sheets API (only the calls the app uses).
 * Used by the end-to-end tests to prove that sync works and that retries never create duplicate rows.
 *   node tests/mock-google.mjs   (listens on :4555)
 */
import http from "node:http";

const PORT = Number(process.env.MOCK_GOOGLE_PORT ?? 4555);
const books = new Map(); // sheetId -> Map(tab -> rows[][])
let failNext = 0;

const book = (id) => {
  if (!books.has(id)) books.set(id, new Map([["Sheet1", []]]));
  return books.get(id);
};
const parseRange = (r) => {
  const m = /^'?(.+?)'?!([A-Z]+)(\d+)?(?::([A-Z]+)(\d+)?)?$/.exec(r);
  if (!m) throw new Error(`bad range ${r}`);
  return { tab: m[1].replace(/''/g, "'"), row: m[3] ? Number(m[3]) : null };
};
const send = (res, code, body) => { res.writeHead(code, { "Content-Type": "application/json" }); res.end(JSON.stringify(body)); };
const body = (req) => new Promise((r) => { let d = ""; req.on("data", (c) => (d += c)); req.on("end", () => r(d ? JSON.parse(d) : {})); });

http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = decodeURIComponent(url.pathname);
  try {
    if (path === "/token") return send(res, 200, { access_token: "mock-token", expires_in: 3600 });
    if (path === "/__dump") return send(res, 200, Object.fromEntries([...books].map(([id, tabs]) => [id, Object.fromEntries(tabs)])));
    if (path === "/__fail") { failNext = Number(url.searchParams.get("n") ?? 1); return send(res, 200, { failNext }); }
    if (path === "/__reset") { books.clear(); return send(res, 200, {}); }
    if (req.headers.authorization !== "Bearer mock-token") return send(res, 401, { error: "unauthenticated" });
    if (failNext > 0) { failNext--; return send(res, 503, { error: { message: "Simulated outage" } }); }

    const m = /^\/sheets\/([^/:]+)(.*)$/.exec(path);
    if (!m) return send(res, 404, { error: "not found" });
    const [, id, rest] = m;
    const b = book(id);
    if (rest === "" && req.method === "GET") return send(res, 200, { sheets: [...b.keys()].map((title) => ({ properties: { title } })) });
    if (rest === ":batchUpdate") {
      const j = await body(req);
      for (const r of j.requests ?? []) if (r.addSheet) b.set(r.addSheet.properties.title, []);
      return send(res, 200, {});
    }
    const vm = /^\/values\/(.+?)(:append)?$/.exec(rest);
    if (vm) {
      const { tab, row } = parseRange(vm[1]);
      if (!b.has(tab)) return send(res, 400, { error: { message: `Unable to parse range: ${tab}` } });
      const rows = b.get(tab);
      if (vm[2]) {
        const j = await body(req);
        rows.push(...j.values);
        return send(res, 200, { updates: { updatedRange: `'${tab}'!A${rows.length}:U${rows.length}` } });
      }
      if (req.method === "GET") {
        if (row === 1) return send(res, 200, rows[0] ? { values: [rows[0]] } : {});
        return send(res, 200, { values: rows.map((r) => [r[0]]) });
      }
      if (req.method === "PUT") {
        const j = await body(req);
        rows[(row ?? 1) - 1] = j.values[0];
        return send(res, 200, {});
      }
    }
    send(res, 404, { error: "unhandled" });
  } catch (e) {
    send(res, 500, { error: String(e) });
  }
}).listen(PORT, () => console.log(`mock google on :${PORT}`));
